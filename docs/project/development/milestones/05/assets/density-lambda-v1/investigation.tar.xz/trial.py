import os,pathlib,subprocess,json,time,gzip,statistics,hashlib
w=pathlib.Path('/tmp/maelstrom-density-20261028');out=w/'trial-results';out.mkdir(exist_ok=False);env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'));summary={}
for n,scene in [(8000,w/'control/scenes/falling-block-20.toml'),(110592,w/'inputs/scenes/capacity-block-48.toml')]:
 ref=None;samples=[]
 for index in range(3):
  pair={}
  for v in (['control','trial'] if index%2==0 else ['trial','control']):
   args=[str(w/f'target-{v}/release/maelstrom'),'run',str(scene),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure'];t=time.monotonic();p=subprocess.run(args,env=env,capture_output=True,timeout=120);elapsed=time.monotonic()-t;d=out/f'{n}-{index}-{v}';d.mkdir();(d/'stdout.gz').write_bytes(gzip.compress(p.stdout,mtime=0));(d/'stderr.gz').write_bytes(gzip.compress(p.stderr,mtime=0));(d/'process.json').write_text(json.dumps(dict(command=args,exit=p.returncode,wall_s=elapsed),indent=2));assert p.returncode==0
   value=json.loads(p.stdout);assert value['completed_steps']=='480' and not value['failures'];pair[v]=sum(s['total_s'] for s in value.pop('measurements')['steps']);value['metadata'].pop('build_revision',None);finger=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest();assert ref in [None,finger];ref=finger
  if index:samples.append(pair)
  print(n,index,pair,flush=True)
 summary[n]=samples;(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
