import pathlib,subprocess,time,json,gzip,sqlite3,hashlib,os
w=pathlib.Path('/tmp/maelstrom-density-20261028');out=w/'attribution';out.mkdir();env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
def call(label,args,cwd=w,limit=180):
 t=time.monotonic();p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=limit);elapsed=time.monotonic()-t;d=out/label;d.mkdir(parents=True);(d/'stdout.gz').write_bytes(gzip.compress(p.stdout,mtime=0));(d/'stderr.gz').write_bytes(gzip.compress(p.stderr,mtime=0));(d/'process.json').write_text(json.dumps(dict(command=args,exit=p.returncode,wall_s=elapsed,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()),indent=2)+'\n');assert p.returncode==0,(label,p.stderr[-2000:]);return p.stdout
for v in ['control','diagnostic']:
 env['CARGO_TARGET_DIR']=str(w/f'target-{v}');call('build/'+v,['cargo','build','--release','--features','cuda','--locked','--offline'],w/v,600)
 ptx=w/(v+'.ptx');call('ptx/'+v,['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)],w/v);assert ptx.read_bytes() in (w/f'target-{v}/release/maelstrom').read_bytes()
summary={};refs={};raw=sqlite3.connect(out/'activity.sqlite');raw.execute('CREATE TABLE kernel(variant TEXT,particles INTEGER,step INTEGER,iteration INTEGER,operation TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)')
for n,scene,sorts in [(8000,w/'control/scenes/falling-block-20.toml',7),(110592,w/'inputs/scenes/capacity-block-48.toml',11)]:
 summary[n]={}
 for v in ['control','diagnostic']:
  args=[str(w/f'target-{v}/release/maelstrom'),'run',str(scene),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure']
  for kind in ['warmup','profile']:
   command=args if kind=='warmup' else ['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--output',str(out/f'trace-{n}-{v}'),*args];b=call(f'{n}/{v}/{kind}',command);value=json.JSONDecoder().raw_decode(b.decode())[0];assert value['completed_steps']=='480' and not value['failures'];value.pop('measurements');value['metadata'].pop('build_revision',None);finger=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest();assert refs.get(n,finger)==finger,(n,v,kind);refs[n]=finger
  prefix=out/f'trace-{n}-{v}';call(f'{n}/{v}/export',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'])
  db=sqlite3.connect(str(prefix)+'.sqlite');ks=db.execute('SELECT s.value,k.start,k.end,k.correlationId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName ORDER BY k.start').fetchall();ops=['active','density-lambda','correction','mass-check','candidate','projection'] if v=='control' else ['active','density','owner-prefix','squared-suffix','correction','mass-check','candidate','projection'];labels=['acceleration','prediction','cells']+['spatial-sort']*sorts+['count','prefix-block','prefix-total','prefix-carry','fill','row-sort']+ops*8+['velocity'];width=len(labels);assert len(ks)==480*width
  start=9+sorts;raw.executemany('INSERT INTO kernel VALUES(?,?,?,?,?,?,?,?,?)',[(v,n,i//width+1,(i%width-start)//len(ops)+1 if start<=i%width<width-1 else 0,labels[i%width],*k) for i,k in enumerate(ks)]);raw.commit();bands={}
  for lo,hi in [(1,480),(1,120),(241,480)]:bands[f'{lo}-{hi}']={op:sum(k[2]-k[1] for i,k in enumerate(ks) if lo<=i//width+1<=hi and labels[i%width]==op)/1e6/(hi-lo+1) for op in ops}
  summary[n][v]=dict(gpu_ms_per_step=bands,kernels=len(ks),physical_sha256=refs[n]);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(n,v,bands,flush=True)
raw.close()
