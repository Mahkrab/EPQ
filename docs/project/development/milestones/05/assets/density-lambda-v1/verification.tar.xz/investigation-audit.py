"""Independently read the initial split profiles and bounded exploratory pairs."""
from pathlib import Path
import json,gzip,hashlib,sqlite3,sys
root=Path(sys.argv[1]);a=root/'attribution';summary=json.loads((a/'summary.json').read_text());fingerprints={};trials={}
def value_at(d,profile=False):
 proc=json.loads((d/'process.json').read_text());assert proc['exit']==0
 for stream in ['stdout','stderr']:
  raw=gzip.decompress((d/(stream+'.gz')).read_bytes())
  if stream+'_sha256' in proc:assert hashlib.sha256(raw).hexdigest()==proc[stream+'_sha256']
 raw=gzip.decompress((d/'stdout.gz').read_bytes()).decode();v=json.JSONDecoder().raw_decode(raw)[0] if profile else json.loads(raw);assert v['completed_steps']=='480' and not v['failures'];assert v['execution']==dict(mode='cuda',device=0,threads=128);assert v['metadata']['debug_assertions'] is False
 return v
for n in [8000,110592]:
 ref=None
 for variant in ['control','diagnostic']:
  for kind in ['warmup','profile']:
   v=value_at(a/str(n)/variant/kind,kind=='profile');assert len(v['final_snapshot']['particles'])==n;v.pop('measurements');v['metadata'].pop('build_revision',None);finger=hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest();assert ref in [None,finger];ref=finger
 fingerprints[n]=ref
 db=sqlite3.connect(a/'activity.sqlite')
 for variant in ['control','diagnostic']:
  ops=['active','density-lambda','correction','mass-check','candidate','projection'] if variant=='control' else ['active','density','owner-prefix','squared-suffix','correction','mass-check','candidate','projection'];sorts=7 if n==8000 else 11
  labels=['acceleration','prediction','cells']+['spatial-sort']*sorts+['count','prefix-block','prefix-total','prefix-carry','fill','row-sort']+ops*8+['velocity'];ks=db.execute('SELECT step,operation,name,start_ns,end_ns FROM kernel WHERE variant=? AND particles=? ORDER BY start_ns',(variant,n)).fetchall();assert len(ks)==480*len(labels)
  for index,k in enumerate(ks):assert k[0]==index//len(labels)+1 and k[1]==labels[index%len(labels)]
  bands={}
  for lo,hi in [(1,480),(1,120),(241,480)]:bands[f'{lo}-{hi}']={op:sum(k[4]-k[3] for k in ks if lo<=k[0]<=hi and k[1]==op)/1e6/(hi-lo+1) for op in ops}
  assert bands==summary[str(n)][variant]['gpu_ms_per_step'];assert len(ks)==summary[str(n)][variant]['kernels']
 ref=None;pairs=[]
 for index in range(3):
  pair={}
  for variant in ['control','trial']:
   v=value_at(root/'trial-results'/f'{n}-{index}-{variant}');assert len(v['final_snapshot']['particles'])==n;pair[variant]=sum(s['total_s'] for s in v.pop('measurements')['steps']);v['metadata'].pop('build_revision',None);finger=hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest();assert ref in [None,finger];ref=finger
  if index:pairs.append(pair)
 trials[n]=pairs
assert json.loads((root/'trial-results/summary.json').read_text())=={str(n):v for n,v in trials.items()}
print(json.dumps(dict(profile_records=8,exploratory_records=12,profile_physical_sha256=fingerprints,exploratory_pairs=trials,attribution_recomputed=True),indent=2))
