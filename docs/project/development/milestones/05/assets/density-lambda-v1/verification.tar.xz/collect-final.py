from pathlib import Path
import json,hashlib,tarfile,subprocess
w=Path('/tmp/maelstrom-density-20261028');out=w/'retained-final';out.mkdir();members={}
def pack(name,files):
 with tarfile.open(out/name,'w:xz') as arc:
  for p in sorted(files):
   if p.is_file():
    rel=p.relative_to(w).as_posix();members[rel]=hashlib.sha256(p.read_bytes()).hexdigest();arc.add(p,arcname=rel,recursive=False)
# Record the diagnostic profile binding explicitly. Fresh PTX was also checked
# inside each executable before its initial capture by profile.py.
identities={}
for v in ['control','diagnostic']:
 ptx=w/(v+'-identity.ptx');args=['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)];p=subprocess.run(args,cwd=w/v,capture_output=True,timeout=180);assert p.returncode==0;binary=w/f'target-{v}/release/maelstrom';assert ptx.read_bytes() in binary.read_bytes()
 identities[v]=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),ptx_sha256=hashlib.sha256(ptx.read_bytes()).hexdigest(),fresh_ptx_embedded=True,hashes_recorded_after_profile=True,command=args,exit=p.returncode)
(w/'profile-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
# Bind the untouched exploratory source to its executable after primary timing.
ptx=w/'trial.ptx';args=['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)];p=subprocess.run(args,cwd=w/'trial',capture_output=True,timeout=180);assert p.returncode==0;binary=w/'target-trial/release/maelstrom';assert ptx.read_bytes() in binary.read_bytes() and ptx.read_bytes()==(w/'candidate.ptx').read_bytes();(w/'trial-identity.json').write_text(json.dumps(dict(command=args,exit=p.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),ptx_sha256=hashlib.sha256(ptx.read_bytes()).hexdigest(),fresh_ptx_embedded=True,ptx_equals_final_candidate=True,checked_after_exploration=True),indent=2)+'\n')
pack('observations.tar.xz',list((w/'measurements').rglob('*'))+list((w/'inputs').rglob('*')))
attribution=[p for p in (w/'attribution').rglob('*') if p.is_file() and p.suffix!='.nsys-rep' and (p.suffix!='.sqlite' or p.name=='activity.sqlite')]
pack('investigation.tar.xz',attribution+list((w/'trial-results').rglob('*'))+[w/n for n in ['profile.py','trial.py','trial-source.json','trial.patch','trial-build.log','trial-identity.json','diagnostic-source.json','diagnostic.patch','attribution-progress.log']])
pack('verification.tar.xz',list((w/'verification').rglob('*'))+list((w/'reference-verification').rglob('*'))+list((w/'postcheck').rglob('*'))+list((w/'local-verification').rglob('*'))+[w/n for n in ['verify.py','measure.py','audit.py','postcheck.py','reference-tests.py','resources.cpp','collect.py','verification-progress.log','measurement-progress.log','postcheck-progress.log','investigation-audit.py','investigation-audit.json','collect-final.py','profile-identities.json']])
(out/'files-sha256.json').write_text(json.dumps(members,indent=2)+'\n');print('Members:',len(members),flush=True)
