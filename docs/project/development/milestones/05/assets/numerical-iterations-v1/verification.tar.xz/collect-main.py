from pathlib import Path
import json,hashlib,tarfile
w=Path('/tmp/maelstrom-jacobi-power4-bits-20261027');out=w/'retained-main';out.mkdir();members={}
def pack(name,files):
 with tarfile.open(out/name,'w:xz') as arc:
  for p in sorted(files):
   if p.is_file():
    rel=p.relative_to(w).as_posix();members[rel]=hashlib.sha256(p.read_bytes()).hexdigest();arc.add(p,arcname=rel,recursive=False)
pack('observations.tar.xz',list((w/'measurements').rglob('*'))+list((w/'inputs').rglob('*')))
pack('verification.tar.xz',list((w/'verification').rglob('*'))+list((w/'power-qualification').rglob('*'))+list((w/'postcheck').rglob('*'))+list((w/'local-verification').rglob('*'))+[w/n for n in ['verify.py','measure.py','audit.py','postcheck.py','qualify-power.py','resources.cpp','retain-investigation.py','finalise-investigation.py','collect-main.py','verification-progress.log','measurement-progress.log','postcheck-progress.log','investigation-progress.log','investigation-final-progress.log']])
(out/'files-sha256.json').write_text(json.dumps(members,indent=2)+'\n');print('Main members',len(members),flush=True)
