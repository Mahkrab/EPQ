import os,subprocess,pathlib,json,time,hashlib
w=pathlib.Path('/tmp/maelstrom-jacobi-power4-bits-20261027'); logs=w/'verification';logs.mkdir(exist_ok=True)
env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
records=[]
def run(name,args,variant='candidate'):
 e=dict(env,CARGO_TARGET_DIR=str(w/f'target-{variant}')); t=time.monotonic();p=subprocess.run(args,cwd=w/variant,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=600)
 (logs/f'{name}.log').write_bytes(p.stdout); records.append(dict(name=name,args=args,variant=variant,exit=p.returncode,wall_s=time.monotonic()-t,sha256=hashlib.sha256(p.stdout).hexdigest()));(logs/'commands.json').write_text(json.dumps(records,indent=2)+'\n'); print(name,p.returncode,flush=True)
 if p.returncode: raise SystemExit(p.returncode)
cargo=['cargo','test','--release','--features','cuda','--locked','--offline']
run('control-binary',['cargo','build','--release','--features','cuda','--locked','--offline'],'control')
run('control-isolated-cli',cargo+['--test','cli_workflow','bundled_scenes_and_defaults_are_discoverable_outside_the_checkout'],'control')
run('candidate-suite',cargo+['--no-fail-fast'])
run('candidate-hardware-lib',cargo+['--lib','cuda::','--','--include-ignored','--test-threads=1'])
for target in ['cuda_boundary','cuda_execution']:
 run('candidate-'+target,cargo+['--test',target,'--','--include-ignored','--test-threads=1'])
run('candidate-clippy',['cargo','clippy','--release','--features','cuda','--locked','--offline','--all-targets','--','-D','warnings'])
run('candidate-format',['cargo','fmt','--check'])
run('native-build',['c++','-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I/usr/local/cuda/include','native/tests.cpp','-ldl','-o',str(w/'native-tests-final')])
run('native-sanitized',[str(w/'native-tests-final')])
run('candidate-binary',['cargo','build','--release','--features','cuda','--locked','--offline'])
run('control-native-build',['c++','-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I/usr/local/cuda/include','native/tests.cpp','-ldl','-o',str(w/'native-tests-control')],'control')
run('control-native',[str(w/'native-tests-control')],'control')
