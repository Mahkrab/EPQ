"""Bind and package all rejected investigations after final measurement."""
from pathlib import Path
import json,subprocess,time,hashlib,gzip,statistics,tarfile,shutil
base=Path('/tmp/maelstrom-jacobi-20261027');final=Path('/tmp/maelstrom-jacobi-power4-bits-20261027');out=final/'investigation';out.mkdir();common=json.loads((base/'control-source.json').read_text());records=[];summary={};members={}
variants=[('spatial',base,'trial','trial-results'),('pressure-cache',base,'pressure-trial','pressure-trial-results'),('warp-correction',base,'warp-trial','warp-trial-results'),('coefficients',base,'coeff-trial','coeff-trial-results'),('pair-validation',Path('/tmp/maelstrom-jacobi-fast-20261027'),'candidate','trial-results'),('row-validation',Path('/tmp/maelstrom-jacobi-row-20261027'),'candidate','trial-results'),('numerical-validation',Path('/tmp/maelstrom-jacobi-validated-20261027'),'candidate','trial-results'),('lambda-diagnostics',Path('/tmp/maelstrom-jacobi-lambda-20261027'),'candidate','trial-results'),('shared-tables',Path('/tmp/maelstrom-jacobi-tables-20261027'),'candidate','trial-results'),('floating-guard',Path('/tmp/maelstrom-jacobi-power4-20261027'),'candidate','trial-results'),('integer-guard',final,'exploratory-candidate','trial-results')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def command(label,args,cwd):
 t=time.monotonic();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=180);d=out/'identity-logs';d.mkdir(exist_ok=True);(d/(label+'.stdout')).write_bytes(p.stdout);(d/(label+'.stderr')).write_bytes(p.stderr);records.append(dict(label=label,command=args,exit=p.returncode,wall_s=time.monotonic()-t));(out/'identity-commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0,label
for label,w,variant,dirname in variants:
 d=out/label;d.mkdir();manifest=json.loads((w/(variant+'-source.json')).read_text());assert all(sha(w/variant/n)==h for n,h in manifest.items());(d/'source.json').write_text(json.dumps(manifest,indent=2)+'\n');patch=''
 for n in sorted(set(common)|set(manifest)):
  if common.get(n)==manifest.get(n):continue
  old=str(base/'control'/n) if n in common else '/dev/null';new=str(w/variant/n) if n in manifest else '/dev/null';p=subprocess.run(['diff','-u','--label','a/'+n,'--label','b/'+n,old,new],capture_output=True,text=True);assert p.returncode==1;patch+=p.stdout
 (d/'candidate.patch').write_text(patch)
 ptx=w/(variant+'-retained.ptx');command(label,['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)],w/variant)
 binary=w/('target-'+variant+'/release/maelstrom')
 if label=='integer-guard':binary=final/'target-candidate/release/maelstrom';assert ptx.read_bytes()==(final/'candidate.ptx').read_bytes()
 else:assert ptx.read_bytes() in binary.read_bytes()
 (d/'identity.json').write_text(json.dumps(dict(ptx_sha256=sha(ptx),binary_sha256=sha(binary),fresh_ptx_embedded=True,checked_after_exploration=True,integer_guard_binary_is_final_equivalent_ptx=label=='integer-guard'),indent=2)+'\n')
 shutil.copytree(w/dirname,d/'runs')
 script=w/('trial.py' if variant in ['candidate','trial','exploratory-candidate'] else variant+'.py');shutil.copy2(script,d/'collector.py')
 log=w/('trial-build.log' if variant in ['candidate','trial','exploratory-candidate'] else variant+'-build.log')
 if log.exists():shutil.copy2(log,d/'build.log')
 alias='candidate' if label=='integer-guard' else variant;data={}
 for n in [8000,110592]:
  ref=None;pairs=[]
  for i in range(3):
   pair={}
   for v in ['control',alias]:
    directory=d/'runs'/f'{n}-{i}-{v}';proc=json.loads((directory/'process.json').read_text());assert proc['exit']==0;value=json.loads(gzip.decompress((directory/'stdout.gz').read_bytes()));assert value['completed_steps']=='480' and not value['failures'];pair[v]=sum(step['total_s'] for step in value.pop('measurements')['steps']);value['metadata'].pop('build_revision',None);fingerprint=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest();assert ref in [None,fingerprint];ref=fingerprint
   if i:pairs.append(pair)
  med={v:statistics.median(p[v] for p in pairs) for v in ['control',alias]};data[n]=dict(pairs=pairs,median_s=med,median_reduction_percent=100*(1-med[alias]/med['control']),slower_pairs=sum(p[alias]>p['control'] for p in pairs))
 summary[label]=data
(out/'summary.json').write_text(json.dumps(dict(exploratory_records=132,variants=summary),indent=2)+'\n')
# Preserve the complete earlier, mixed coefficient-only primary campaign and its
# audit/qualification separately. Preliminary stage names keep their original labels.
shutil.copytree(base/'measurements',out/'coefficient-campaign/measurements');shutil.copytree(base/'inputs',out/'coefficient-campaign/inputs');shutil.copy2(base/'independent-audit.json',out/'coefficient-campaign/audit.json');shutil.copy2(base/'candidate-source.json',out/'coefficient-campaign/candidate-source.json');shutil.copy2(base/'candidate.patch',out/'coefficient-campaign/candidate.patch');shutil.copy2(base/'measure.py',out/'coefficient-campaign/collector.py');shutil.copy2(base/'audit.py',out/'coefficient-campaign/audit.py')
for name in ['verification','reference-verification','postcheck']:
 shutil.copytree(base/name,out/'coefficient-campaign'/name)
for p in (base/'profile-control').iterdir():
 if p.is_file() and p.suffix!='.nsys-rep' and (p.suffix!='.sqlite' or p.name.endswith('-activity.sqlite')):
  dest=out/'initial-profile'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
shutil.copy2(base/'profile.py',out/'initial-profile/collector.py');shutil.copy2(base/'protocol.md',out/'initial-protocol.md')
g=Path('/tmp/maelstrom-jacobi-power4-20261027');margins=out/'margins';margins.mkdir();shutil.copy2(g/'qualify-margins.py',margins/'collector.py');shutil.copy2(g/'power_exhaustive-final.cu',margins/'power_exhaustive.cu');shutil.copy2(g/'margins/commands.json',margins/'commands.json')
source_hashes={}
for power in [28,30,32,34,36]:
 src=g/'margins'/str(power);dest=margins/str(power);dest.mkdir();source_hashes[power]={n:sha(src/n) for n in ['power.cuh','power_exhaustive.cu','verify']}
 for p in src.iterdir():
  if p.suffix in ['.stdout','.stderr']:shutil.copy2(p,dest/p.name)
(margins/'source-hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
# Do not retain whole sources, native profiler reports, PTX or executables.
with tarfile.open(final/'investigation.tar.xz','w:xz') as arc:
 for p in sorted(out.rglob('*')):
  if p.is_file():
   rel=p.relative_to(final).as_posix();members[rel]=sha(p);arc.add(p,arcname=rel,recursive=False)
(final/'investigation-files.json').write_text(json.dumps(members,indent=2)+'\n');print('Investigation members',len(members),flush=True)
