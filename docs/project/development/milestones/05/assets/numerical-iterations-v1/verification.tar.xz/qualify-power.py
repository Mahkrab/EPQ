from pathlib import Path
import json,subprocess,time,hashlib
w=Path('/tmp/maelstrom-jacobi-power4-bits-20261027');out=w/'power-qualification';out.mkdir();records=[]
header=(w/'candidate/native/power.cuh').read_text();original=(w/'control/native/power.cuh').read_text();assert header.startswith(original.replace('float ordered_power(', 'float ordered_power_reference('))
manifest=json.loads((w/'candidate-source.json').read_text());assert all(hashlib.sha256((w/'candidate'/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
def run(label,args):
 t=time.monotonic();p=subprocess.run(args,cwd=w/'candidate',capture_output=True,timeout=180);elapsed=time.monotonic()-t
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);records.append(dict(label=label,command=args,exit=p.returncode,wall_s=elapsed,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0,(label,p.stderr);return p.stdout
binary=w/'power-exhaustive-final';run('build',['/usr/local/cuda/bin/nvcc','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/power_exhaustive.cu','-o',str(binary)])
results={}
for block in [32,64,128,256]:
 v=json.loads(run(str(block),[str(binary),str(block)]));assert v['input_words']==2**31 and v['mismatches']==0 and v['raw_quartic_mismatches']==354191 and v['guarded_words']==529216975 and v['threads']==block;results[block]=v
(out/'summary.json').write_text(json.dumps(dict(reference_body_unchanged=True,source_files=len(manifest),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),results=results),indent=2)+'\n')
