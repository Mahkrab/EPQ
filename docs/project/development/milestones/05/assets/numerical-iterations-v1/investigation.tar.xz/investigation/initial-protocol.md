# CUDA numerical iterations, 27 October 2026

Control is the exact retained 186-file neighbour-construction candidate, based on
Maelstrom 87145510a9e5d812066138c35f1fac82e4f593b0. Preserve all earlier dirty work,
Git states and installed commands. Do not pool earlier campaigns.

First collect ordinary-control full480step warmups/profiles at8000 and110592,
block128/refinement4/eight iterations. Attribute every kernel and each iteration;
report density/lambda together because they share one kernel. Initial collector
legacy labels multiplier/apply/planes/project mean density-lambda/mass-check/
candidate/projection respectively; derive these meanings from operations5..10.
Its GPU times exclude host gaps; its command wall time includes output compression.
Those command durations are not primary solver times.

First exploration: apply the prediction-cell permutation to active validation,
density/lambda and correction owners, preserving each ordered row and equations.
An explicit private group flag selects spatial versus identity scheduling; identity
mode remains available for component tests and caller-supplied rows. Keep candidate,
projection and mass-check assignments unchanged. Use existing buffer-layout padding,
no allocation or snapshot change. Run one warmup and two alternating exploratory
pairs per size using the fixed trial.py collector; retain all observations.
Profile correction and combined density/lambda before choosing any further rewrite.

Preserve binary32 equations and ordered-power bits, fixed membership/current-support
checks, sorted identity reductions, owner/prefix error precedence, global Jacobi
barriers, all eight iterations, refinement and convergence. Every stage's first
error still uses identity rather than executing-lane precedence. Retain cancellation
polls, panic/driver/allocator rollback, poison policy and accepted snapshots. No
approximation, reassociated reduction or fixed neighbour capacity is authorised.

Freeze final source (including tests/comments) and patch before qualification and
measurement. PC locked/offline precise compute_89 release builds, separate targets,
fresh exact embedded PTX correspondence, source/binary/input hashes. Qualify ordinary
suite, explicit CUDA library/boundary/integration, strict Clippy, formatting and native
ASan/UBSan. New tests compare both schedules bitwise for every intermediate and
multiple immutable snapshots, tails, dense/empty rows, all blocks and errors from
different stages/identities; use existing independent CPU component oracles too.
Run CPU feature isolation with invalid toolkit/compiler paths. Attempt device
sanitiser separately; failed support is no device-memory pass.

Final ordinary measurements: seven64..8000 regression trajectories480steps with
checkpoints0/1/120/240/480. Primary8000 with checkpoints,110592 without,110592 with
XSPH.01 and confinement.1 without. All are new simulations,480 unpaced steps,
device0,block128,refinement4,eight iterations,no graphics. One warmup per variant
then five alternating pairs, first measured candidate/control. Retain every slower
sample/failure, no replacements. Stop mismatches/incomplete runs. Compare canonical
physical/ordered diagnostic JSON exactly excluding measurements/build revision.
Record internal completed-step sums (validation/transfers/launch/completion/
cancellation/acceptance included); construction/teardown/audits/output excluded.
Keep monotonic child/collector durations distinct. Require4GiB host/2GiB GPU free,
timeout120s run,600s test,180s trace. Record environment and warning status.

After ordinary samples, separately trace full480steps for both variants and sizes,
without checkpoints. Retain privacy-limited API/kernel/copy rows and per-iteration,
early(1-120),late(241-480),full stage timing. Reconstruct exact schedule/launches/
transfer sizes and synchronisations; check profiled physical equivalence. Preserve
raw native reports on PC, not private metadata in the repository. Observe loaded
function resources outside timing; do not claim achieved occupancy from attributes.
Audit original outputs and all retained archive hashes, reconstruction/live source
identity. Report medians/ranges/paired changes, stage effects and memory/launch costs.
Follow performance-assessment.md with a written engineering decision, not a fixed
percentage rule. No other-device, device-loss, worst-case cancellation latency,
statistical significance or independent fluid-quality claims follow automatically.

## Exploratory follow-ups, before final qualification

Spatial-owner scheduling was mixed at110592 and slower at8000. A second trial
cached symmetric pressure in completed cell scratch during density and used a
reverse-row binary search in correction: all four pairs slowed. A third trial
used one warp per correction row and a serial ordered accumulation: small pairs
improved but both large pairs slowed. Preserve each immutable trial export hash,
patch and all observations; none is the final candidate. Their collectors fixed
one warmup and two alternating pairs before execution, using the same workloads.

The fourth trial hoists Poly6/Spiky coefficient values before density/lambda and
correction loops. Line-annotated control PTX showed constant coefficient div.rn
instructions still inside neighbour loops. Only values are hoisted; all original
checks remain at their original use sites, including early-return/lazy paths.
It adds no group flag, scratch, function lookup, launch or cancellation boundary.
All four exploratory pairs improved. Freeze this final source with a hardware
regression for underflow/overflow, inactive/empty rows and diagnostic precedence;
check the new regression against an isolated control plus only its test overlay.
Existing independent ordered CPU component tests cover all intermediate results,
power exponents and block sizes. The earlier planned schedule-comparison fixture
is superseded by these coefficient-specific checks; no rejected trial code is kept.
Final ordinary sampling and profiling plans above remain unchanged.
