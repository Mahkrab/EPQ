from pathlib import Path
import subprocess,json,time,hashlib
w=Path('/tmp/maelstrom-jacobi-power4-20261027');out=w/'margins';out.mkdir();records=[]
header=(w/'candidate/native/power.cuh').read_text();tool=(w/'power_exhaustive-final.cu').read_text()
for power in [28,30,32,34,36]:
 d=out/str(power);d.mkdir();(d/'power.cuh').write_text(header.replace('0x1p-28',f'0x1p-{power}'));(d/'power_exhaustive.cu').write_text(tool)
 for label,args in [('build',['/usr/local/cuda/bin/nvcc','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89',str(d/'power_exhaustive.cu'),'-o',str(d/'verify')]),('verify',[str(d/'verify')])]:
  t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=180);(d/(label+'.stdout')).write_bytes(p.stdout);(d/(label+'.stderr')).write_bytes(p.stderr);records.append(dict(power=power,label=label,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(power,label,p.returncode,p.stdout.decode()[:500],flush=True)
  if label=='build':assert p.returncode==0
