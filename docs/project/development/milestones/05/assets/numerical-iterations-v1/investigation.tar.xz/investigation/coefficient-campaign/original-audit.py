"""Read original observations independently of their timing collector."""
import pathlib,sys,json,gzip,hashlib,statistics,sqlite3,collections
r=pathlib.Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest()
for p in r.glob('**/process.json'):
 proc=json.loads(p.read_text());assert proc['exit']==0 and not proc['timed_out']
 for stream in ['stdout','stderr']:
  assert sha(gzip.decompress((p.parent/(stream+'.gz')).read_bytes()))==proc[stream+'_sha256']
identities=json.loads((r/'identities.json').read_text())
for name,expected in json.loads((r/'input-identities.json').read_text()).items():
 if name.startswith('control/'):
  assert identities['control']['source'][name.removeprefix('control/')]==expected
 else:assert sha((r.parent/name).read_bytes())==expected
assert identities['control']['ptx_sha256']!=identities['candidate']['ptx_sha256']
refs={};sample={};physical_runs=0
for p in sorted(r.glob('**/metrics.json')):
 d=p.parent;proc=json.loads((d/'process.json').read_text());assert proc['exit']==0 and not proc['timed_out'];raw=gzip.decompress((d/'stdout.gz').read_bytes());assert sha(raw)==proc['stdout_sha256'];assert sha(gzip.decompress((d/'stderr.gz').read_bytes()))==proc['stderr_sha256'];value=json.loads(raw);assert value['completed_steps']=='480' and not value['failures'];assert value['status'] in ['completed','completed_with_warnings'];assert value['execution']['mode']=='cuda' and value['execution']['device']==0 and value['execution']['threads']==128
 measured=value.pop('measurements');total=sum(x['total_s'] for x in measured['steps']);assert len(measured['steps'])==480
 value['metadata'].pop('build_revision',None);finger=sha(json.dumps(value,sort_keys=True,allow_nan=False).encode());rel=d.relative_to(r).parts;group='/'.join(rel[:2]) if rel[0]=='regression' else rel[0];assert refs.get(group,finger)==finger;refs[group]=finger
 entry=json.loads(p.read_text());assert entry['solver_s']==total and entry['physical_sha256']==finger
 if rel[1].startswith('sample-'):sample.setdefault(rel[0],{}).setdefault(rel[1],{})[rel[2]]=total
 physical_runs+=1
assert physical_runs==50 and len(refs)==10
summary={}
for workload,pairs in sample.items():
 assert len(pairs)==5;ordered=[pairs[f'sample-{i}'] for i in range(1,6)];totals={v:[p[v] for p in ordered] for v in ['control','candidate']};med={v:statistics.median(x) for v,x in totals.items()};summary[workload]=dict(samples_s=totals,median_s=med,ranges_s={v:[min(x),max(x)] for v,x in totals.items()},median_reduction_percent=100*(1-med['candidate']/med['control']),median_speedup=med['control']/med['candidate'],paired_reduction_percent=[100*(1-p['candidate']/p['control']) for p in ordered],slower_pairs=sum(p['candidate']>p['control'] for p in ordered))
assert summary==json.loads((r/'summary.json').read_text())
db=sqlite3.connect(r/'activity.sqlite');trace={}
for n,sorts in [(8000,7),(110592,11)]:
 labels=['acceleration','prediction','cells']+['spatial-sort']*sorts+['count','prefix-block','prefix-total','prefix-carry','fill','row-sort']+(['active','density-lambda','correction','mass-check','candidate','projection']*8)+['velocity'];width=len(labels);assert width==58+sorts
 trace[n]={}
 for v in ['control','candidate']:
  raw=gzip.decompress((r/f'trace/{n}/{v}/stdout.gz').read_bytes()).decode();value,offset=json.JSONDecoder().raw_decode(raw);assert value['completed_steps']=='480' and not value['failures'];value.pop('measurements');value['metadata'].pop('build_revision',None);finger=sha(json.dumps(value,sort_keys=True,allow_nan=False).encode())
  if v=='control':profile_finger=finger
  else:assert profile_finger==finger
  ks=db.execute('SELECT name,start_ns,end_ns,correlation FROM kernel WHERE variant=? AND particles=? ORDER BY start_ns',(v,n)).fetchall();assert len(ks)==480*width
  for i,k in enumerate(ks):
   label=labels[i%width];expected='observe_state' if label in ['acceleration','prediction'] else 'spatial_sort' if label=='spatial-sort' else 'prefix_counts' if label.startswith('prefix-') else 'solver';assert k[0]==expected,(i,k,label)
  # Correlate device activity with actual host calls, excluding private metadata.
  apis=db.execute('SELECT name,start_ns,end_ns,correlation FROM api WHERE variant=? AND particles=?',(v,n)).fetchall();byid={a[3]:a for a in apis};assert all('cuLaunchKernel' in byid[k[3]][0] for k in ks)
  waits=sum(a[0]=='cuStreamSynchronize' for a in apis);assert waits==480*21,waits
  copies=db.execute('SELECT start_ns,end_ns,bytes,copy_kind,correlation FROM memcpy WHERE variant=? AND particles=? ORDER BY start_ns',(v,n)).fetchall();kinds=collections.Counter(c[3] for c in copies);assert kinds=={1:3,2:480*26},kinds
  assert all(('cuMemcpyHtoD' if c[3]==1 else 'cuMemcpyDtoH') in byid[c[4]][0] for c in copies)
  h2d=sum(c[2] for c in copies if c[3]==1);d2h=sum(c[2] for c in copies if c[3]==2);b=(n+127)//128;expected_step=[16,32*b,8,32*b,16,8,8]+[32,16]*8+[8,12*n,12*n];assert len(expected_step)==26;assert [c[2] for c in copies if c[3]==2]==expected_step*480
  assert h2d==24*n+96 and d2h==480*(24*n+64*b+448)
  bands={}
  for start,end in [(1,480),(1,120),(241,480)]:
   times={label:sum(k[2]-k[1] for i,k in enumerate(ks) if start<=i//width+1<=end and labels[i%width]==label)/1e6/(end-start+1) for label in dict.fromkeys(labels)}
   times['jacobi-total']=sum(times[x] for x in ['active','density-lambda','correction','mass-check','candidate','projection']);times['prefix']=sum(times[x] for x in ['prefix-block','prefix-total','prefix-carry']);times['neighbour-total']=sum(times[x] for x in ['cells','spatial-sort','count','prefix','fill','row-sort']);times['neighbour-span']=sum(ks[step*width+labels.index('row-sort')][2]-ks[step*width+2][1] for step in range(start-1,end))/1e6/(end-start+1);bands[f'{start}-{end}']=times
  iterations={str(iteration+1):{label:sum(ks[step*width+9+sorts+iteration*6+offset][2]-ks[step*width+9+sorts+iteration*6+offset][1] for step in range(480))/480/1e6 for offset,label in enumerate(['active','density-lambda','correction','mass-check','candidate','projection'])} for iteration in range(8)}
  trace[n][v]=dict(gpu_ms_per_iteration=iterations,gpu_ms_per_step=bands,kernel_launches=len(ks),neighbour_launches_per_step=7+sorts,explicit_waits=waits,h2d_calls=3,d2h_calls=kinds[2],h2d_bytes=h2d,d2h_bytes=d2h,steady_transfer_bytes=24*n+64*b+448,profile_physical_sha256=finger)
explorations={}
for dirname,variant in [('trial-results','trial'),('pressure-trial-results','pressure-trial'),('warp-trial-results','warp-trial'),('coeff-trial-results','coeff-trial')]:
 root=r.parent/dirname;data={}
 for n in [8000,110592]:
  fingerprint=None;pairs=[]
  for index in range(3):
   pair={}
   for v in ['control',variant]:
    d=root/f'{n}-{index}-{v}';proc=json.loads((d/'process.json').read_text());assert proc['exit']==0;value=json.loads(gzip.decompress((d/'stdout.gz').read_bytes()));assert value['completed_steps']=='480' and not value['failures'];measured=value.pop('measurements');pair[v]=sum(step['total_s'] for step in measured['steps']);value['metadata'].pop('build_revision',None);actual=sha(json.dumps(value,sort_keys=True).encode());assert fingerprint in [None,actual];fingerprint=actual
   if index:pairs.append(pair)
  median={v:statistics.median(p[v] for p in pairs) for v in ['control',variant]};data[n]=dict(pairs=pairs,median_s=median,median_reduction_percent=100*(1-median[variant]/median['control']),slower_pairs=sum(p[variant]>p['control'] for p in pairs))
 explorations[variant]=data
result=dict(physical_records=physical_runs,physical_groups=len(refs),exploratory_records=48,explorations=explorations,timings=summary,traces=trace)
print(json.dumps(result,indent=2))
