from pathlib import Path
import shutil,json,hashlib,tarfile,subprocess
w=Path('/tmp/maelstrom-jacobi-power4-bits-20261027');out=w/'investigation';d=out/'coefficient-campaign';original=(d/'audit.py').read_text();shutil.copy2(d/'audit.py',d/'original-audit.py');portable=original.replace("root=r.parent/dirname;data={}","root=r.parent.parent/{'trial-results':'spatial','pressure-trial-results':'pressure-cache','warp-trial-results':'warp-correction','coeff-trial-results':'coefficients'}[dirname]/'runs';data={}");assert portable!=original;(d/'audit.py').write_text(portable)
p=subprocess.run(['python3',str(d/'audit.py'),str(d/'measurements')],capture_output=True,timeout=180);(d/'readback-audit.stdout').write_bytes(p.stdout);(d/'readback-audit.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr;assert json.loads(p.stdout)==json.loads((d/'audit.json').read_text())
# Record the portable path adaptation explicitly; observations are unchanged.
(d/'portable-reader.json').write_text(json.dumps(dict(change='Resolve earlier exploratory runs from their archived variant directories.',ordinary_observations_changed=False,reproduced_original_audit=True),indent=2)+'\n')
shutil.copy2(w/'finalise-investigation.py',out/'finalise-investigation.py')
members={}
with tarfile.open(w/'investigation.tar.xz','w:xz') as arc:
 for p in sorted(out.rglob('*')):
  if p.is_file():
   rel=p.relative_to(w).as_posix();members[rel]=hashlib.sha256(p.read_bytes()).hexdigest();arc.add(p,arcname=rel,recursive=False)
(w/'investigation-files.json').write_text(json.dumps(members,indent=2)+'\n');print('Final investigation members',len(members),flush=True)
