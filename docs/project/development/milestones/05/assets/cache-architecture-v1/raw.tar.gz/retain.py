import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import statistics
import subprocess
import tarfile

root = Path('/tmp/maelstrom-cache-review-20261110')
def sha(data): return hashlib.sha256(data).hexdigest()
def command(args): return subprocess.check_output(args,text=True).strip()
repository = Path.home()/'documents/programs/EPQ/Maelstrom'
tracked = command(['git','-C',str(repository),'ls-files']).splitlines()
identities = {}
changed = []
for path in tracked:
    exported = root/'source'/path
    if exported.is_file():
        code = exported.read_bytes()
        identities[path] = sha(code)
        if code != (repository/path).read_bytes(): changed.append(path)
extra = ['src/export/cache_review_probe.rs','src/bin/cache-review.rs']
for path in extra: identities[path] = sha((root/'source'/path).read_bytes())
ptx_files = list((root/'target/release/build').glob('maelstrom-*/out/*.ptx'))
ptx = [p for p in ptx_files if p.read_bytes() in (root/'target/release/maelstrom').read_bytes()]
if len(ptx)!=1: raise ValueError(f'expected one embedded PTX: {ptx}')
code = ptx[0].read_bytes()
if code not in (root/'target/release/cache-review').read_bytes(): raise ValueError('probe PTX differs')
identity = dict(base_commit=command(['git','-C',str(repository),'rev-parse','HEAD']),
    changed_tracked_paths=changed, extra_source_paths=extra, source_sha256=identities,
    ptx_sha256=sha(code),ptx_bytes=len(code),binary_sha256={name:sha((root/'target/release'/name).read_bytes()) for name in ['maelstrom','cache-review']},
    native_and_shader_files_identical_to_clean_base=all(not p.startswith(('native/','src/render/')) for p in changed))
(root/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
summary=json.loads((root/'summary.json').read_bytes())
details=[]
for case in summary:
    metrics={}
    for label,pattern in [('a','a-{i}'),('bake','b-{i}-bake'),('render','b-{i}-render'),('alt','b-{i}-render-alt'),('simulate','simulate-{i}')]:
        invocations=[]
        for i in range(1,4):
            path=root/case['scene']/pattern.format(i=i)/'gpu.csv'
            rows=[]
            for row in csv.reader(io.StringIO(path.read_text())):
                try: rows.append([float(v.strip()) for v in row[1:]])
                except ValueError: continue
            record=case['samples'][i][label]
            invocations.append(dict(round=i, wall_s=record['wall_s'],rss_mib=record['max_rss_kib']/1024,
                cpu_core_equivalents=(record['user_s']+record['system_s'])/record['wall_s'],samples=len(rows),
                mean_gpu_percent=statistics.mean(r[0] for r in rows), max_gpu_memory_mib=max(r[1] for r in rows),
                median_sm_clock_mhz=statistics.median(r[2] for r in rows)))
        metrics[label]=dict(median={key:statistics.median(r[key] for r in invocations) for key in ['wall_s','rss_mib','cpu_core_equivalents','mean_gpu_percent','max_gpu_memory_mib','median_sm_clock_mhz']},invocations=invocations)
    stages={}
    for path,keys in [('bake_profile',['solver_s','canonical_s','write_pack_hash_sync_s']),('render_profile',['graphics_readback_s','png_encoding_s','hashing_s','read_decode_validate_s','publication_s','progress_s','output_wait_s'])]:
        stages[path]={key:statistics.median(s[path][key] for s in case['samples'][1:]) for key in keys}
    data_bytes=case['samples'][1]['cache_bytes']
    details.append(dict(scene=case['scene'],metrics=metrics,stages=stages,cache_frame_bytes=data_bytes,
        pack_write_hash_sync_MB_s=data_bytes/stages['bake_profile']['write_pack_hash_sync_s']/1e6,
        warm_read_decode_validate_MB_s=data_bytes/stages['render_profile']['read_decode_validate_s']/1e6,
        break_even_same_resolution_presentations=(metrics['bake']['median']['wall_s']/(metrics['a']['median']['wall_s']-metrics['render']['median']['wall_s']) if metrics['a']['median']['wall_s']>metrics['render']['median']['wall_s'] else None)))
(root/'resource-summary.json').write_text(json.dumps(details,indent=2)+'\n')
env=dict(cpu=command(['bash','-c',"lscpu | sed -n 's/^Model name: *//p'"]),kernel=platform.release(),
    rustc=command(['rustc','-vV']),cargo=command(['cargo','-V']),cuda=command(['/usr/local/cuda/bin/nvcc','--version']),
    gpu=command(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader']),
    ram=command(['free','-b']),graphics=json.loads((root/'falling-block-20/a-1-bundle/manifest.json').read_bytes())['graphics'])
(root/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
files=[]
for path in root.rglob('*'):
    if not path.is_file(): continue
    rel=path.relative_to(root)
    if rel.parts[0] in ['source','target'] or path.suffix in ['.png','.bin','.pyc']: continue
    if any(p.endswith('-bundle') or p.endswith('-images') or p.endswith('-cache') or p=='library' for p in rel.parts): continue
    if rel.name in ['raw.tar.gz','raw-manifest.json','retain.py']: continue
    files.append(path)
files.append(root/'retain.py')
members=[]
with tarfile.open(root/'raw.tar.gz','w:gz') as archive:
    for path in sorted(set(files)):
        data=path.read_bytes(); rel=path.relative_to(root).as_posix()
        info=tarfile.TarInfo(rel);info.size=len(data);info.mtime=0;info.mode=0o644
        archive.addfile(info,io.BytesIO(data));members.append(dict(path=rel,bytes=len(data),sha256=sha(data)))
with tarfile.open(root/'raw.tar.gz') as archive:
    for member in members:
        data=archive.extractfile(member['path']).read()
        if len(data)!=member['bytes'] or sha(data)!=member['sha256']:raise ValueError('seal mismatch')
(root/'raw-manifest.json').write_text(json.dumps(dict(archive_sha256=sha((root/'raw.tar.gz').read_bytes()),members=members),indent=2)+'\n')
print(json.dumps(dict(files=len(members),archive_bytes=(root/'raw.tar.gz').stat().st_size,identity={k:v for k,v in identity.items() if k!='source_sha256'},resources=details),indent=2))
