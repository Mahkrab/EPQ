# GPU ranking follow-up

Declared after the host-coordination samples showed small pure-CPU fractions, before this capture.
Collect one control-only 110,592-particle disabled-effect, 480-step full-motion Nsight Systems trace.
Keep refinement 4, eight iterations, device zero, 128 threads, no checkpoints, no pacing and no rendering.
Use the already hashed control binary and input, verify exact physical/warning agreement with its warm-up,
and check the cooperative-sort launch, transfer and completion models independently. This trace ranks
remaining costs; do not pool its instrumented timing with ordinary or CPU-probe measurements.
