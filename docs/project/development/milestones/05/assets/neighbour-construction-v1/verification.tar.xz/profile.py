import pathlib,subprocess,time,json,gzip,sqlite3,hashlib,os,statistics
w=pathlib.Path('/tmp/maelstrom-neighbours-20261027');out=w/'profile-control';out.mkdir(exist_ok=False)
env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
def call(name,args,limit=180,cwd=w):
 t=time.monotonic();p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=limit);(out/(name+'.stdout.gz')).write_bytes(gzip.compress(p.stdout,mtime=0));(out/(name+'.stderr.gz')).write_bytes(gzip.compress(p.stderr,mtime=0));(out/(name+'.json')).write_text(json.dumps(dict(command=args,exit=p.returncode,wall_s=time.monotonic()-t),indent=2));assert p.returncode==0,name;return p.stdout
call('build',['cargo','build','--release','--features','cuda','--locked','--offline'],600,w/'control') if False else None
summary={};small=w/'control/scenes/falling-block-20.toml';large=w/'inputs/scenes/capacity-block-48.toml'
for n,scene,sorts in [(8000,small,7),(110592,large,11)]:
 args=[str(w/'target-control/release/maelstrom'),'run',str(scene),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure']
 call(f'{n}-warmup',args)
 prefix=out/str(n);call(f'{n}-trace',['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--output',str(prefix),*args]);call(f'{n}-export',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'])
 db=sqlite3.connect(str(prefix)+'.sqlite');ks=db.execute('SELECT s.value,k.start,k.end,k.correlationId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName ORDER BY k.start').fetchall();width=58+sorts;assert len(ks)==480*width,(len(ks),width)
 labels=['acceleration','prediction','cells']+['spatial-sort']*sorts+['count','prefix-block','prefix-total','prefix-carry','fill','row-sort']+(['active','multiplier','correction','apply','planes','project']*8)+['velocity'];assert len(labels)==width
 raw=sqlite3.connect(out/f'{n}-activity.sqlite');raw.execute('CREATE TABLE kernel(step INTEGER,operation TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)');raw.executemany('INSERT INTO kernel VALUES(?,?,?,?,?,?)',[(i//width+1,labels[i%width],*row) for i,row in enumerate(ks)]);raw.commit();raw.close()
 summary[n]={}
 for start,end in [(1,480),(1,120),(241,480)]:
  d={label:sum(k[2]-k[1] for i,k in enumerate(ks) if start<=i//width+1<=end and labels[i%width]==label)/1e6/(end-start+1) for label in dict.fromkeys(labels)};summary[n][f'{start}-{end}']=d
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(n,summary[n],flush=True)
