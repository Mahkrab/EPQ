from pathlib import Path
import tarfile,hashlib,json
w=Path('/tmp/maelstrom-neighbours-20261027');out=w/'retained-final';out.mkdir(exist_ok=False);members={}
def pack(name,paths):
 with tarfile.open(out/name,'w:xz') as arc:
  for p in sorted(paths):
   if p.is_file():
    rel=p.relative_to(w).as_posix();members[rel]=hashlib.sha256(p.read_bytes()).hexdigest();arc.add(p,arcname=rel,recursive=False)
pack('observations.tar.xz',list((w/'measurements').rglob('*'))+list((w/'inputs').rglob('*'))+list((w/'trial-results').rglob('*'))+[p for p in (w/'profile-control').iterdir() if p.suffix!='.nsys-rep' and (p.suffix!='.sqlite' or p.name.endswith('-activity.sqlite'))])
pack('verification.tar.xz',list((w/'verification').rglob('*'))+list((w/'local-verification').rglob('*'))+list((w/'postcheck').rglob('*'))+[w/name for name in ['collect.py','measure.py','verify.py','profile.py','trial.py','audit.py','postcheck-neighbours.py','resources.cpp','protocol.md','trial-source.json','trial-build.log','independent-audit.json','verification-progress.log','measurement-progress.log','postcheck-progress.log']])
(out/'files-sha256.json').write_text(json.dumps(members,indent=2)+'\n')
print(len(members),flush=True)
