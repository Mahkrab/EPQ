from pathlib import Path
import shutil,subprocess,time,os,json,hashlib
w=Path('/tmp/maelstrom-active-20261027');r=w/'reference-verification';r.mkdir();shutil.copytree(w/'control',w/'reference')
p=w/'reference/src/cuda/solver.rs';p.write_text(p.read_text()+'\n#[cfg(test)]\n#[path = "active_tests.rs"]\nmod active_tests;\n');shutil.copyfile(w/'candidate/src/cuda/active_tests.rs',w/'reference/src/cuda/active_tests.rs')
keys=set(json.loads((w/'control-source.json').read_text()))|{'src/cuda/active_tests.rs'};(r/'source.json').write_text(json.dumps({k:hashlib.sha256((w/'reference'/k).read_bytes()).hexdigest() for k in sorted(keys)},indent=2)+'\n')
a=['cargo','test','--release','--features','cuda','--locked','--offline','--lib','cuda::solver::active_tests::','--','--ignored','--test-threads=1'];env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',CARGO_TARGET_DIR=str(w/'target-reference'));t=time.monotonic();p=subprocess.run(a,cwd=w/'reference',env=env,capture_output=True,timeout=600)
(r/'stdout').write_bytes(p.stdout);(r/'stderr').write_bytes(p.stderr);(r/'command.json').write_text(json.dumps(dict(command=a,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()),indent=2)+'\n');assert p.returncode==0
