"""Retain bounded observations without private native profiler metadata."""
from pathlib import Path
import tarfile,json,hashlib,shutil
w=Path('/tmp/maelstrom-active-20261027');out=w/'retained';out.mkdir();members={}
def pack(name,paths):
 with tarfile.open(out/name,'w:xz') as arc:
  for p in sorted(set(paths)):
   if p.is_file():
    rel=p.relative_to(w).as_posix();members[rel]=hashlib.sha256(p.read_bytes()).hexdigest();arc.add(p,arcname=rel,recursive=False)
pack('observations.tar.xz',list((w/'measurements').rglob('*'))+list((w/'inputs').rglob('*')))
pack('initial-profile.tar.xz',list((w/'initial').rglob('*'))+[w/n for n in ['initial.py','initial-audit.py','initial-audit.json','initial-progress.log','control-build.log']])
pack('verification.tar.xz',list((w/'verification').rglob('*'))+list((w/'reference-verification').rglob('*'))+list((w/'postcheck').rglob('*'))+list((w/'local-verification').rglob('*'))+[w/n for n in ['measure.py','audit.py','verify.py','postcheck.py','resources.cpp','reference-tests.py','collect.py','verification-progress.log','reference-progress.log','measurement-progress.log','postcheck-progress.log','trial-tests.log','active-tests-initial.log','active-tests-corrected.log','preliminary-tests.json','preliminary-fixture-fix.patch']])
(out/'files-sha256.json').write_text(json.dumps(members,indent=2)+'\n');print('members',len(members),flush=True)
for name in ['control-source.json','candidate-source.json','control.patch','candidate.patch','protocol.md','independent-audit.json','initial-audit.json']:
 shutil.copyfile(w/name,out/name)
