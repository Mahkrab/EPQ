"""Record static driver-JIT resources separately from all timed requests."""
import hashlib,json
from pathlib import Path
from tools.performance.capture import invoke,write_json
work=Path('/tmp/maelstrom-compile-profile-20261026')
root=work/'results'
commands=(('resource-build',['c++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include',str(root/'resource-probe.cpp'),'-ldl','-o',str(work/'resource-probe')]),('resource-query',[str(work/'resource-probe'),str(work/'candidate-expected.ptx')]))
for label,command in commands:
 process,result=invoke(command,work,root/label,timeout=60)
 if process['exit_code'] != 0 or process['timed_out']:
  raise ValueError(label+' failed; attempt retained')
 if label=='resource-query':
  if result is None or result['launches']!=0 or result['attributes']['binary_version']!=89:
   raise ValueError('unexpected generated-code resource result')
write_json(root/'resource-identities.json',{'source_sha256':hashlib.sha256((root/'resource-probe.cpp').read_bytes()).hexdigest(),'ptx_sha256':hashlib.sha256((work/'candidate-expected.ptx').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((work/'resource-probe').read_bytes()).hexdigest(),'method':'cuModuleLoadData defaults; static resource and occupancy-limit queries; no launches'})
print(json.dumps(result))
