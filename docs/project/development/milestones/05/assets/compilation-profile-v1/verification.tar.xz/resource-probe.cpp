// Load the measured PTX through the production JIT path, then query static resources.
// No simulation kernel is launched. Occupancy is a resource bound, not achieved usage.
#include <cuda.h>
#include <dlfcn.h>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>

template<class T> T symbol(void* library, const char* name) {
    auto result = reinterpret_cast<T>(dlsym(library, name));
    if (!result) throw std::runtime_error(std::string("missing driver entry: ") + name);
    return result;
}
void check(CUresult code) {
    if (code != CUDA_SUCCESS) throw std::runtime_error("CUDA result " + std::to_string(code));
}
int main(int argc, char** argv) {
    if (argc != 2) return 2;
    try {
        std::ifstream stream(argv[1]);
        std::string ptx((std::istreambuf_iterator<char>(stream)), {});
        if (!stream || ptx.empty()) throw std::runtime_error("unable to read measured PTX");
        void* library = dlopen("libcuda.so.1", RTLD_NOW | RTLD_LOCAL);
        if (!library) throw std::runtime_error("CUDA driver unavailable");
        auto init = symbol<decltype(&cuInit)>(library, "cuInit");
        auto device_get = symbol<decltype(&cuDeviceGet)>(library, "cuDeviceGet");
        auto create = symbol<decltype(&cuCtxCreate)>(library, "cuCtxCreate_v4");
        auto destroy = symbol<decltype(&cuCtxDestroy)>(library, "cuCtxDestroy_v2");
        auto load = symbol<decltype(&cuModuleLoadData)>(library, "cuModuleLoadData");
        auto function = symbol<decltype(&cuModuleGetFunction)>(library, "cuModuleGetFunction");
        auto attribute = symbol<decltype(&cuFuncGetAttribute)>(library, "cuFuncGetAttribute");
        auto active = symbol<decltype(&cuOccupancyMaxActiveBlocksPerMultiprocessor)>(library, "cuOccupancyMaxActiveBlocksPerMultiprocessor");
        check(init(0));
        CUdevice device; check(device_get(&device, 0));
        CUcontext context; check(create(&context, nullptr, 0, device));
        struct Context { CUcontext value; decltype(destroy) release; ~Context() { release(value); } } cleanup{context, destroy};
        CUmodule module; check(load(&module, ptx.c_str()));
        CUfunction solver; check(function(&solver, module, "solver"));
        const CUfunction_attribute attributes[] = {CU_FUNC_ATTRIBUTE_MAX_THREADS_PER_BLOCK,
            CU_FUNC_ATTRIBUTE_SHARED_SIZE_BYTES, CU_FUNC_ATTRIBUTE_CONST_SIZE_BYTES,
            CU_FUNC_ATTRIBUTE_LOCAL_SIZE_BYTES, CU_FUNC_ATTRIBUTE_NUM_REGS,
            CU_FUNC_ATTRIBUTE_PTX_VERSION, CU_FUNC_ATTRIBUTE_BINARY_VERSION};
        const char* names[] = {"max_threads_per_block", "static_shared_bytes", "constant_bytes",
            "local_bytes_per_thread", "registers_per_thread", "ptx_version", "binary_version"};
        std::cout << "{\"kernel\":\"solver\",\"launches\":0,\"attributes\":{";
        for (int i = 0; i < 7; ++i) {
            int value; check(attribute(&value, attributes[i], solver));
            std::cout << (i ? "," : "") << '"' << names[i] << "\":" << value;
        }
        std::cout << "},\"active_blocks_per_sm_resource_bound\":{";
        bool first = true;
        for (int block : {32, 64, 128, 256}) {
            int value; check(active(&value, solver, block, 0));
            std::cout << (first ? "" : ",") << '"' << block << "\":" << value;
            first = false;
        }
        std::cout << "}}\n";
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
