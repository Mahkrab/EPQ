# Generated-module resource follow-up

Declared during compilation collection, before this probe is built or run. After the timed
campaign and its audit, load the already hashed candidate PTX through the same default
cuModuleLoadData path used by the production bridge. Query solver function resources and
active-block resource bounds at 32/64/128/256 threads. Launch no kernels, and run no simulation.
Capture compiler command, driver outcome and source/PTX identities. This provides static JIT
resource evidence, not achieved occupancy, cache counters or a new throughput measurement.
It neither replaces the campaign's physical checks nor changes its source or sampling protocol.
