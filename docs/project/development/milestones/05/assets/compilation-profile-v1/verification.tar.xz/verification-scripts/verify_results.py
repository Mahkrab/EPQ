"""Reconstruct the collection and require deliberately false evidence to fail."""
import copy
import hashlib
import json
from pathlib import Path
from unittest.mock import patch
from tests.performance import audit_compilation as reader
from tools.performance.capture import invoke, write_json

work = Path('/tmp/maelstrom-compile-profile-20261026')
root = work / 'results'
summary = json.loads((root / 'summary.json').read_bytes())
process, result = invoke(['python3', '-m', 'tests.performance.audit_compilation', str(root)], work / 'harness', root / 'independent-audit', timeout=600)
if process['exit_code'] != 0 or result is None:
    raise ValueError('independent raw reconstruction failed')
write_json(root / 'independent-audit.json', result)
controls = []

def reject(label, operation):
    try:
        operation()
    except ValueError as error:
        controls.append({'alteration': label, 'rejected': True, 'reason': str(error)})
    else:
        raise ValueError('negative control accepted: ' + label)

altered = copy.deepcopy(summary)
altered['headless']['8000']['32']['samples'][0]['solver_s'] += 1
reject('false headless solver sum', lambda: reader.audit(root, altered))
original_read = reader.read

def physical(directory):
    process, value = original_read(directory)
    if directory == root / 'headless/8000/32/sample-1':
        value['final_snapshot']['particles'][0]['position_m']['x'] += 1
    return process, value

with patch.object(reader, 'read', physical):
    reject('changed accepted particle position', lambda: reader.audit(root))
def wrong_effects(directory):
    process, value = original_read(directory)
    if directory == root / 'headless/8000/32/warmup':
        value['input']['configuration']['numerical']['xsph_viscosity_enabled'] = True
    return process, value

with patch.object(reader, 'read', wrong_effects):
    reject('wrong enabled fluid-effect workload', lambda: reader.audit(root))
altered = copy.deepcopy(summary)
altered['compile']['candidate-128-stride-1']['samples'][0]['components_s']['frame_hashing'] += 1
reject('false compile component summary', lambda: reader.audit(root, altered))
original_manifest = reader.retained_manifest

def wrong_scope(directory):
    value = original_manifest(directory)
    if directory == root / 'compile/candidate-128-stride-1/warmup':
        value['timing_profile']['boundary'] = 'whole_command'
    return value

with patch.object(reader, 'retained_manifest', wrong_scope):
    reject('profile claims the whole command', lambda: reader.audit(root))

def changed_frame(directory):
    value = original_manifest(directory)
    if directory == root / 'compile/candidate-256-stride-1/warmup':
        value['frames'][0]['snapshot_sha256'] = 'sha256:' + '0' * 64
    return value

with patch.object(reader, 'retained_manifest', changed_frame):
    reject('changed common-frame observation hash', lambda: reader.audit(root))
write_json(root / 'negative-controls.json', controls)
write_json(root / 'auditor-sha256.json', {p: hashlib.sha256((work / 'harness' / p).read_bytes()).hexdigest() for p in [q.relative_to(work / 'harness').as_posix() for q in sorted((work / 'harness/tests/performance').glob('*.py'))] + ['verify_results.py']})
print(json.dumps({'independent_audit': True, 'negative_controls_rejected': len(controls)}))
