"""Reconstruct physical/timing evidence and test false claims without altering it."""
import copy,hashlib,json
from pathlib import Path
from unittest.mock import patch
from tests.performance import audit_gradient_reassessment as reader
from tests.performance.audit_neighbour_bands import audit_trace
from tools.performance.capture import invoke,write_json
w=Path('/tmp/maelstrom-resident-state-20261027');root=w/'results'
p,result=invoke(['python3','-m','tests.performance.audit_gradient_reassessment',str(root)],w/'harness',root/'independent-audit',timeout=600)
if p['exit_code']!=0 or result is None:raise ValueError('independent audit failed')
write_json(root/'independent-audit.json',result)
summary=json.loads((root/'summary.json').read_bytes());controls=[]
def reject(label,operation):
 try:operation()
 except ValueError as error:controls.append({'alteration':label,'rejected':True,'reason':str(error)})
 else:raise ValueError('false evidence accepted: '+label)
value=copy.deepcopy(summary);value['workloads']['8000']['solver']['candidate_median_s']+=1
reject('false solver median',lambda:reader.audit(root,value))
value=copy.deepcopy(summary);value['workloads']['8000']['solver']['faster_pairs']+=1
reject('false faster-pair count',lambda:reader.audit(root,value))
original=reader.read
def changed(directory):
 p,v=original(directory)
 if directory==root/'paired/8000/control/sample-1':v['final_snapshot']['particles'][0]['position_m']['x']+=1
 return p,v
with patch.object(reader,'read',changed):reject('changed accepted particle position',lambda:reader.audit(root))
directory=root/'timelines/candidate';trace=json.loads((directory/'windows.json').read_bytes())
value=copy.deepcopy(trace);value['whole']['completion_count']+=1
reject('false completion summary',lambda:audit_trace(directory,value,row_sort=True,resident=True))
value=copy.deepcopy(trace);value['whole']['transfers']['host_to_device']['calls']+=1
reject('false upload summary',lambda:audit_trace(directory,value,row_sort=True,resident=True))
value=copy.deepcopy(trace);value['windows']['241-480']['operations_device_s']['7']+=1
reject('false evolved correction duration',lambda:audit_trace(directory,value,row_sort=True,resident=True))
write_json(root/'negative-controls.json',controls)
write_json(root/'auditor-sha256.json',{p.relative_to(w/'harness').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [*sorted((w/'harness/tests/performance').glob('*.py')),w/'harness/verify_results.py']})
print(json.dumps({'independent_audit':True,'negative_controls_rejected':len(controls)}))
