from pathlib import Path
import json,gzip,hashlib,sys
w=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/maelstrom-reprofile11-20261028');sha=lambda b:hashlib.sha256(b).hexdigest();records=0
for g in ['8000','110592','8000-effects','110592-effects']:
 expected=None
 for path in [w/f'final-profiles/trace/{g}/control',w/f'clean-profiles/ordinary/{g}/diagnostic',w/f'clean-profiles/trace/{g}/diagnostic']:
  rec=json.loads((path/'process.json').read_text());raw=gzip.decompress((path/'stdout.gz').read_bytes());err=gzip.decompress((path/'stderr.gz').read_bytes());assert rec['exit']==0 and sha(raw)==rec['stdout_sha256'] and sha(err)==rec['stderr_sha256'];value,_=json.JSONDecoder().raw_decode(raw.decode());value.pop('measurements');value['metadata'].pop('build_revision',None);assert value['completed_steps']=='480' and not value['failures'];fp=sha(json.dumps(value,sort_keys=True,allow_nan=False).encode());assert expected in [None,fp];expected=fp;records+=1
(w/'clean-audit.json').write_text(json.dumps(dict(records_compared=records,additional_exact_solver_records=8,total_unique_exact_solver_records=174,all_match=True),indent=2)+'\n')
print('clean observations exact')
