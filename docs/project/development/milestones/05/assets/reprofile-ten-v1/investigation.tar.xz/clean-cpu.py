"""Export solver-root CPU samples without process names, addresses or machine metadata."""
from pathlib import Path
import sqlite3,bisect,collections,json
w=Path('/tmp/maelstrom-reprofile11-20261028');out=sqlite3.connect(w/'clean-profiles/cpu.sqlite')
out.executescript('CREATE TABLE sample(workload TEXT,time_ns INTEGER,phase TEXT,state INTEGER);CREATE TABLE frame(workload TEXT,time_ns INTEGER,depth INTEGER,symbol TEXT,module TEXT);CREATE TABLE scheduler(workload TEXT,time_ns INTEGER,on_core INTEGER);')
summary={}
for name in ['8000','110592','8000-effects','110592-effects']:
 db=sqlite3.connect(w/f'clean-trace-{name}-diagnostic.sqlite');roots=db.execute("SELECT start,end,globalTid FROM NVTX_EVENTS WHERE text='solver-step' ORDER BY start").fetchall();assert len(roots)==480
 starts=[a for a,b,t in roots];tid=roots[0][2];phases=db.execute('SELECT start,end,COALESCE(n.text,s.value) FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE globalTid=? AND n.end IS NOT NULL',(tid,)).fetchall()
 phase_buckets=[[] for _ in roots]
 for a,b,label in phases:
  i=bisect.bisect_right(starts,a)-1
  if i>=0 and b<=roots[i][1]:phase_buckets[i].append((a,b,label))
 selected={};counts=collections.Counter();leaves=collections.Counter()
 for id,t,state in db.execute('SELECT id,start,threadState FROM COMPOSITE_EVENTS WHERE globalTid=? ORDER BY start',(tid,)):
  i=bisect.bisect_right(starts,t)-1
  if i<0 or t>=roots[i][1]:continue
  active=[(b-a,label) for a,b,label in phase_buckets[i] if a<=t<b];phase=min(active)[1] if active else 'unlabelled';selected[id]=t;counts[phase]+=1
  out.execute('INSERT INTO sample VALUES(?,?,?,?)',(name,t,phase,state))
 for id,depth,symbol,module in db.execute('SELECT c.id,c.stackDepth,s.value,m.value FROM SAMPLING_CALLCHAINS c LEFT JOIN StringIds s ON c.symbol=s.id LEFT JOIN StringIds m ON c.module=m.id ORDER BY c.id,c.stackDepth'):
  if id not in selected:continue
  module=Path(module or '').name;symbol='[unresolved]' if not symbol or symbol.startswith('0x') else symbol;out.execute('INSERT INTO frame VALUES(?,?,?,?,?)',(name,selected[id],depth,symbol,module))
  if depth==0:leaves[symbol]+=1
 for t,on in db.execute('SELECT start,isSchedIn FROM SCHED_EVENTS WHERE globalTid=? ORDER BY start',(tid,)):out.execute('INSERT INTO scheduler VALUES(?,?,?)',(name,t,on))
 summary[name]=dict(samples=len(selected),phase_samples=dict(counts.most_common()),leaf_samples=dict(leaves.most_common(30)))
 out.commit()
out.close();(w/'clean-cpu-analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
