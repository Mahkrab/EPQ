from pathlib import Path
import shutil,json,hashlib,subprocess,os
w=Path('/tmp/maelstrom-reprofile11-20261028');t=w/'trial-0';shutil.copytree(w/'control',t)
def replace(name,a,b):
 p=t/name;s=p.read_text();assert s.count(a)==1,(name,a);p.write_text(s.replace(a,b))
replace('native/solver.h','    std::uint32_t first_operation;','    std::uint32_t first_operation;\n    // Only a completed/submitted spatial sort establishes this permutation.\n    std::uint32_t spatial_rows;')
replace('native/bridge.cpp','    bool attempt_open = false;','    bool attempt_open = false;\n    bool spatial_rows = false;')
replace('native/bridge.cpp','        buffers.first_operation=grouped ? operation : 0;','        buffers.first_operation=grouped ? operation : 0;\n        buffers.spatial_rows=r.spatial_rows;\n        if (operation==2) r.spatial_rows=false;')
replace('native/bridge.cpp','    if (diagnostic && !status.code) {\n        // Stage order','    if (!status.code && operation==13) r.spatial_rows=true;\n    if (diagnostic && !status.code) {\n        // Stage order')
replace('native/solver.cu','    auto i=(operation==4 || operation==12) ? b.cells[lane].index','    // Scheduling changes only lane ownership, never row order or reductions.\n    auto i=(operation==4 || operation==12 ||\n        (b.spatial_rows && operation>=5 && operation<=8)) ? b.cells[lane].index')
manifest={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in t.rglob('*') if p.is_file()};(w/'trial-0-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=subprocess.run(['diff','-ruN',str(w/'control'),str(t)],capture_output=True);(w/'trial-0.patch').write_bytes(p.stdout)
env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',CARGO_TARGET_DIR=str(w/'target-trial-0'))
p=subprocess.run(['cargo','build','--release','--features','cuda','--locked','--offline'],cwd=t,env=env,capture_output=True);(w/'trial-build.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
