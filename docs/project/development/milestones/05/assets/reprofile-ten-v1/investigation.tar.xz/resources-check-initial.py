from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/tmp/maelstrom-reprofile11-20261028');deadline=time.monotonic()+900
while not (w/'device-checks-progress.log').exists() or 'initcheck 0' not in (w/'device-checks-progress.log').read_text():
 assert time.monotonic()<deadline;time.sleep(5)
records=[]
for v,ptx in [('control','control'),('trial-0','trial-0'),('candidate','candidate')]:
 binary=w/('resource-probe-'+v);args=['c++','-std=c++17','-O2','-DCANDIDATE','-I/usr/local/cuda/include','-I'+str(w/v),str(w/'resources.cpp'),'-ldl','-o',str(binary)];p=subprocess.run(args,capture_output=True);assert p.returncode==0,p.stderr
 p=subprocess.run([str(binary),str(w/(ptx+'.ptx'))],capture_output=True);assert p.returncode==0,p.stderr
 data=json.loads(p.stdout);records.append(dict(variant=v,resources=data,probe_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
(w/'resources.json').write_text(json.dumps(records,indent=2)+'\n')
