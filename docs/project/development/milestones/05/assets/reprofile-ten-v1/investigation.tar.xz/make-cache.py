from pathlib import Path
import shutil,json,hashlib,subprocess,os
w=Path('/tmp/maelstrom-reprofile11-20261028');t=w/'trial-cache';shutil.copytree(w/'control',t)
def change(n,a,b):
 p=t/n;s=p.read_text();assert a in s,(n,a);p.write_text(s.replace(a,b))
change('native/neighbours.cuh','Checked &c, bool fill) {','Checked &c, bool fill, unsigned int spatial_lane, bool cached=false) {')
change('native/neighbours.cuh','        while (lo<hi) { auto mid=lo+(hi-lo)/2; if (less(b.cells[mid],target)) lo=mid+1; else hi=mid; }','''        // Sorting finishes at the public base; its other half is dead until
        // the next discovery. Eight coalesced columns fit that existing space.
        auto *columns=reinterpret_cast<unsigned int *>(b.cells+s.padded);
        const auto column=static_cast<unsigned int>((x+1)*3+y+1);
        const auto address=static_cast<std::uint64_t>(column)*s.padded+spatial_lane;
        if (cached && column<8) lo=columns[address];
        else while (lo<hi) { auto mid=lo+(hi-lo)/2; if (less(b.cells[mid],target)) lo=mid+1; else hi=mid; }
        if (!fill && column<8) columns[address]=lo;''')
change('native/solver.cu','operation==4 || operation==12','operation==4 || operation==12 || operation==25')
change('native/solver.cu','discover_row(b,s,i,c,operation==12);','discover_row(b,s,i,c,operation!=4,static_cast<unsigned int>(lane),operation==25);')
change('native/bridge.cpp','operation>17 && operation!=24','operation>17 && operation!=24 && operation!=25')
change('native/bridge.cpp','|| operation==12) &&','|| operation==12 || operation==25) &&')
change('native/bridge.cpp','if (kernel_operation==12) {','if (kernel_operation==12 || kernel_operation==25) {')
change('src/cuda/solver.rs','        self.operation(*s, 12)','''        // Count cached eight column starts in the completed sort scratch.
        // Positions, width and cell order remain unchanged until fill finishes.
        self.operation(*s, 25)''')
f={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in t.rglob('*') if p.is_file()};(w/'trial-cache-source.json').write_text(json.dumps(f,indent=2)+'\n')
p=subprocess.run(['diff','-ruN',str(w/'control'),str(t)],capture_output=True);(w/'trial-cache.patch').write_bytes(p.stdout)
env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',CARGO_TARGET_DIR=str(w/'target-trial-cache'))
p=subprocess.run(['cargo','build','--release','--features','cuda','--locked','--offline'],cwd=t,env=env,capture_output=True);(w/'cache-build.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
s=(w/'trial.py').read_text().replace("r=w/'trial-results'","r=w/'cache-results'").replace('trial-0','trial-cache');(w/'cache-trial.py').write_text(s)
p=subprocess.run(['python3',str(w/'cache-trial.py')],stdout=open(w/'cache-progress.log','w'),stderr=subprocess.STDOUT);assert p.returncode==0
