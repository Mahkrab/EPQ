"""Bounded comparison of preserved solver trees on the primary PC."""
import os,subprocess,pathlib,json,time,hashlib,gzip,statistics,sqlite3,datetime
w=pathlib.Path('/tmp/maelstrom-fullprofile-20261028');r=w/'trial-results';r.mkdir(exist_ok=False)
env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def call(label,args,cwd=w,limit=120):
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();timed_out=False
 try:p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit)
 except subprocess.TimeoutExpired as error:
  p=subprocess.CompletedProcess(args,-1,error.stdout or b'',error.stderr or b'');timed_out=True
 child_wall_s=time.monotonic()-t
 dest=r/label;dest.mkdir(parents=True,exist_ok=False)
 for name,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  (dest/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 rec=dict(command=args,exit=p.returncode,timed_out=timed_out,wall_s=child_wall_s,collector_wall_s=time.monotonic()-t,start_utc=start,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr));write(dest/'process.json',rec)
 if p.returncode: raise RuntimeError(f'{label}: exit {p.returncode}')
 return p.stdout,rec
for label,args in [('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.free','--format=csv,noheader']),('cpu',['lscpu','--json']),('rust',['rustc','-Vv']),('cargo',['cargo','-V']),('nvcc',['/usr/local/cuda/bin/nvcc','--version']),('host-compiler',['c++','--version']),('nsys',['nsys','--version']),('memory',['cat','/proc/meminfo'])]:call('environment/'+label,args)
identities={}
for v in ['control','trial-0']:
 source=json.loads((w/(v+'-source.json')).read_text())
 for name,expected in source.items():assert sha((w/v/name).read_bytes())==expected,(v,name)
 binary=w/f'target-{v}/release/maelstrom';ptx=w/(v+'.ptx')
 call('identity/'+v,['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)],w/v)
 assert ptx.read_bytes() in binary.read_bytes()
 identities[v]=dict(binary_sha256=sha(binary.read_bytes()),ptx_sha256=sha(ptx.read_bytes()),source=source)
assert identities['control']['ptx_sha256']!=identities['trial-0']['ptx_sha256']
# Admission uses current free resources, without mixing measurements from devices.
available=int(next(line.split()[1] for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
gpu=gzip.decompress((r/'environment/gpu/stdout.gz').read_bytes()).decode();free_mib=int(gpu.strip().split(',')[-1].split()[0]);assert available>=4*1024**2 and free_mib>=2048
write(r/'resources.json',dict(host_available_kib=available,gpu_free_mib=free_mib))
write(r/'identities.json',identities)
# This scene is the existing counted capacity-block workload with unchanged defaults.
scene=w/'inputs/scenes/capacity-block-48.toml';scene.parent.mkdir(parents=True,exist_ok=True)
(w/'inputs/config').mkdir(exist_ok=True)
(w/'inputs/config/defaults-v4.toml').write_bytes((w/'control/config/defaults-v4.toml').read_bytes())
scene.write_text('''schema_version = 1
name = "capacity-block-48"
description = "Counted 48-by-48-by-48 diagnostic fluid block"
randomness = "none"
allow_coincident_particles = false
[configuration]
source = "file"
path = "../config/defaults-v4.toml"
[particles]
construction = "lattice"
first_identity = 0
origin_m = [0.2, 0.4, 0.2]
counts = [48, 48, 48]
spacing_m = 0.05
endpoint_rule = "counted_half_open"
order = "x_then_y_then_z"
initial_velocity_m_s = [0.0, 0.0, 0.0]
'''+''.join(f'\n[[planes]]\nnormal = {normal}\noffset_m = {offset}\n' for normal,offset in [([1.,0.,0.],0.),([-1.,0.,0.],-2.8),([0.,1.,0.],0.),([0.,-1.,0.],-3.),([0.,0.,1.],0.),([0.,0.,-1.],-2.8)]))
write(r/'input-identities.json',{str(p.relative_to(w)):sha(p.read_bytes()) for p in [scene,w/'inputs/config/defaults-v4.toml',*[w/f'control/scenes/falling-block-{s:02}.toml' for s in [4,6,8,10,12,16,20]]]})
def args(v,scene,observations=True,effects=False,steps=480):
 a=[str(w/f'target-{v}/release/maelstrom'),'run',str(scene),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps',str(steps),'--unpaced','--format','json','--quiet','--measure']
 if observations:a+=['--checkpoints','0,1,120,240,480']
 if effects:
  for value in ['xsph_viscosity_enabled=true','xsph_viscosity_coefficient=0.01','vorticity_confinement_enabled=true','vorticity_confinement_strength_m_s=0.1']:a+=['--set',value]
 return a

references={};results={}
for n,path in [(8000,w/'control/scenes/falling-block-20.toml'),(110592,scene)]:
 pairs=[]
 for index in range(3):
  order=['control','trial-0'] if index%2==0 else ['trial-0','control'];pair={}
  for v in order:
   raw,_=call(f'{n}/'+('warmup' if index==0 else f'pair-{index}')+'/'+v,args(v,path,False))
   value=json.loads(raw);m=value.pop('measurements');value['metadata'].pop('build_revision',None)
   fingerprint=sha(json.dumps(value,sort_keys=True).encode());assert references.get(n,fingerprint)==fingerprint;references[n]=fingerprint
   assert value['completed_steps']=='480' and not value['failures'] and len(value['final_snapshot']['particles'])==n
   pair[v]=sum(step['total_s'] for step in m['steps'])
  if index:pairs.append(pair)
  print(n,index,pair,flush=True)
 results[n]=pairs;write(r/'summary.json',results)
for v in ['control','trial-0']:
 for name,expected in identities[v]['source'].items():assert sha((w/v/name).read_bytes())==expected
