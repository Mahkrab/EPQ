"""Bounded comparison of preserved solver trees on the primary PC."""
import os,subprocess,pathlib,json,time,hashlib,gzip,statistics,sqlite3,datetime
w=pathlib.Path('/tmp/maelstrom-fullprofile-20261028');r=w/'profiles';r.mkdir(exist_ok=False)
env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def call(label,args,cwd=w,limit=120):
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();timed_out=False
 try:p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit)
 except subprocess.TimeoutExpired as error:
  p=subprocess.CompletedProcess(args,-1,error.stdout or b'',error.stderr or b'');timed_out=True
 child_wall_s=time.monotonic()-t
 dest=r/label;dest.mkdir(parents=True,exist_ok=False)
 for name,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  (dest/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 rec=dict(command=args,exit=p.returncode,timed_out=timed_out,wall_s=child_wall_s,collector_wall_s=time.monotonic()-t,start_utc=start,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr));write(dest/'process.json',rec)
 if p.returncode: raise RuntimeError(f'{label}: exit {p.returncode}')
 return p.stdout,rec
for label,args in [('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.free','--format=csv,noheader']),('cpu',['lscpu','--json']),('rust',['rustc','-Vv']),('cargo',['cargo','-V']),('nvcc',['/usr/local/cuda/bin/nvcc','--version']),('host-compiler',['c++','--version']),('nsys',['nsys','--version']),('memory',['cat','/proc/meminfo'])]:call('environment/'+label,args)

identities=json.loads((w/'baseline/identities.json').read_text());write(r/'identities.json',identities)
for v,d in identities.items():
 for name,expected in d['source'].items():assert sha((w/v/name).read_bytes())==expected
scene=w/'inputs/scenes/capacity-block-48.toml'
def args(v,path,obs,effects):
 a=[str(w/f'target-{v}/release/maelstrom'),'run',str(path),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure']
 if obs:a+=['--checkpoints','0,1,120,240,480']
 if effects:
  for value in ['xsph_viscosity_enabled=true','xsph_viscosity_coefficient=0.01','vorticity_confinement_enabled=true','vorticity_confinement_strength_m_s=0.1']:a+=['--set',value]
 return a
references={};totals={}
def check(name,raw):
 value,_=json.JSONDecoder().raw_decode(raw.decode());m=value.pop('measurements');value['metadata'].pop('build_revision',None);assert value['completed_steps']=='480' and not value['failures'];fp=sha(json.dumps(value,sort_keys=True).encode());assert references.get(name,fp)==fp,(name,'physical mismatch');references[name]=fp;return sum(step['total_s'] for step in m['steps'])
# Extend the unchanged primary protocol to quantify small-scene effects too.
small=w/'control/scenes/falling-block-20.toml'
for index in range(6):
 raw,_=call('8000-effects-baseline/'+('warmup' if not index else f'sample-{index}'),args('control',small,True,True));total=check('8000-effects',raw);totals.setdefault('8000-effects-baseline',[]).append(total)
 print('small-effects baseline',index,total,flush=True)
workloads=[('8000',small,True,False),('110592',scene,False,False),('8000-effects',small,True,True),('110592-effects',scene,False,True)]
activities=sqlite3.connect(r/'activity.sqlite')
activities.execute('CREATE TABLE api(workload TEXT,variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)')
activities.execute('CREATE TABLE kernel(workload TEXT,variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)')
activities.execute('CREATE TABLE memcpy(workload TEXT,variant TEXT,start_ns INTEGER,end_ns INTEGER,bytes INTEGER,copy_kind INTEGER,correlation INTEGER)')
activities.execute('CREATE TABLE memset(workload TEXT,variant TEXT,start_ns INTEGER,end_ns INTEGER,bytes INTEGER,correlation INTEGER)')
activities.execute('CREATE TABLE nvtx(workload TEXT,variant TEXT,text TEXT,start_ns INTEGER,end_ns INTEGER,global_tid INTEGER)')
for name,path,obs,effects in workloads:
 # Three interleaved pairs measure annotation/frame-pointer overhead without a profiler.
 for index in range(3):
  for v in (['control','diagnostic'] if index%2==0 else ['diagnostic','control']):
   raw,_=call(f'overhead/{name}/pair-{index+1}/{v}',args(v,path,obs,effects));total=check(name,raw);totals.setdefault(name,{}).setdefault('unprofiled-'+v,[]).append(total)
 # Ordinary CUDA-only tracing and richer labelled CPU tracing are separate captures.
 for v in ['control','diagnostic']:
  prefix=w/f'trace-{name}-{v}'
  flags=['--trace=cuda','--sample=none','--cpuctxsw=none'] if v=='control' else ['--trace=cuda,nvtx,osrt','--sample=process-tree','--cpuctxsw=process-tree','--backtrace=fp','--sampling-frequency=4000']
  raw,_=call(f'trace/{name}/{v}',['nsys','profile',*flags,'--force-overwrite=false','--output',str(prefix),*args(v,path,obs,effects),'--stage-profile'],limit=240)
  total=check(name,raw);totals[name]['profiled-'+v]=total
  call(f'export/{name}/{v}',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'],limit=240)
  with sqlite3.connect(str(prefix)+'.sqlite') as db:
   tables=[x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")];schema={t:[x[1] for x in db.execute('PRAGMA table_info('+t+')')] for t in tables};write(r/f'schema-{name}-{v}.json',schema)
   table='CUPTI_ACTIVITY_KIND_DRIVER' if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables else 'CUPTI_ACTIVITY_KIND_RUNTIME'
   rows=db.execute(f'SELECT s.value,a.start,a.end,a.correlationId FROM {table} a JOIN StringIds s ON s.id=a.nameId').fetchall();activities.executemany('INSERT INTO api VALUES (?,?,?,?,?,?,?)',[(name,v,*row) for row in rows])
   rows=db.execute('SELECT s.value,k.start,k.end,k.correlationId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName ORDER BY k.start').fetchall();activities.executemany('INSERT INTO kernel VALUES (?,?,?,?,?,?,?)',[(name,v,*row) for row in rows])
   rows=db.execute('SELECT start,end,bytes,copyKind,correlationId FROM CUPTI_ACTIVITY_KIND_MEMCPY').fetchall();activities.executemany('INSERT INTO memcpy VALUES (?,?,?,?,?,?,?)',[(name,v,*row) for row in rows])
   if 'CUPTI_ACTIVITY_KIND_MEMSET' in tables:
    rows=db.execute('SELECT start,end,bytes,correlationId FROM CUPTI_ACTIVITY_KIND_MEMSET').fetchall();activities.executemany('INSERT INTO memset VALUES (?,?,?,?,?,?)',[(name,v,*row) for row in rows])
   if 'NVTX_EVENTS' in tables:
    rows=db.execute('SELECT COALESCE(n.text,s.value),n.start,n.end,n.globalTid FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL').fetchall();activities.executemany('INSERT INTO nvtx VALUES (?,?,?,?,?,?)',[(name,v,*row) for row in rows])
  activities.commit();print('trace',name,v,total,flush=True)
 # These counters cover the entire child, including setup and JSON output; never label them solver-only.
 perf=w/f'perf-{name}.csv';raw,_=call('perf/'+name,['/usr/lib/linux-tools/6.8.0-147-generic/perf','stat','-x,','-e','task-clock,cycles,instructions,branches,branch-misses,cache-references,cache-misses,context-switches,page-faults','-o',str(perf),'--',*args('control',path,obs,effects)],limit=240);check(name,raw);(r/f'perf-{name}.csv').write_bytes(perf.read_bytes())
 write(r/'summary.json',dict(totals=totals,physical=references))
activities.close()
for v,d in identities.items():
 for name,expected in d['source'].items():assert sha((w/v/name).read_bytes())==expected
print('complete',flush=True)
