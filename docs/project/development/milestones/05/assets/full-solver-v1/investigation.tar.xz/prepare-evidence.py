"""Bind exploratory/diagnostic exports and retain only privacy-limited evidence."""
from pathlib import Path
import json,hashlib,difflib,subprocess,shutil,tarfile
w=Path('/tmp/maelstrom-fullprofile-20261028');sha=lambda b:hashlib.sha256(b).hexdigest()
# The completed trial export was restored after a separate test overlay; preserve both.
base=w/'trial-0';overlay=w/'trial-verification';keys=list(json.loads((w/'trial-0-source.json').read_text()))+['src/cuda/plane_tests.rs'];manifest={p:sha((overlay/p).read_bytes()) for p in sorted(keys)};(w/'trial-verification-source.json').write_text(json.dumps(manifest,indent=2)+'\n');patch=''
for p in manifest:
 old=(base/p).read_text() if (base/p).exists() else '';new=(overlay/p).read_text();patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p if old else '/dev/null',tofile='b/'+p))
(w/'trial-verification.patch').write_text(patch)
ptx=w/'trial-final-binding.ptx';args=['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)];p=subprocess.run(args,cwd=base,capture_output=True,timeout=120);assert p.returncode==0;binary=w/'target-trial-0/release/maelstrom';assert ptx.read_bytes() in binary.read_bytes();assert ptx.read_bytes()==(w/'candidate.ptx').read_bytes();(w/'trial-final-binding.json').write_text(json.dumps(dict(command=args,exit=0,binary_sha256=sha(binary.read_bytes()),ptx_sha256=sha(ptx.read_bytes()),ptx_equals_final_candidate=True),indent=2)+'\n')
for variant in ['control','candidate','diagnostic','candidate-diagnostic','trial-0','trial-verification']:
 source=json.loads((w/(variant+'-source.json')).read_text());assert all(sha((w/variant/p).read_bytes())==h for p,h in source.items()),variant
# Show rather than hide the one-pair small-scene checks.
reg={}
for side in [4,6,8,10,12,16,20]:
 n=side**3;d={v:json.loads((w/f'measurements/regression/{n}/{v}/metrics.json').read_text()) for v in ['control','candidate']};reg[n]=dict(control_s=d['control']['solver_s'],candidate_s=d['candidate']['solver_s'],reduction_percent=100*(1-d['candidate']['solver_s']/d['control']['solver_s']),exact_physical_match=d['candidate']['physical_sha256']==d['control']['physical_sha256'])
(w/'regression-summary.json').write_text(json.dumps(reg,indent=2)+'\n')
print('bindings verified',flush=True)
