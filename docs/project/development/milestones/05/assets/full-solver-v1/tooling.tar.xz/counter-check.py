"""Record current GPU counter permission failures without changing clocks/cache policy."""
from pathlib import Path
import subprocess,json,time,hashlib
w=Path('/tmp/maelstrom-fullprofile-20261028');r=w/'counter-check';r.mkdir();records=[];args=['/opt/nvidia/nsight-compute/2026.2.1/ncu','--nvtx','--nvtx-include','k_density_lambda_validation/','--launch-count','1','--set','full','--clock-control','none','--cache-control','none',str(w/'target-diagnostic/release/maelstrom'),'run',str(w/'control/scenes/falling-block-20.toml'),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','1','--unpaced','--format','json','--quiet']
for name,command in [('ordinary',args),('wsl-root',['/mnt/c/Windows/System32/wsl.exe','--user','root','--exec',*args])]:
 t=time.monotonic();p=subprocess.run(command,cwd=w,capture_output=True,timeout=600)
 for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/f'{name}.{stream}').write_bytes(data)
 denied=b'ERR_NVGPUCTRPERM' in p.stdout+p.stderr;records.append(dict(name=name,command=command,exit=p.returncode,wall_s=time.monotonic()-t,counters_permission_denied=denied,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,denied,flush=True)
