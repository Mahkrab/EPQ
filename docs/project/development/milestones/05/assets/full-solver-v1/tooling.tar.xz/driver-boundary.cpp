// Compare one Driver API workload on the same GPU through WSL and native Windows.
// This measures driver boundaries, not a native Windows port of the Rust solver.
#include <cuda.h>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#include <time.h>
#endif
#define FUNCTIONS(X) \
 X(cuInit,"cuInit") X(cuDeviceGet,"cuDeviceGet") X(cuCtxCreate,"cuCtxCreate_v4") \
 X(cuCtxDestroy,"cuCtxDestroy_v2") X(cuCtxPushCurrent,"cuCtxPushCurrent_v2") \
 X(cuCtxPopCurrent,"cuCtxPopCurrent_v2") X(cuModuleLoadData,"cuModuleLoadData") \
 X(cuModuleGetFunction,"cuModuleGetFunction") X(cuStreamCreate,"cuStreamCreate") \
 X(cuStreamSynchronize,"cuStreamSynchronize") X(cuMemAlloc,"cuMemAlloc_v2") \
 X(cuMemcpyHtoD,"cuMemcpyHtoD_v2") X(cuMemcpyDtoH,"cuMemcpyDtoH_v2") \
 X(cuLaunchKernel,"cuLaunchKernel")
struct Driver {
#ifdef _WIN32
 HMODULE library=LoadLibraryA("nvcuda.dll");
 void *symbol(const char *name){return reinterpret_cast<void *>(GetProcAddress(library,name));}
#else
 void *library=dlopen("libcuda.so.1",RTLD_NOW|RTLD_LOCAL);
 void *symbol(const char *name){return dlsym(library,name);}
#endif
#define FIELD(name,symbol) decltype(&name) name##_fn=nullptr;
 FUNCTIONS(FIELD)
#undef FIELD
 Driver(){if(!library)std::exit(2);
#define RESOLVE(name,label) name##_fn=reinterpret_cast<decltype(name##_fn)>(symbol(label));if(!name##_fn)std::exit(2);
 FUNCTIONS(RESOLVE)
#undef RESOLVE
 }
};
static void check(CUresult value){if(value!=CUDA_SUCCESS){std::fprintf(stderr,"CUDA failure %d\n",int(value));std::exit(3);}}
static std::uint64_t cpu_ns(){
#ifdef _WIN32
 FILETIME created,exited,kernel,user; if(!GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user))std::exit(4);
 ULARGE_INTEGER k{},u{};k.LowPart=kernel.dwLowDateTime;k.HighPart=kernel.dwHighDateTime;u.LowPart=user.dwLowDateTime;u.HighPart=user.dwHighDateTime;return (k.QuadPart+u.QuadPart)*100;
#else
 timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::exit(4);return std::uint64_t(t.tv_sec)*1000000000ULL+t.tv_nsec;
#endif
}
int main(int argc,char **argv){
 if(argc!=3){return 1;}
 const auto n=std::strtoull(argv[1],nullptr,10);const auto flags=static_cast<unsigned int>(std::strtoul(argv[2],nullptr,10));if((n!=8000 && n!=110592)||(flags!=0 && flags!=4))return 1;
 Driver d;check(d.cuInit_fn(0));CUdevice device;check(d.cuDeviceGet_fn(&device,0));CUcontext context;check(d.cuCtxCreate_fn(&context,nullptr,flags,device));
 const char ptx[]=".version 8.0\n.target sm_89\n.address_size 64\n.visible .entry tick(.param .u64 address) { .reg .u32 tid; .reg .pred other; .reg .u64 ptr; mov.u32 tid,%tid.x; setp.ne.u32 other,tid,0; @other bra done; ld.param.u64 ptr,[address]; st.global.u32 [ptr],0x13579bdf; done: ret; }\n";
 CUmodule module;CUfunction kernel;CUstream stream;check(d.cuModuleLoadData_fn(&module,ptx));check(d.cuModuleGetFunction_fn(&kernel,module,"tick"));check(d.cuStreamCreate_fn(&stream,CU_STREAM_DEFAULT));
 const std::size_t bytes=static_cast<std::size_t>(n)*12;CUdeviceptr memory;check(d.cuMemAlloc_fn(&memory,bytes));std::vector<unsigned char> host(bytes,0x5a);check(d.cuMemcpyHtoD_fn(memory,host.data(),bytes));void *args[]={&memory};
 auto launch=[&](){check(d.cuLaunchKernel_fn(kernel,1,1,1,128,1,1,0,stream,args,nullptr));};
 auto sync=[&](){check(d.cuStreamSynchronize_fn(stream));};
 for(int i=0;i<100;++i){launch();sync();}
#ifdef _WIN32
 const char *platform="windows-native";
#else
 const char *platform="wsl-linux";
#endif
 auto measure=[&](const char *label,std::size_t size,unsigned int repetitions,auto operation){
  const auto cpu_start=cpu_ns();const auto start=std::chrono::steady_clock::now();for(unsigned int i=0;i<repetitions;++i)operation();const double wall=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-start).count()/repetitions;const double cpu=double(cpu_ns()-cpu_start)/repetitions;
  std::printf("{\"platform\":\"%s\",\"particles\":%llu,\"flags\":%u,\"operation\":\"%s\",\"bytes\":%zu,\"repetitions\":%u,\"wall_ns_per_operation\":%.3f,\"thread_cpu_ns_per_operation\":%.3f}\n",platform,n,flags,label,size,repetitions,wall,cpu);
 };
 measure("launch-sync",0,2000,[&](){launch();sync();});
 measure("six-launches-sync",0,1000,[&](){for(int i=0;i<6;++i)launch();sync();});
 CUcontext previous;check(d.cuCtxPopCurrent_fn(&previous));
 measure("context-push-pop",0,10000,[&](){check(d.cuCtxPushCurrent_fn(context));check(d.cuCtxPopCurrent_fn(&previous));});
 for(std::size_t size:{std::size_t(8),std::size_t(32),static_cast<std::size_t>((n+127)/128)*32,bytes}){
  for(int i=0;i<10;++i){check(d.cuCtxPushCurrent_fn(context));check(d.cuMemcpyDtoH_fn(host.data(),memory,size));check(d.cuCtxPopCurrent_fn(&previous));}
  measure("bound-download",size,500,[&](){check(d.cuCtxPushCurrent_fn(context));check(d.cuMemcpyDtoH_fn(host.data(),memory,size));check(d.cuCtxPopCurrent_fn(&previous));});
 }
 std::uint32_t marker=0;std::memcpy(&marker,host.data(),sizeof(marker));if(marker!=0x13579bdf || host.back()!=0x5a)return 5;
 check(d.cuCtxDestroy_fn(context));return 0;
}
