"""Fresh explicit compiler receipts for the same-source platform control."""
from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/tmp/maelstrom-fullprofile-20261028');records=[]
commands=[['c++','--version'],['x86_64-w64-mingw32-g++-posix','--version'],['c++','-std=c++17','-O3','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include','driver-boundary.cpp','-ldl','-o','driver-boundary-linux-final'],['x86_64-w64-mingw32-g++-posix','-std=c++17','-O3','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include','driver-boundary.cpp','-static','-Wl,--no-insert-timestamp','-o','driver-boundary-final.exe']]
for i,args in enumerate(commands):
 t=time.monotonic();p=subprocess.run(args,cwd=w,capture_output=True,timeout=120)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(w/f'boundary-build-{i}.{label}').write_bytes(data)
 records.append(dict(command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));assert p.returncode==0,p.stderr
(w/'boundary-build.json').write_text(json.dumps(records,indent=2)+'\n')
