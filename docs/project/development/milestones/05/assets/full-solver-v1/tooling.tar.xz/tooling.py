"""Read back narrowly scoped profiling configuration and software identities."""
from pathlib import Path
import subprocess,json,time,base64,hashlib
w=Path('/tmp/maelstrom-fullprofile-20261028');r=w/'tooling';r.mkdir();records=[]
ps=r'''$changes = @(
 @('SOFTWARE\NVIDIA Corporation\GPUDebugger','EnableInterface'),
 @('SYSTEM\CurrentControlSet\Services\nvlddmkm','EnableDebugInterface'),
 @('SYSTEM\CurrentControlSet\Services\nvlddmkm\Global\NVTweak','RmProfilingAdminOnly')
)
$values = foreach ($entry in $changes) {
 $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($entry[0], $false)
 try { [pscustomobject]@{key=$entry[0];name=$entry[1];value=$key.GetValue($entry[1],$null)} } finally {if ($key) {$key.Dispose()}}
}
[pscustomobject]@{windows_version=[Environment]::OSVersion.VersionString;administrator=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator);session=(Get-Process -Id $PID).SessionId;values=$values;driver_state=(Get-Service nvlddmkm).Status.ToString();recovery_hive_unloaded= -not (Test-Path 'Registry::HKEY_LOCAL_MACHINE\MaelstromRecovery20261028')} | ConvertTo-Json -Depth 5
'''
commands=[('nsys',['nsys','--version']),('ncu',['/opt/nvidia/nsight-compute/2026.2.1/ncu','--version']),('compute-sanitizer',['/usr/local/cuda/bin/compute-sanitizer','--version']),('perf',['/usr/lib/linux-tools/6.8.0-147-generic/perf','--version']),('kernel',['uname','-r']),('packages',['dpkg-query','-W','-f=${Package} ${Version}\n','linux-tools-generic','linux-tools-6.8.0-147-generic','g++-mingw-w64-x86-64-posix']),('windows',['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(ps.encode('utf-16le')).decode()])]
for name,args in commands:
 t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=60)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/f'{name}.{label}').write_bytes(data)
 records.append(dict(name=name,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));assert p.returncode==0,(name,p.stderr)
(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
