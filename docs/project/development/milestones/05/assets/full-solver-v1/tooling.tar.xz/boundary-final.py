"""Same-source driver boundary control; this is not a Windows solver port."""
from pathlib import Path
import subprocess,time,json,hashlib,statistics,shutil
w=Path('/tmp/maelstrom-fullprofile-20261028');r=w/'boundary-final';r.mkdir();dest=Path('/mnt/c/Windows/Temp/maelstrom-fullprofile-20261028');dest.mkdir(exist_ok=True);shutil.copyfile(w/'driver-boundary-final.exe',dest/'driver-boundary-final.exe')
identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [w/'driver-boundary.cpp',w/'driver-boundary-linux-final',w/'driver-boundary-final.exe']};(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');records=[];samples={}
for n in [8000,110592]:
 for flags in [0,4]:
  for pair in range(6):
   for platform in (['linux','windows'] if pair%2==0 else ['windows','linux']):
    binary=w/'driver-boundary-linux-final' if platform=='linux' else dest/'driver-boundary-final.exe';args=[str(binary),str(n),str(flags)];t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=90);elapsed=time.monotonic()-t;name=f'{n}-{flags}-{pair}-{platform}'
    (r/(name+'.stdout')).write_bytes(p.stdout);(r/(name+'.stderr')).write_bytes(p.stderr);rec=dict(name=name,command=args,exit=p.returncode,wall_s=elapsed,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());records.append(rec);(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0,(name,p.stderr)
    values=[json.loads(line) for line in p.stdout.splitlines()];assert len(values)==7,(name,values)
    if pair:
     for value in values:
      key=f'{n}/{flags}/{platform}/{value["operation"]}/{value["bytes"]}';samples.setdefault(key,[]).append(value)
  print(n,flags,'complete',flush=True)
(r/'summary.json').write_text(json.dumps({k:dict(wall_ns=statistics.median(x['wall_ns_per_operation'] for x in v),cpu_ns=statistics.median(x['thread_cpu_ns_per_operation'] for x in v),samples=v) for k,v in samples.items()},indent=2)+'\n')
