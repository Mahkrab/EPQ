"""Compare teardown diagnostics and driver-reported static function resources."""
from pathlib import Path
import subprocess,json,time,hashlib,re
w=Path('/tmp/maelstrom-fullprofile-20261028');r=w/'postcheck';r.mkdir();records=[]
def call(name,args,cwd=w,expected=0):
 t=time.monotonic();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=180)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/f'{name}.{label}').write_bytes(data)
 records.append(dict(name=name,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==expected,(name,p.returncode,p.stderr);return p.stdout
leaks={}
for v,target in [('control','reference-plane'),('candidate','candidate')]:
 binary=list((w/f'target-{target}/release/deps').glob('maelstrom-13d7f2152309ef5d'))[0];raw=call(v+'-leak-observation',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','86','--leak-check','full','--print-limit','1',str(binary),'hardware_deferred_plane_failures_keep_error_priority_cancellation_and_retry','--ignored','--test-threads=1'],expected=86).decode();match=re.search(r'LEAK SUMMARY: ([0-9]+) bytes leaked in ([0-9]+) allocations',raw);assert match;errors=re.search(r'ERROR SUMMARY: ([0-9]+) errors',raw);assert int(errors[1])==int(match[2]);leaks[v]=dict(bytes=int(match[1]),allocations=int(match[2]),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
assert leaks['candidate']['allocations']==leaks['control']['allocations'];assert leaks['candidate']['bytes']-leaks['control']['bytes']==32*32
(r/'leak-comparison.json').write_text(json.dumps(dict(results=leaks,extra_bytes=1024,contexts=32,extra_requested_bytes_per_context=32,all_reported_errors_are_context_destruction_allocations=True),indent=2)+'\n')
for v in ['control','candidate']:
 binary=str(w/('resources-'+v));call(v+'-resource-build',['c++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-DCANDIDATE','-I/usr/local/cuda/include','-I'+str(w/v/'native'),str(w/'resources.cpp'),'-ldl','-o',binary]);call(v+'-resources',[binary,str(w/(v+'.ptx'))])
print('complete',flush=True)
