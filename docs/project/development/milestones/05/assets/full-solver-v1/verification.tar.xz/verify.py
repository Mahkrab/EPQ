"""Qualify the source freeze and failure boundaries before primary timing."""
import os,subprocess,pathlib,json,time,hashlib,shutil
w=pathlib.Path('/tmp/maelstrom-fullprofile-20261028');logs=w/'verification';logs.mkdir(exist_ok=True);env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'));records=[]
def run(name,args,v='candidate'):
 t=time.monotonic();p=subprocess.run(args,cwd=w/v,env=dict(env,CARGO_TARGET_DIR=str(w/f'target-{v}')),capture_output=True,timeout=600)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(logs/f'{name}.{label}').write_bytes(data)
 records.append(dict(name=name,command=args,variant=v,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(logs/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0,name
cargo=['cargo','test','--release','--features','cuda','--locked','--offline']
for target in ['cuda_boundary','cuda_execution']:run(target,cargo+['--test',target,'--','--include-ignored','--test-threads=1'])
run('clippy',['cargo','clippy','--release','--features','cuda','--locked','--offline','--all-targets','--','-D','warnings'])
run('format',['cargo','fmt','--check'])
for v in ['candidate','control']:
 binary=str(w/('native-tests-'+v));run(v+'-native-build',['c++','-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I/usr/local/cuda/include','native/tests.cpp','-ldl','-o',binary],v);run(v+'-native',[binary],v)
# The public error/cancellation fixture must also pass the pre-change solver.
overlay=w/'reference-plane';shutil.copytree(w/'control',overlay);shutil.copyfile(w/'candidate/src/cuda/plane_tests.rs',overlay/'src/cuda/plane_tests.rs');p=overlay/'src/cuda/solver.rs';p.write_text(p.read_text()+'\n#[cfg(test)]\n#[path="plane_tests.rs"]\nmod plane_tests;\n')
run('reference-plane-errors',cargo+['--lib','hardware_deferred_plane_failures_keep_error_priority_cancellation_and_retry','--','--ignored','--test-threads=1'],'reference-plane')
run('binary',['cargo','build','--release','--features','cuda','--locked','--offline'])
print('complete',flush=True)
