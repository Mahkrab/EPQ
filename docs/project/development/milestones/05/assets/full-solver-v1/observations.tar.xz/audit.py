"""Independently recalculate numerical identity, paired timing and GPU stage totals."""
from pathlib import Path
import json,gzip,hashlib,statistics,sqlite3,collections,sys
w=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/maelstrom-fullprofile-20261028');r=w/'measurements'
def sha(b):return hashlib.sha256(b).hexdigest()
refs={};samples={};records=0;warnings={}
for p in sorted(r.rglob('metrics.json')):
 folder=p.parent;process=json.loads((folder/'process.json').read_text());assert process['exit']==0 and not process['timed_out'];raw=gzip.decompress((folder/'stdout.gz').read_bytes());assert sha(raw)==process['stdout_sha256'];assert sha(gzip.decompress((folder/'stderr.gz').read_bytes()))==process['stderr_sha256'];value=json.loads(raw);m=value.pop('measurements');value['metadata'].pop('build_revision',None);fp=sha(json.dumps(value,sort_keys=True,allow_nan=False).encode());assert not value['failures'] and value['completed_steps']=='480';parts=folder.relative_to(r).parts;group='/'.join(parts[:2]) if parts[0]=='regression' else parts[0];assert refs.get(group,fp)==fp,(group,'physical mismatch');refs[group]=fp;entry=json.loads(p.read_text());total=sum(x['total_s'] for x in m['steps']);assert total==entry['solver_s'] and fp==entry['physical_sha256'];records+=1;warnings[group]=dict(status=value['status'],ordered_step_records=len(value['steps']))
 if parts[1].startswith('sample-'):samples.setdefault(group,{}).setdefault(parts[2],[]).append(total)
assert records==62,records
summary={}
for group,s in samples.items():
 a,b=s['control'],s['candidate'];assert len(a)==len(b)==5
 summary[group]=dict(control_median_s=statistics.median(a),candidate_median_s=statistics.median(b),control_range_s=[min(a),max(a)],candidate_range_s=[min(b),max(b)],median_reduction_percent=100*(1-statistics.median(b)/statistics.median(a)),paired_reductions_percent=[100*(1-y/x) for x,y in zip(a,b)],slower_pairs=sum(y>x for x,y in zip(a,b)))
# Activity attribution uses stream order, checked function names and exact launch counts.
db=sqlite3.connect(w/'final-profiles/activity.sqlite');stages={}
for group in ['8000','110592','8000-effects','110592-effects']:
 n=int(group.split('-')[0]);sorts=7 if n==8000 else 11;effects=group.endswith('effects');labels=['acceleration_cfl','prediction_bounds','cells']+['spatial_sort']*sorts+['neighbor_count','prefix_block','prefix_total','prefix_carry','neighbor_fill','row_sort']+['density_lambda_validation','publication','correction','physical_density_check','candidate','projection']*8+['velocity']+(['curl','confinement','velocity_replace','xsph','velocity_replace'] if effects else [])
 for v in ['control','candidate','candidate-diagnostic']:
  kernels=db.execute('SELECT name,start_ns,end_ns FROM kernel WHERE workload=? AND variant=? ORDER BY start_ns',(group,v)).fetchall();assert len(kernels)==480*len(labels)
  totals=collections.Counter();per_step=[]
  for step in range(480):
   sums=collections.Counter()
   for label,(name,a,b) in zip(labels,kernels[step*len(labels):(step+1)*len(labels)]):
    expected='observe_state' if label in ['acceleration_cfl','prediction_bounds'] else 'spatial_sort' if label=='spatial_sort' else 'prefix_counts' if label.startswith('prefix_') else 'solver';assert name==expected,(label,name,expected);assert b>=a;sums[label]+=b-a
   per_step.append({k:x/1e6 for k,x in sums.items()});totals.update(sums)
  api=dict(db.execute('SELECT name,count(*) FROM api WHERE workload=? AND variant=? GROUP BY name',(group,v)))
  copies=db.execute('SELECT copy_kind,count(*),sum(bytes) FROM memcpy WHERE workload=? AND variant=? GROUP BY copy_kind',(group,v)).fetchall()
  download=next(row for row in copies if row[0]==2);expected_copies=31 if effects else 26;expected_bytes=24*n+64*((n+127)//128)+448+(40 if effects else 0)+(16 if v!='control' else 0)
  assert download[1]==480*expected_copies and download[2]==480*expected_bytes,(group,v,download,expected_bytes)
  syncs=sum(count for name,count in api.items() if 'StreamSynchronize' in name);assert syncs==480*(26 if effects else 21),(group,v,syncs)
  stages[group+'/'+v]=dict(gpu_ms_per_step={k:x/480/1e6 for k,x in totals.items()},launches_per_step=len(labels),api_counts=api,copies=copies,downloads_per_step=expected_copies,download_bytes_per_step=expected_bytes,stream_syncs_per_step=syncs//480,stage_step_ranges_ms={k:dict(min=min(x[k] for x in per_step),median=statistics.median(x[k] for x in per_step),max=max(x[k] for x in per_step)) for k in totals})
# Validate all process outputs and physical identities in initial/profile/trial campaigns.
extra_counts={};all_physical={};solver_records=0
for folder in [p.parent for p in r.rglob('metrics.json')]:
 value=json.loads(gzip.decompress((folder/'stdout.gz').read_bytes()));value.pop('measurements');value['metadata'].pop('build_revision',None);key=sha(json.dumps({k:value[k] for k in ['input','request','execution']},sort_keys=True).encode());fp=sha(json.dumps(value,sort_keys=True).encode());assert all_physical.get(key,fp)==fp;all_physical[key]=fp;solver_records+=1
for campaign in ['baseline','profiles','trial-results','final-profiles']:
 count=0;failures=[]
 for p in (w/campaign).rglob('process.json'):
  rec=json.loads(p.read_text());dest=p.parent
  for stream in ['stdout','stderr']:
   assert sha(gzip.decompress((dest/(stream+'.gz')).read_bytes()))==rec[stream+'_sha256']
  if rec['exit']==0:
   raw=gzip.decompress((dest/'stdout.gz').read_bytes())
   try:value,_=json.JSONDecoder().raw_decode(raw.decode())
   except (ValueError,UnicodeDecodeError):value={}
   if isinstance(value,dict) and 'measurements' in value and 'final_snapshot' in value:
    value.pop('measurements');value['metadata'].pop('build_revision',None);assert not value['failures'] and value['completed_steps']=='480';key=sha(json.dumps({k:value[k] for k in ['input','request','execution']},sort_keys=True).encode());fp=sha(json.dumps(value,sort_keys=True).encode());assert all_physical.get(key,fp)==fp,(campaign,dest,'cross-campaign physical mismatch');all_physical[key]=fp;solver_records+=1
  if rec['exit']:failures.append(str(dest.relative_to(w)))
  else:count+=1
 extra_counts[campaign]=dict(successful_processes=count,failed_processes=failures)
out=dict(all_solver_records=solver_records,cross_campaign_physical_groups=len(all_physical),primary_records=records,physical_groups=len(refs),all_physical_outputs_exact=True,timing=summary,diagnostics=warnings,stage_attribution=stages,other_process_integrity=extra_counts)
(w/'independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(records=records,timing=summary,integrity=extra_counts),indent=2))
