"""Partition labelled solver wall time without adding overlapping GPU and API time."""
from pathlib import Path
import sqlite3,json,bisect,collections,gzip
w=Path('/tmp/maelstrom-fullprofile-20261028');db=sqlite3.connect(w/'final-profiles/activity.sqlite');output={}
def union(items):
 out=[]
 for a,b in sorted(items):
  if b<=a:continue
  if out and a<=out[-1][1]:out[-1]=(out[-1][0],max(b,out[-1][1]))
  else:out.append((a,b))
 return out
def length(items):return sum(b-a for a,b in union(items))
def difference(interval,mask):
 a,b=interval;cursor=a;total=0
 for x,y in mask:
  if y<=cursor:continue
  if x>=b:break
  total+=max(0,min(x,b)-cursor);cursor=max(cursor,y)
  if cursor>=b:break
 return total+max(0,b-cursor)
def api_class(name):
 if 'cuLaunchKernel' in name:return 'driver_launch_gpu_idle'
 if 'cuStreamSynchronize' in name:return 'driver_sync_gpu_idle'
 if 'cuMemcpy' in name:return 'driver_copy_gpu_idle'
 if 'cuCtxPush' in name or 'cuCtxPop' in name:return 'driver_binding_gpu_idle'
 if 'cuMemAlloc' in name or 'cuMemFree' in name:return 'driver_allocation_gpu_idle'
 return 'driver_other_gpu_idle'
host_labels=['host-input-validation','host-output-validation','host-plane-validation','host-particle-materialisation','host-snapshot-install','bounds-host-reduction','cuda-preparation','device-accept']
for workload in ['8000','110592','8000-effects','110592-effects']:
 n=int(workload.split('-')[0]);sorts=7 if n==8000 else 11;effects=workload.endswith('effects');variant='candidate-diagnostic'
 roots=db.execute("SELECT start_ns,end_ns,global_tid FROM nvtx WHERE workload=? AND variant=? AND text='solver-step' ORDER BY start_ns",(workload,variant)).fetchall();assert len(roots)==480
 starts=[a for a,b,t in roots];buckets=[dict(k=[],a=[],c=[],m=[],nv=[]) for _ in roots]
 for table,key,query in [('kernel','k','name,start_ns,end_ns,correlation'),('api','a','name,start_ns,end_ns,correlation'),('memcpy','c','copy_kind,start_ns,end_ns,bytes'),('memset','m','bytes,start_ns,end_ns,correlation'),('nvtx','nv','text,start_ns,end_ns,global_tid')]:
  for row in db.execute('SELECT '+query+' FROM '+table+' WHERE workload=? AND variant=? ORDER BY start_ns',(workload,variant)):
   i=bisect.bisect_right(starts,row[1])-1
   if i>=0 and row[2]<=roots[i][1]:buckets[i][key].append(row)
 labels=['acceleration_cfl','prediction_bounds','cells']+['spatial_sort']*sorts+['neighbor_count','prefix_block','prefix_total','prefix_carry','neighbor_fill','row_sort']+['density_lambda_validation','publication','correction','physical_density_check','candidate','projection']*8+['velocity']+(['curl','confinement','velocity_replace','xsph','velocity_replace'] if effects else [])
 totals=collections.Counter();api_totals=collections.Counter();leaf_times=collections.Counter();wait_overlap=0;running=off=0
 with sqlite3.connect(w/'final-profiles/cpu.sqlite') as native:
  sched=native.execute('SELECT time_ns,on_core FROM scheduler WHERE workload=? ORDER BY time_ns',(workload,)).fetchall();sched_starts=[t for t,state in sched]
 for step,(a,b,tid) in enumerate(roots):
  part=buckets[step];assert len(part['k'])==len(labels),(workload,step,len(part['k']),len(labels))
  gpu=union([(r[1],r[2]) for key in ['k','c','m'] for r in part[key]])
  assert length([(r[1],r[2]) for key in ['k','c','m'] for r in part[key]])==sum(r[2]-r[1] for key in ['k','c','m'] for r in part[key]),'device intervals overlap'
  for label,row in zip(labels,part['k']):totals['gpu_'+label]+=row[2]-row[1]
  for row in part['c']:totals['gpu_download' if row[0]==2 else 'gpu_upload']+=row[2]-row[1]
  for row in part['m']:totals['gpu_memset']+=row[2]-row[1]
  assert length([(r[1],r[2]) for r in part['a']])==sum(r[2]-r[1] for r in part['a']),'API intervals overlap'
  api_mask=union([(r[1],r[2]) for r in part['a']]);used=length(gpu)
  for name,x,y,corr in part['a']:
   idle=difference((x,y),gpu);totals[api_class(name)]+=idle;used+=idle;api_totals[name]+=y-x
   if 'cuStreamSynchronize' in name:wait_overlap+=(y-x)-idle
  allmask=union(gpu+api_mask);host_intervals=[]
  for text,x,y,ntid in part['nv']:
   if text in host_labels:
    value=difference((x,y),allmask);totals['cpu_'+text]+=value;used+=value;host_intervals.append((x,y));leaf_times[text]+=y-x
  assert length(host_intervals)==sum(y-x for x,y in host_intervals),'named host categories overlap'
  assert used<=b-a,(workload,step,used,b-a)
  totals['host_framework_and_instrumentation']+=b-a-used;totals['wall']+=b-a
  # Root marker executes on-core; scheduler transitions then partition its span.
  cursor=a;on=True;begin=bisect.bisect_left(sched_starts,a);end=bisect.bisect_left(sched_starts,b)
  for t,state in sched[begin:end]:
   if on:running+=t-cursor
   else:off+=t-cursor
   cursor=t;on=bool(state)
  if on:running+=b-cursor
  else:off+=b-cursor
 assert running+off==totals['wall']
 output[workload]=dict(wall_partition_ms_per_step={k:v/480/1e6 for k,v in totals.items()},ranked_wall_contributions=[dict(category=k,ms_per_step=v/480/1e6,percent=100*v/totals['wall']) for k,v in totals.most_common() if k!='wall'],api_inclusive_ms_per_step={k:v/480/1e6 for k,v in api_totals.items()},sync_gpu_overlap_ms_per_step=wait_overlap/480/1e6,scheduler_on_core_ms_per_step=running/480/1e6,scheduler_off_core_ms_per_step=off/480/1e6,host_named_range_ms_per_step={k:v/480/1e6 for k,v in leaf_times.items()},kernel_launches_per_step=len(labels))
print(json.dumps(output,indent=2))
