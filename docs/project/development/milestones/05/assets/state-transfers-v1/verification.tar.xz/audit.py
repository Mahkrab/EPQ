"""Recompute solver comparisons and transfer bytes from retained raw activity."""
from pathlib import Path
import gzip,hashlib,json,statistics,sqlite3,math,sys
root=Path(sys.argv[1]);seen={};timings={};runs=0
for process in sorted(root.glob('**/process.json')):
 rec=json.loads(process.read_text());out=gzip.decompress(process.with_name('stdout.gz').read_bytes());err=gzip.decompress(process.with_name('stderr.gz').read_bytes())
 assert hashlib.sha256(out).hexdigest()==rec['stdout_sha256']
 assert hashlib.sha256(err).hexdigest()==rec['stderr_sha256']
 assert rec['exit']==0 and not rec['timed_out'],process
 parts=process.relative_to(root).parts
 if parts[0] not in ['regression','8000','110592','110592-effects']:continue
 value=json.loads(out);assert value['completed_steps']=='480' and not value['failures']
 measurements=value.pop('measurements')
 expected_count=int(parts[1] if parts[0]=='regression' else parts[0].split('-')[0])
 assert len(value['input']['particles'])==expected_count and len(value['final_snapshot']['particles'])==expected_count
 assert value['execution']=={'mode':'cuda','device':0,'threads':128}
 assert not value['metadata']['debug_assertions'] and value['request']['steps']=='480'
 assert len(measurements['steps'])==480
 value['metadata'].pop('build_revision',None)
 key='/'.join(parts[:2]) if parts[0]=='regression' else parts[0]
 physical=json.dumps(value,sort_keys=True,allow_nan=False)
 assert physical==seen.setdefault(key,physical),(key,parts[2]);runs+=1
 if parts[0]!='regression' and parts[1]!='warmup':timings.setdefault(key,{})[(parts[1],parts[2])]=math.fsum(s['total_s'] for s in measurements['steps'])
summary=json.loads((root/'summary.json').read_text());recomputed={}
for key,values in timings.items():
 med={v:statistics.median(values[(f'sample-{i}',v)] for i in range(1,6)) for v in ['control','candidate']}
 pairs=[100*(1-values[(f'sample-{i}','candidate')]/values[(f'sample-{i}','control')]) for i in range(1,6)]
 for v in med:assert math.isclose(med[v],summary[key]['median_s'][v],rel_tol=1e-12)
 assert all(math.isclose(a,b,abs_tol=1e-10) for a,b in zip(pairs,summary[key]['paired_reduction_percent']))
 assert sum(x<0 for x in pairs)==summary[key]['slower_pairs']
 recomputed[key]=dict(median_s=med,speedup=med['control']/med['candidate'],reduction_percent=100*(1-med['candidate']/med['control']),paired_reduction_percent=pairs)
traces={}
with sqlite3.connect(root/'activity.sqlite') as db:
 for n,old_kernels,new_kernels in [(8000,62,65),(110592,66,69)]:
  traces[n]={};blocks=(n+127)//128
  for variant,per_step in [('control',old_kernels),('candidate',new_kernels)]:
   args=(variant,n)
   api=dict(db.execute('SELECT name,count(*) FROM api WHERE variant=? AND particles=? GROUP BY name',args))
   kernels=db.execute('SELECT name,count(*) FROM kernel WHERE variant=? AND particles=? GROUP BY name',args).fetchall()
   assert sum(count for _,count in kernels)==8*per_step
   assert api['cuStreamSynchronize']==168
   assert api['cuMemcpyDtoH_v2']==208 and api['cuMemcpyHtoD_v2']==(11 if variant=='control' else 3)
   by_name=dict(kernels)
   if variant=='candidate':assert by_name['observe_state']==16 and by_name['prefix_counts']==24
   copies=db.execute('SELECT copy_kind,count(*),sum(bytes) FROM memcpy WHERE variant=? AND particles=? GROUP BY copy_kind',args).fetchall()
   copied={kind:dict(count=count,bytes=byte_count) for kind,count,byte_count in copies}
   assert copied[1]['count']==api['cuMemcpyHtoD_v2'] and copied[2]['count']==api['cuMemcpyDtoH_v2']
   # Correlate each observed DtoH with its actual host call, then verify every
   # transfer against the fixed solver schedule rather than trusting totals.
   downloads=[row[0] for row in db.execute('SELECT m.bytes FROM memcpy m JOIN api a ON a.variant=m.variant AND a.particles=m.particles AND a.correlation=m.correlation WHERE m.variant=? AND m.particles=? AND m.copy_kind=2 ORDER BY a.start_ns',args)]
   expected=([8,12*n,8,12*n,8,8*(n+1),8] if variant=='control' else [16,32*blocks,8,32*blocks,16,8,8])+[32,16]*8+[8,12*n,12*n]
   assert len(expected)==26 and downloads==expected*8
   uploaded=[row[0] for row in db.execute('SELECT m.bytes FROM memcpy m JOIN api a ON a.variant=m.variant AND a.particles=m.particles AND a.correlation=m.correlation WHERE m.variant=? AND m.particles=? AND m.copy_kind=1 ORDER BY a.start_ns',args)]
   assert uploaded==[12*n,12*n,96]+([8*(n+1)]*8 if variant=='control' else [])
   htd_step=8*(n+1) if variant=='control' else 0
   bytes_step=sum(expected)+htd_step
   assert bytes_step==(64*n+440 if variant=='control' else 24*n+64*blocks+448)
   saved=json.loads((root/f'trace-{n}-{variant}-counts.json').read_text());assert api=={row[0]:row[1] for row in saved['api']}
   traces[n][variant]=dict(kernels_per_step=per_step,kernel_counts=dict(kernels),htod=copied[1],dtoh=copied[2],bytes_per_steady_step=bytes_step,transfers_per_steady_step=27 if variant=='control' else 26,synchronisations_per_step=21,initial_htod_bytes=24*n+96)
  old=traces[n]['control']['bytes_per_steady_step'];new=traces[n]['candidate']['bytes_per_steady_step']
  traces[n]['byte_reduction_percent']=100*(1-new/old)
print(json.dumps(dict(physical_runs=runs,exact_groups=len(seen),solver=recomputed,traces=traces),indent=2))
