"""Observe loaded kernel resources and attempt a device-memory diagnostic after timing."""
from pathlib import Path
import subprocess,json,time,re,hashlib,shutil
w=Path('/tmp/maelstrom-transfer-20261027');out=w/'postcheck';out.mkdir(exist_ok=False);records=[]
def run(label,args,timeout=180,cwd=None):
 t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=timeout,cwd=cwd)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 records.append(dict(label=label,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,flush=True);return p
for v in ['control','candidate']:
 args=['c++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include','-I'+str(w/v/'native'),str(w/'resources.cpp'),'-ldl','-o',str(w/('resources-'+v))]
 if v=='candidate':args+=['-DCANDIDATE']
 assert run(v+'-resources-build',args).returncode==0
 assert run(v+'-resources',[str(w/('resources-'+v)),str(w/(v+'.ptx'))]).returncode==0
text=(w/'verification/candidate-hardware-lib.log').read_text();binary=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',text).group(1)
p=run('device-memcheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','97',binary,'cuda::solver::observation_tests::','--ignored','--test-threads=1'])
if p.returncode==0:
 assert b'2 passed' in p.stdout and b'ERROR SUMMARY: 0 errors' in p.stderr+p.stdout
 assert run('device-racecheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','97',binary,'cuda::solver::observation_tests::','--ignored','--test-threads=1']).returncode==0

# Only the final neighbour-header comment differs from the measured source.
final=w/'final-check';shutil.copytree(w/'candidate',final)
assert run('comment-patch',['patch','--batch','-p1','-d',str(final),'-i',str(w/'comment-clarification.patch')]).returncode==0
assert run('final-comment-ptx',['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(w/'final.ptx')],cwd=final).returncode==0
assert (w/'final.ptx').read_bytes()==(w/'candidate.ptx').read_bytes()
manifest=json.loads((w/'final-source.json').read_text());assert all(hashlib.sha256((final/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
(out/'comment-clarification.json').write_text(json.dumps(dict(final_source_files=len(manifest),only_changed_file='native/neighbours.cuh',change='host prefixes -> prefix totals in comment',ptx_identical_to_measured_candidate=True,ptx_sha256=hashlib.sha256((w/'final.ptx').read_bytes()).hexdigest()),indent=2)+'\n')
