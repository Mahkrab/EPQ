// Compare one Driver API workload on the same GPU through WSL and native Windows.
// This measures driver boundaries, not a native Windows port of the Rust solver.
#include <cuda.h>
#include <nvtx3/nvToolsExt.h>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#include <time.h>
#endif
#define FUNCTIONS(X) \
 X(cuInit,"cuInit") X(cuDeviceGet,"cuDeviceGet") X(cuCtxCreate,"cuCtxCreate_v4") \
 X(cuCtxDestroy,"cuCtxDestroy_v2") X(cuCtxPushCurrent,"cuCtxPushCurrent_v2") \
 X(cuCtxPopCurrent,"cuCtxPopCurrent_v2") X(cuModuleLoadData,"cuModuleLoadData") \
 X(cuModuleGetFunction,"cuModuleGetFunction") X(cuStreamCreate,"cuStreamCreate") \
 X(cuStreamSynchronize,"cuStreamSynchronize") X(cuMemAlloc,"cuMemAlloc_v2") \
 X(cuMemcpyHtoD,"cuMemcpyHtoD_v2") X(cuMemcpyDtoH,"cuMemcpyDtoH_v2") \
 X(cuLaunchKernel,"cuLaunchKernel") X(cuMemAllocHost,"cuMemAllocHost_v2") \
 X(cuMemFreeHost,"cuMemFreeHost") X(cuMemcpyDtoHAsync,"cuMemcpyDtoHAsync_v2")
struct Driver {
#ifdef _WIN32
 HMODULE library=LoadLibraryA("nvcuda.dll");
 void *symbol(const char *name){return reinterpret_cast<void *>(GetProcAddress(library,name));}
#else
 void *library=dlopen("libcuda.so.1",RTLD_NOW|RTLD_LOCAL);
 void *symbol(const char *name){return dlsym(library,name);}
#endif
#define FIELD(name,symbol) decltype(&name) name##_fn=nullptr;
 FUNCTIONS(FIELD)
#undef FIELD
 Driver(){if(!library)std::exit(2);
#define RESOLVE(name,label) name##_fn=reinterpret_cast<decltype(name##_fn)>(symbol(label));if(!name##_fn)std::exit(2);
 FUNCTIONS(RESOLVE)
#undef RESOLVE
 }
};
static void check(CUresult value){if(value!=CUDA_SUCCESS){std::fprintf(stderr,"CUDA failure %d\n",int(value));std::exit(3);}}
static std::uint64_t cpu_ns(){
#ifdef _WIN32
 FILETIME created,exited,kernel,user; if(!GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user))std::exit(4);
 ULARGE_INTEGER k{},u{};k.LowPart=kernel.dwLowDateTime;k.HighPart=kernel.dwHighDateTime;u.LowPart=user.dwLowDateTime;u.HighPart=user.dwHighDateTime;return (k.QuadPart+u.QuadPart)*100;
#else
 timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::exit(4);return std::uint64_t(t.tv_sec)*1000000000ULL+t.tv_nsec;
#endif
}
int main() {
 Driver d;check(d.cuInit_fn(0));CUdevice device;check(d.cuDeviceGet_fn(&device,0));CUcontext context,removed;check(d.cuCtxCreate_fn(&context,nullptr,0,device));check(d.cuCtxPopCurrent_fn(&removed));
 constexpr unsigned repeats=100000;
 for(unsigned round=0;round<6;++round){const auto cpu=cpu_ns();const auto begin=std::chrono::steady_clock::now();for(unsigned i=0;i<repeats;++i){check(d.cuCtxPushCurrent_fn(context));check(d.cuCtxPopCurrent_fn(&removed));}const auto wall=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-begin).count()/repeats;const auto consumed=double(cpu_ns()-cpu)/repeats;if(removed!=context)return 5;std::printf("{\"round\":%u,\"warmup\":%s,\"pairs\":%u,\"wall_ns_per_pair\":%.3f,\"cpu_ns_per_pair\":%.3f}\n",round,round==0 ? "true" : "false",repeats,wall,consumed);}
 check(d.cuCtxDestroy_fn(context));return 0;
}
