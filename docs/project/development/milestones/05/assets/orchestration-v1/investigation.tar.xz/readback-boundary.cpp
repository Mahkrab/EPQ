// Compare one Driver API workload on the same GPU through WSL and native Windows.
// This measures driver boundaries, not a native Windows port of the Rust solver.
#include <cuda.h>
#include <nvtx3/nvToolsExt.h>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#include <time.h>
#endif
#define FUNCTIONS(X) \
 X(cuInit,"cuInit") X(cuDeviceGet,"cuDeviceGet") X(cuCtxCreate,"cuCtxCreate_v4") \
 X(cuCtxDestroy,"cuCtxDestroy_v2") X(cuCtxPushCurrent,"cuCtxPushCurrent_v2") \
 X(cuCtxPopCurrent,"cuCtxPopCurrent_v2") X(cuModuleLoadData,"cuModuleLoadData") \
 X(cuModuleGetFunction,"cuModuleGetFunction") X(cuStreamCreate,"cuStreamCreate") \
 X(cuStreamSynchronize,"cuStreamSynchronize") X(cuMemAlloc,"cuMemAlloc_v2") \
 X(cuMemcpyHtoD,"cuMemcpyHtoD_v2") X(cuMemcpyDtoH,"cuMemcpyDtoH_v2") \
 X(cuLaunchKernel,"cuLaunchKernel") X(cuMemAllocHost,"cuMemAllocHost_v2") \
 X(cuMemFreeHost,"cuMemFreeHost") X(cuMemcpyDtoHAsync,"cuMemcpyDtoHAsync_v2")
struct Driver {
#ifdef _WIN32
 HMODULE library=LoadLibraryA("nvcuda.dll");
 void *symbol(const char *name){return reinterpret_cast<void *>(GetProcAddress(library,name));}
#else
 void *library=dlopen("libcuda.so.1",RTLD_NOW|RTLD_LOCAL);
 void *symbol(const char *name){return dlsym(library,name);}
#endif
#define FIELD(name,symbol) decltype(&name) name##_fn=nullptr;
 FUNCTIONS(FIELD)
#undef FIELD
 Driver(){if(!library)std::exit(2);
#define RESOLVE(name,label) name##_fn=reinterpret_cast<decltype(name##_fn)>(symbol(label));if(!name##_fn)std::exit(2);
 FUNCTIONS(RESOLVE)
#undef RESOLVE
 }
};
static void check(CUresult value){if(value!=CUDA_SUCCESS){std::fprintf(stderr,"CUDA failure %d\n",int(value));std::exit(3);}}
static std::uint64_t cpu_ns(){
#ifdef _WIN32
 FILETIME created,exited,kernel,user; if(!GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user))std::exit(4);
 ULARGE_INTEGER k{},u{};k.LowPart=kernel.dwLowDateTime;k.HighPart=kernel.dwHighDateTime;u.LowPart=user.dwLowDateTime;u.HighPart=user.dwHighDateTime;return (k.QuadPart+u.QuadPart)*100;
#else
 timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::exit(4);return std::uint64_t(t.tv_sec)*1000000000ULL+t.tv_nsec;
#endif
}
int main() {
 Driver d;check(d.cuInit_fn(0));CUdevice device;check(d.cuDeviceGet_fn(&device,0));CUcontext context;check(d.cuCtxCreate_fn(&context,nullptr,0,device));
 const char ptx[]=".version 8.0\n.target sm_89\n.address_size 64\n.visible .entry tick(.param .u64 address,.param .u32 cycles,.param .u32 marker) { .reg .u32 tid,n,value; .reg .u64 ptr,begin,now,delta,limit; .reg .pred other,again; mov.u32 tid,%tid.x; setp.ne.u32 other,tid,0; @other bra done; ld.param.u32 n,[cycles]; cvt.u64.u32 limit,n; mov.u64 begin,%clock64; loop: mov.u64 now,%clock64; sub.u64 delta,now,begin; setp.lt.u64 again,delta,limit; @again bra loop; ld.param.u64 ptr,[address]; ld.param.u32 value,[marker]; st.global.u32 [ptr],value; done: ret; }\n";
 CUmodule module;CUfunction kernel;CUstream stream;check(d.cuModuleLoadData_fn(&module,ptx));check(d.cuModuleGetFunction_fn(&kernel,module,"tick"));check(d.cuStreamCreate_fn(&stream,CU_STREAM_DEFAULT));CUdeviceptr memory;check(d.cuMemAlloc_fn(&memory,32));
 std::uint32_t pageable[8]{};void *host=nullptr;check(d.cuMemAllocHost_fn(&host,32));auto pinned=static_cast<std::uint32_t *>(host);check(d.cuMemcpyHtoD_fn(memory,pageable,32));
 unsigned int cycles=0,marker=0;void *args[]={&memory,&cycles,&marker};CUcontext previous;check(d.cuCtxPopCurrent_fn(&previous));
 const char *names[]={"wait-pageable-copy","pageable-copy-wait","wait-pinned-copy","pinned-async-copy-wait"};
 constexpr unsigned int repetitions=200;
 for(unsigned int launches:{1U,4U}) for(unsigned int delay:{0U,250000U}) for(unsigned int round=0;round<6;++round) for(unsigned int order=0;order<4;++order) {
  const auto mode=round%2 ? 3-order : order;cycles=delay;unsigned long long checksum=0;
  char label[128];std::snprintf(label,sizeof(label),"%s/k%u/c%u/r%u",names[mode],launches,delay,round);nvtxRangePushA(label);
  const auto cpu_start=cpu_ns();const auto start=std::chrono::steady_clock::now();
  for(unsigned int iteration=0;iteration<repetitions;++iteration) {
   ++marker;check(d.cuCtxPushCurrent_fn(context));for(unsigned int k=0;k<launches;++k)check(d.cuLaunchKernel_fn(kernel,1,1,1,128,1,1,0,stream,args,nullptr));
   auto output=mode>=2 ? pinned : pageable;
   if(mode==0 || mode==2){check(d.cuStreamSynchronize_fn(stream));check(d.cuMemcpyDtoH_fn(output,memory,32));}
   else {if(mode==1)check(d.cuMemcpyDtoH_fn(output,memory,32));else check(d.cuMemcpyDtoHAsync_fn(output,memory,32,stream));check(d.cuStreamSynchronize_fn(stream));}
   if(output[0]!=marker){std::fprintf(stderr,"stale result: %s round%u cycles%u\n",names[mode],round,delay);return 5;}checksum+=output[0];check(d.cuCtxPopCurrent_fn(&previous));
  }
  const double wall=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-start).count()/repetitions;const double cpu=double(cpu_ns()-cpu_start)/repetitions;
  nvtxRangePop();
  std::printf("{\"mode\":\"%s\",\"launches\":%u,\"cycles\":%u,\"round\":%u,\"warmup\":%s,\"repetitions\":%u,\"wall_ns_per_group\":%.3f,\"cpu_ns_per_group\":%.3f,\"checksum\":%llu}\n",names[mode],launches,delay,round,round==0 ? "true" : "false",repetitions,wall,cpu,checksum);
 }
 check(d.cuCtxPushCurrent_fn(context));check(d.cuMemFreeHost_fn(host));check(d.cuCtxPopCurrent_fn(&previous));check(d.cuCtxDestroy_fn(context));return 0;
}
