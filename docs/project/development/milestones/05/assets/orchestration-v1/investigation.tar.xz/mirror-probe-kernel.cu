#include <cstdint>
struct Packet { unsigned long long words[4]; unsigned long long *host; };
extern "C" __global__ void mirror_errors(Packet *packet,unsigned count,unsigned slot,unsigned pattern) {
 const unsigned lane=blockIdx.x*blockDim.x+threadIdx.x;if(lane>=count)return;
 const auto row=(pattern&1) ? count-1-lane : lane;
 if((pattern&2) && row%3!=0)return;
 const auto value=(static_cast<unsigned long long>(row)<<32)|((row*37U+slot)%71U+1U);
 const auto previous=atomicMin(packet->words+slot,value);
 if(value<previous)atomicMin(packet->host+slot,value);
}
extern "C" __global__ void timing_counter(unsigned long long *counter,unsigned cycles) {
 if(threadIdx.x)return;const auto begin=clock64();while(clock64()-begin<cycles){}*counter+=1;
}
