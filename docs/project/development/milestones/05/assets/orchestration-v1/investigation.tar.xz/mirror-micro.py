"""Compare process-owned readback ordering before choosing a production change."""
from pathlib import Path
import subprocess,json,time,hashlib,statistics,gzip,sqlite3
w=Path('/tmp/maelstrom-orchestration-20261028');r=w/'mirror-micro';r.mkdir();records=[]
def run(name,args):
 t=time.monotonic();p=subprocess.run(args,cwd=w,capture_output=True,timeout=240)
 for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(name+'.'+stream+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 records.append(dict(name=name,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0,(name,p.stderr);return p.stdout
run('ptx',['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','mirror-probe-kernel.cu','-o','mirror-probe.ptx']);run('compiler',['c++','--version']);run('build',['c++','-std=c++17','-O3','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include','-I/opt/nvidia/nsight-systems/2026.1.3/target-linux-x64/nvtx/include','mirror-probe.cpp','-ldl','-o','mirror-probe'])
(r/'identity.json').write_text(json.dumps({p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in ['mirror-probe.cpp','mirror-probe-kernel.cu','mirror-probe.ptx','mirror-probe']},indent=2)+'\n')
raw=run('ordinary',[str(w/'mirror-probe'),str(w/'mirror-probe.ptx')]);all_values=[json.loads(line) for line in raw.splitlines()];values=[x for x in all_values if 'mode' in x];assert all_values[1]['stress_tests_passed']==1920;assert len(values)==48 and sum(x['warmup'] for x in values)==8
summary={}
for x in values:
 if not x['warmup']:summary.setdefault(f'{x["launches"]}/{x["cycles"]}/{x["mode"]}',[]).append(x['wall_ns_per_group'])
(r/'summary.json').write_text(json.dumps({k:dict(samples_ns=v,median_ns=statistics.median(v),min_ns=min(v),max_ns=max(v)) for k,v in summary.items()},indent=2)+'\n');print((r/'summary.json').read_text(),flush=True)
prefix=w/'mirror-micro-trace';run('trace',['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--force-overwrite=false','--output',str(prefix),str(w/'mirror-probe'),str(w/'mirror-probe.ptx')]);run('export',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'])
with sqlite3.connect(str(prefix)+'.sqlite') as db:
 tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")};api='CUPTI_ACTIVITY_KIND_DRIVER' if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables else 'CUPTI_ACTIVITY_KIND_RUNTIME';out=sqlite3.connect(r/'activity.sqlite')
 for table,query,cols in [('api',f'SELECT s.value,a.start,a.end,a.correlationId FROM {api} a JOIN StringIds s ON s.id=a.nameId','name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER'),('kernel','SELECT s.value,k.start,k.end,k.correlationId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName','name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER'),('copy','SELECT start,end,bytes,copyKind,correlationId FROM CUPTI_ACTIVITY_KIND_MEMCPY','start_ns INTEGER,end_ns INTEGER,bytes INTEGER,copy_kind INTEGER,correlation INTEGER'),('nvtx','SELECT COALESCE(n.text,s.value),n.start,n.end FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL','text TEXT,start_ns INTEGER,end_ns INTEGER')]:
  rows=db.execute(query).fetchall();out.execute('CREATE TABLE '+table+'('+cols+')');out.executemany('INSERT INTO '+table+' VALUES('+','.join('?' for _ in cols.split(','))+')',rows)
 out.commit();out.close()
print('complete',flush=True)
