"""Bounded comparison of preserved solver trees on the primary PC."""
import os,subprocess,pathlib,json,time,hashlib,gzip,statistics,sqlite3,datetime
w=pathlib.Path('/tmp/maelstrom-orchestration-20261028');r=w/'initial';r.mkdir(exist_ok=False)
env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def call(label,args,cwd=w,limit=120):
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();timed_out=False
 try:p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit)
 except subprocess.TimeoutExpired as error:
  p=subprocess.CompletedProcess(args,-1,error.stdout or b'',error.stderr or b'');timed_out=True
 child_wall_s=time.monotonic()-t
 dest=r/label;dest.mkdir(parents=True,exist_ok=False)
 for name,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  (dest/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 rec=dict(command=args,exit=p.returncode,timed_out=timed_out,wall_s=child_wall_s,collector_wall_s=time.monotonic()-t,start_utc=start,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr));write(dest/'process.json',rec)
 if p.returncode: raise RuntimeError(f'{label}: exit {p.returncode}')
 return p.stdout,rec
for label,args in [('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.free','--format=csv,noheader']),('cpu',['lscpu','--json']),('rust',['rustc','-Vv']),('cargo',['cargo','-V']),('nvcc',['/usr/local/cuda/bin/nvcc','--version']),('host-compiler',['c++','--version']),('nsys',['nsys','--version']),('memory',['cat','/proc/meminfo'])]:call('environment/'+label,args)
identities={}
for v in ['control','diagnostic']:
 source=json.loads((w/(v+'-source.json')).read_text())
 for name,expected in source.items():assert sha((w/v/name).read_bytes())==expected,(v,name)
 binary=w/f'target-{v}/release/maelstrom';ptx=w/(v+'.ptx')
 call('identity/'+v,['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)],w/v)
 assert ptx.read_bytes() in binary.read_bytes()
 identities[v]=dict(binary_sha256=sha(binary.read_bytes()),ptx_sha256=sha(ptx.read_bytes()),source=source)
assert identities['control']['ptx_sha256']==identities['diagnostic']['ptx_sha256']
# Admission uses current free resources, without mixing measurements from devices.
available=int(next(line.split()[1] for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
gpu=gzip.decompress((r/'environment/gpu/stdout.gz').read_bytes()).decode();free_mib=int(gpu.strip().split(',')[-1].split()[0]);assert available>=4*1024**2 and free_mib>=2048
write(r/'resources.json',dict(host_available_kib=available,gpu_free_mib=free_mib))
write(r/'identities.json',identities)
scene=w/'inputs/scenes/capacity-block-48.toml';small=w/'control/scenes/falling-block-20.toml'
inputs=[scene,w/'inputs/config/defaults-v4.toml',*[w/f'control/scenes/falling-block-{n:02}.toml' for n in [4,6,8,10,12,16,20]]];write(r/'inputs.json',{str(p.relative_to(w)):sha(p.read_bytes()) for p in inputs})
def args(v,path,obs,effects):
 a=[str(w/f'target-{v}/release/maelstrom'),'run',str(path),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure']
 if obs:a+=['--checkpoints','0,1,120,240,480']
 if effects:
  for value in ['xsph_viscosity_enabled=true','xsph_viscosity_coefficient=0.01','vorticity_confinement_enabled=true','vorticity_confinement_strength_m_s=0.1']:a+=['--set',value]
 return a
references={};totals={}
def check(name,raw):
 value,_=json.JSONDecoder().raw_decode(raw.decode());m=value.pop('measurements');value['metadata'].pop('build_revision',None);assert value['completed_steps']=='480' and not value['failures'];fp=sha(json.dumps(value,sort_keys=True).encode());assert references.get(name,fp)==fp,(name,'physical mismatch');references[name]=fp;return sum(step['total_s'] for step in m['steps'])
workloads=[('8000',small,True,False),('110592',scene,False,False),('8000-effects',small,True,True),('110592-effects',scene,False,True)]
for name,path,obs,effects in workloads:
 for index in range(4):
  raw,_=call('baseline/'+name+'/'+('warmup' if not index else f'sample-{index}'),args('control',path,obs,effects));t=check(name,raw);totals.setdefault(name,{}).setdefault('baseline',[]).append(t);print('baseline',name,index,t,flush=True)
activities=sqlite3.connect(r/'activity.sqlite')
for table in ['api(workload TEXT,variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)','kernel(workload TEXT,variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)','memcpy(workload TEXT,variant TEXT,start_ns INTEGER,end_ns INTEGER,bytes INTEGER,copy_kind INTEGER,correlation INTEGER)','memset(workload TEXT,variant TEXT,start_ns INTEGER,end_ns INTEGER,bytes INTEGER,correlation INTEGER)','nvtx(workload TEXT,variant TEXT,text TEXT,start_ns INTEGER,end_ns INTEGER,global_tid INTEGER)']:activities.execute('CREATE TABLE '+table)
for name,path,obs,effects in workloads:
 for index in range(3):
  for v in (['control','diagnostic'] if index%2==0 else ['diagnostic','control']):
   raw,_=call(f'overhead/{name}/pair-{index+1}/{v}',args(v,path,obs,effects));total=check(name,raw);totals[name].setdefault('unprofiled-'+v,[]).append(total)
 for v in ['control','diagnostic']:
  prefix=w/f'initial-{name}-{v}';flags=['--trace=cuda','--sample=none','--cpuctxsw=none'] if v=='control' else ['--trace=cuda,nvtx,osrt','--sample=process-tree','--cpuctxsw=process-tree','--backtrace=fp','--sampling-period=1000000']
  raw,_=call(f'trace/{name}/{v}',['nsys','profile',*flags,'--force-overwrite=false','--output',str(prefix),*args(v,path,obs,effects),'--stage-profile'],limit=240);totals[name]['profiled-'+v]=check(name,raw)
  call(f'export/{name}/{v}',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'],limit=240)
  with sqlite3.connect(str(prefix)+'.sqlite') as db:
   tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")};api='CUPTI_ACTIVITY_KIND_DRIVER' if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables else 'CUPTI_ACTIVITY_KIND_RUNTIME'
   queries=[('api',f'SELECT s.value,a.start,a.end,a.correlationId FROM {api} a JOIN StringIds s ON s.id=a.nameId'),('kernel','SELECT s.value,k.start,k.end,k.correlationId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName ORDER BY k.start'),('memcpy','SELECT start,end,bytes,copyKind,correlationId FROM CUPTI_ACTIVITY_KIND_MEMCPY'),('memset','SELECT start,end,bytes,correlationId FROM CUPTI_ACTIVITY_KIND_MEMSET')]
   if 'NVTX_EVENTS' in tables:queries.append(('nvtx','SELECT COALESCE(n.text,s.value),n.start,n.end,n.globalTid FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL'))
   for table,q in queries:
    rows=[(name,v,*row) for row in db.execute(q)];activities.executemany('INSERT INTO '+table+' VALUES ('+','.join('?' for _ in range(7 if table=='memcpy' else 6))+')',rows)
  activities.commit();print('trace',name,v,totals[name]['profiled-'+v],flush=True)
 write(r/'summary.json',dict(totals=totals,physical=references))
activities.close()
for v,d in identities.items():
 for p,h in d['source'].items():assert sha((w/v/p).read_bytes())==h
print('complete',flush=True)
