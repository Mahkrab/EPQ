from pathlib import Path
import sqlite3,json
w=Path('/tmp/maelstrom-orchestration-20261028');db=sqlite3.connect(w/'graph-micro/activity.sqlite');out={}
for label,a,b in db.execute('SELECT text,start_ns,end_ns FROM nvtx WHERE text LIKE ? ORDER BY start_ns',('%/k4/c0/r1',)):
 rows=db.execute('SELECT name,count(*),sum(end_ns-start_ns) FROM api WHERE start_ns>=? AND end_ns<=? GROUP BY name',(a,b)).fetchall();gpu=db.execute('SELECT sum(end_ns-start_ns) FROM kernel WHERE start_ns>=? AND end_ns<=?',(a,b)).fetchone()[0] or 0;dma=db.execute('SELECT sum(end_ns-start_ns) FROM copy WHERE start_ns>=? AND end_ns<=?',(a,b)).fetchone()[0] or 0
 out[label]=dict(wall_us_per_group=(b-a)/200/1000,gpu_kernel_us=None if label.startswith('graph') else gpu/200/1000,gpu_copy_us=None if label.startswith('graph') else dma/200/1000,gpu_node_activity_available=not label.startswith('graph'),api={name:dict(count_per_group=n/200,us_per_group=t/200/1000) for name,n,t in rows})
(w/'micro-api-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
