"""Queue latency and post-submission idle gaps overlap wall categories; never add them."""
from pathlib import Path
import sqlite3,bisect,json,statistics
w=Path('/tmp/maelstrom-orchestration-20261028');out={}
for folder,variant in [('initial','diagnostic')]:
 db=sqlite3.connect(w/folder/'activity.sqlite')
 for group in ['8000','110592','8000-effects','110592-effects']:
  kernels=db.execute('SELECT start_ns,end_ns,correlation FROM kernel WHERE workload=? AND variant=? ORDER BY start_ns',(group,variant)).fetchall();api={c:(a,b) for a,b,c in db.execute("SELECT start_ns,end_ns,correlation FROM api WHERE workload=? AND variant=? AND name LIKE '%cuLaunchKernel%'",(group,variant))};activity=[(a,b) for a,b,c in kernels]
  for table in ['memcpy','memset']:activity.extend(db.execute('SELECT start_ns,end_ns FROM '+table+' WHERE workload=? AND variant=?',(group,variant)))
  activity.sort();ends=[b for a,b in activity];starts=[a for a,b in activity];assert ends==sorted(ends)
  latency=[];ready=[];launch=[]
  for a,b,c in kernels:
   x,y=api[c];assert x<=a
   previous=bisect.bisect_left(starts,a)-1;previous_end=ends[previous] if previous>=0 else a
   latency.append(max(0,a-y));ready.append(max(0,a-max(y,previous_end)));launch.append(y-x)
  out[group+'/'+variant]=dict(kernel_count=len(kernels),launch_api_inclusive_ms_per_step=sum(launch)/480/1e6,positive_launch_return_to_gpu_start_ms_per_step=sum(latency)/480/1e6,post_submission_gpu_idle_ms_per_step=sum(ready)/480/1e6,median_post_submission_idle_us=statistics.median(ready)/1e3,note='Queue latency includes earlier stream work. Post-submission idle excludes earlier device activity but overlaps existing wall partition categories. No in-kernel memory-stall counters are available.')
(w/'queue-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
