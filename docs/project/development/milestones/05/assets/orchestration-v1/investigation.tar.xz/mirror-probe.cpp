// Compare one Driver API workload on the same GPU through WSL and native Windows.
// This measures driver boundaries, not a native Windows port of the Rust solver.
#include <cuda.h>
#include <nvtx3/nvToolsExt.h>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#include <time.h>
#endif
#define FUNCTIONS(X) \
 X(cuInit,"cuInit") X(cuDeviceGet,"cuDeviceGet") X(cuCtxCreate,"cuCtxCreate_v4") \
 X(cuCtxDestroy,"cuCtxDestroy_v2") X(cuCtxPushCurrent,"cuCtxPushCurrent_v2") \
 X(cuCtxPopCurrent,"cuCtxPopCurrent_v2") X(cuModuleLoadData,"cuModuleLoadData") \
 X(cuModuleGetFunction,"cuModuleGetFunction") X(cuStreamCreate,"cuStreamCreate") \
 X(cuStreamSynchronize,"cuStreamSynchronize") X(cuMemAlloc,"cuMemAlloc_v2") \
 X(cuMemcpyHtoD,"cuMemcpyHtoD_v2") X(cuMemcpyDtoH,"cuMemcpyDtoH_v2") \
 X(cuLaunchKernel,"cuLaunchKernel") X(cuMemAllocHost,"cuMemAllocHost_v2") \
 X(cuMemHostGetDevicePointer,"cuMemHostGetDevicePointer_v2") X(cuDeviceGetAttribute,"cuDeviceGetAttribute") X(cuMemFreeHost,"cuMemFreeHost") X(cuMemcpyDtoHAsync,"cuMemcpyDtoHAsync_v2")
struct Driver {
#ifdef _WIN32
 HMODULE library=LoadLibraryA("nvcuda.dll");
 void *symbol(const char *name){return reinterpret_cast<void *>(GetProcAddress(library,name));}
#else
 void *library=dlopen("libcuda.so.1",RTLD_NOW|RTLD_LOCAL);
 void *symbol(const char *name){return dlsym(library,name);}
#endif
#define FIELD(name,symbol) decltype(&name) name##_fn=nullptr;
 FUNCTIONS(FIELD)
#undef FIELD
 Driver(){if(!library)std::exit(2);
#define RESOLVE(name,label) name##_fn=reinterpret_cast<decltype(name##_fn)>(symbol(label));if(!name##_fn)std::exit(2);
 FUNCTIONS(RESOLVE)
#undef RESOLVE
 }
};
static void check(CUresult value){if(value!=CUDA_SUCCESS){std::fprintf(stderr,"CUDA failure %d\n",int(value));std::exit(3);}}
static std::uint64_t cpu_ns(){
#ifdef _WIN32
 FILETIME created,exited,kernel,user; if(!GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user))std::exit(4);
 ULARGE_INTEGER k{},u{};k.LowPart=kernel.dwLowDateTime;k.HighPart=kernel.dwHighDateTime;u.LowPart=user.dwLowDateTime;u.HighPart=user.dwHighDateTime;return (k.QuadPart+u.QuadPart)*100;
#else
 timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::exit(4);return std::uint64_t(t.tv_sec)*1000000000ULL+t.tv_nsec;
#endif
}

#include <fstream>
#include <iterator>
#include <string>
#include <limits>
int main(int argc,char **argv) {
 if(argc!=2)return 1;
 Driver d;check(d.cuInit_fn(0));CUdevice device;check(d.cuDeviceGet_fn(&device,0));CUcontext context;check(d.cuCtxCreate_fn(&context,nullptr,0,device));
 int map=0,uva=0,host_atomics=0;check(d.cuDeviceGetAttribute_fn(&map,CU_DEVICE_ATTRIBUTE_CAN_MAP_HOST_MEMORY,device));check(d.cuDeviceGetAttribute_fn(&uva,CU_DEVICE_ATTRIBUTE_UNIFIED_ADDRESSING,device));check(d.cuDeviceGetAttribute_fn(&host_atomics,CU_DEVICE_ATTRIBUTE_HOST_NATIVE_ATOMIC_SUPPORTED,device));std::printf("{\"capabilities\":{\"can_map_host\":%d,\"uva\":%d,\"host_native_atomics\":%d}}\n",map,uva,host_atomics);
 std::ifstream file(argv[1],std::ios::binary);if(!file)return 1;const std::string ptx((std::istreambuf_iterator<char>(file)),std::istreambuf_iterator<char>());
 CUmodule module;CUfunction errors,tick;CUstream stream;check(d.cuModuleLoadData_fn(&module,ptx.c_str()));check(d.cuModuleGetFunction_fn(&errors,module,"mirror_errors"));check(d.cuModuleGetFunction_fn(&tick,module,"timing_counter"));check(d.cuStreamCreate_fn(&stream,CU_STREAM_DEFAULT));
 void *host=nullptr;check(d.cuMemAllocHost_fn(&host,32));auto packet=static_cast<unsigned long long *>(host);CUdeviceptr mapped=0,diagnostic=0,counter=0;check(d.cuMemHostGetDevicePointer_fn(&mapped,host,0));check(d.cuMemAlloc_fn(&diagnostic,40));check(d.cuMemAlloc_fn(&counter,8));check(d.cuMemcpyHtoD_fn(diagnostic+32,&mapped,8));
 unsigned tests=0;
 for(unsigned threads:{32U,64U,128U,256U})for(unsigned count:{0U,1U,2U,31U,32U,33U,257U,513U,8000U,110592U})for(unsigned pattern=0;pattern<4;++pattern)for(unsigned slot=0;slot<4;++slot)for(unsigned repeat=0;repeat<3;++repeat){
  for(unsigned k=0;k<4;++k){packet[k]=~0ULL;}check(d.cuMemcpyHtoD_fn(diagnostic,packet,32));
  if(count){void *args[]={&diagnostic,&count,&slot,&pattern};check(d.cuLaunchKernel_fn(errors,(count+threads-1)/threads,1,1,threads,1,1,0,stream,args,nullptr));check(d.cuStreamSynchronize_fn(stream));}
  unsigned long long gpu[4]{};check(d.cuMemcpyDtoH_fn(gpu,diagnostic,32));
  for(unsigned k=0;k<4;++k){const auto expected=(count && k==slot) ? slot+1ULL : ~0ULL;if(packet[k]!=expected || gpu[k]!=expected){std::fprintf(stderr,"mirror mismatch: block%u n%u pattern%u slot%u repeat%u\n",threads,count,pattern,slot,repeat);return 5;}}
  ++tests;
 }
 std::printf("{\"stress_tests_passed\":%u}\n",tests);
 unsigned long long expected_counter=0;check(d.cuMemcpyHtoD_fn(counter,&expected_counter,8));CUcontext previous;check(d.cuCtxPopCurrent_fn(&previous));
 constexpr unsigned repetitions=200;
 for(unsigned launches:{1U,4U})for(unsigned cycles:{0U,250000U})for(unsigned round=0;round<6;++round)for(unsigned order=0;order<2;++order){
  const auto mirrored=bool(round%2 ? 1-order : order);char label[128];std::snprintf(label,sizeof(label),"%s/k%u/c%u/r%u",mirrored ? "mirror" : "copy",launches,cycles,round);nvtxRangePushA(label);
  const auto cpu_start=cpu_ns();const auto start=std::chrono::steady_clock::now();
  for(unsigned iteration=0;iteration<repetitions;++iteration){
   check(d.cuCtxPushCurrent_fn(context));void *args[]={&counter,&cycles};for(unsigned k=0;k<launches;++k)check(d.cuLaunchKernel_fn(tick,1,1,1,128,1,1,0,stream,args,nullptr));check(d.cuStreamSynchronize_fn(stream));
   unsigned long long copied[4]{};if(!mirrored)check(d.cuMemcpyDtoH_fn(copied,diagnostic,32));const auto result=mirrored ? packet : copied;
   for(unsigned k=0;k<4;++k){const auto expected=k==3 ? 4ULL : ~0ULL;if(result[k]!=expected)return 6;}
   check(d.cuCtxPopCurrent_fn(&previous));
  }
  const double wall=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-start).count()/repetitions;const double cpu=double(cpu_ns()-cpu_start)/repetitions;nvtxRangePop();expected_counter+=static_cast<unsigned long long>(repetitions)*launches;
  check(d.cuCtxPushCurrent_fn(context));unsigned long long observed=0;check(d.cuMemcpyDtoH_fn(&observed,counter,8));check(d.cuCtxPopCurrent_fn(&previous));if(observed!=expected_counter)return 7;
  std::printf("{\"mode\":\"%s\",\"launches\":%u,\"cycles\":%u,\"round\":%u,\"warmup\":%s,\"repetitions\":%u,\"wall_ns_per_group\":%.3f,\"cpu_ns_per_group\":%.3f,\"counter\":%llu}\n",mirrored ? "mirror" : "copy",launches,cycles,round,round==0 ? "true" : "false",repetitions,wall,cpu,observed);
 }
 // Context destruction owns both the mapped host allocation and device storage.
 check(d.cuCtxDestroy_fn(context));return 0;
}
