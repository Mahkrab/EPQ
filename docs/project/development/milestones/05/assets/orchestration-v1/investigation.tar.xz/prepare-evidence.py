from pathlib import Path
import json,hashlib,subprocess
w=Path('/tmp/maelstrom-orchestration-20261028');sha=lambda b:hashlib.sha256(b).hexdigest()
for v in ['control','diagnostic','trial-0','candidate','candidate-diagnostic']:
 d=json.loads((w/(v+'-source.json')).read_text());assert all(sha((w/v/p).read_bytes())==h for p,h in d.items()),v
args=['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(w/'trial-binding.ptx')];p=subprocess.run(args,cwd=w/'trial-0',capture_output=True,timeout=120);assert p.returncode==0;ptx=(w/'trial-binding.ptx').read_bytes();binary=(w/'target-trial-0/release/maelstrom').read_bytes();assert ptx in binary and ptx==(w/'candidate.ptx').read_bytes();(w/'trial-final-binding.json').write_text(json.dumps(dict(command=args,exit=0,binary_sha256=sha(binary),ptx_sha256=sha(ptx),equals_final_candidate_ptx=True),indent=2)+'\n')
print('all source exports and trial binding verified')
