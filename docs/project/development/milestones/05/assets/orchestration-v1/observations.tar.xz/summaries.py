from pathlib import Path
import json,gzip,statistics,csv
w=Path('/tmp/maelstrom-orchestration-20261028');out={}
def total(path):
 value,_=json.JSONDecoder().raw_decode(gzip.decompress(path.read_bytes()).decode());return sum(x['total_s'] for x in value['measurements']['steps'])
initial=json.loads((w/'initial/summary.json').read_text())['totals']
for group in ['8000','110592','8000-effects','110592-effects']:
 old=initial[group];cp={v:[total(w/f'final-profiles/overhead/{group}/pair-{i}/{v}/stdout.gz') for i in [1,2,3]] for v in ['candidate','candidate-diagnostic']};control=statistics.median(old['unprofiled-control']);candidate=statistics.median(cp['candidate']);row={}
 for v,base in [('control',control),('candidate',candidate)]:
  diag='diagnostic' if v=='control' else 'candidate-diagnostic';unprofiled_diag=statistics.median(old['unprofiled-diagnostic'] if v=='control' else cp[diag]);row[v]=dict(unprofiled_median_s=base,diagnostic_build_median_s=unprofiled_diag,build_only_percent=100*(unprofiled_diag/base-1),ordinary_trace_s=total(w/f'final-profiles/trace/{group}/{v}/stdout.gz'),rich_trace_s=total(w/f'final-profiles/trace/{group}/{diag}/stdout.gz'))
  row[v]['ordinary_trace_percent']=100*(row[v]['ordinary_trace_s']/base-1);row[v]['rich_trace_percent']=100*(row[v]['rich_trace_s']/base-1)
 out[group]=row
perf={}
for n in [8000,110592]:
 for v in ['control','candidate']:
  rows=[line.split(',') for line in (w/f'postcheck/perf-{n}-{v}.csv').read_text().splitlines() if line and not line.startswith('#')];d={r[2]:float(r[0]) for r in rows};perf[f'{n}/{v}']=dict(task_clock_ms=d['task-clock:u'],cycles=d['cycles:u'],instructions=d['instructions:u'],ipc=d['instructions:u']/d['cycles:u'],cache_miss_percent=100*d['cache-misses:u']/d['cache-references:u'],event_running_percent={r[2]:float(r[4]) for r in rows})
(w/'overhead-summary.json').write_text(json.dumps(out,indent=2)+'\n');(w/'cpu-counters.json').write_text(json.dumps(perf,indent=2)+'\n');print('complete')
