"""Explain checked boundaries without counting GPU/API overlap twice."""
from pathlib import Path
import json,sqlite3,collections,bisect
w=Path('/tmp/maelstrom-orchestration-20261028');db=sqlite3.connect(w/'final-profiles/activity.sqlite');out={}
def union(rows):
 merged=[]
 for a,b in sorted(rows):
  if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
  else:merged.append((a,b))
 return merged
def idle(a,b,gpu,starts,ends):
 i=bisect.bisect_right(ends,a);j=bisect.bisect_left(starts,b)
 return (b-a)-sum(max(0,min(b,y)-max(a,x)) for x,y in gpu[i:j])
phases=['acceleration-cfl','prediction','bounds-host-reduction','neighbor-pipeline','jacobi-group','projection-group','velocity-and-effects','final-vector-downloads']
for group in ['8000','110592','8000-effects','110592-effects']:
 for variant in ['diagnostic','candidate-diagnostic']:
  gpu=union([r for table in ['kernel','memcpy','memset'] for r in db.execute('SELECT start_ns,end_ns FROM '+table+' WHERE workload=? AND variant=?',(group,variant))]);starts=[a for a,b in gpu];ends=[b for a,b in gpu];api=db.execute('SELECT name,start_ns,end_ns FROM api WHERE workload=? AND variant=? ORDER BY start_ns',(group,variant)).fetchall();api_starts=[row[1] for row in api];counts=collections.Counter();times=collections.Counter()
  for text,a,b in db.execute('SELECT text,start_ns,end_ns FROM nvtx WHERE workload=? AND variant=? AND text IN ('+','.join('?' for _ in phases)+')',(group,variant,*phases)):
   counts[text+'/ranges']+=1;times[text+'/wall']+=b-a
   for name,x,y in api[bisect.bisect_left(api_starts,a):bisect.bisect_left(api_starts,b)]:
    if y>b:continue
    kind='wait' if 'StreamSynchronize' in name else 'download' if 'MemcpyDtoH' in name else 'launch' if 'cuLaunchKernel' in name else None
    if kind:counts[text+'/'+kind]+=1;times[text+'/'+kind+'-gpu-idle']+=idle(x,y,gpu,starts,ends)
  out[group+'/'+variant]=dict(counts_per_step={k:v/480 for k,v in counts.items()},ms_per_step={k:v/480/1e6 for k,v in times.items()})
(w/'boundary-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print('complete')
