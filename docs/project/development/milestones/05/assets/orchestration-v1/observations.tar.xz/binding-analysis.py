from pathlib import Path
import json,sqlite3,gzip,statistics
w=Path('/tmp/maelstrom-orchestration-20261028');db=sqlite3.connect(w/'all-apis/activity.sqlite');out={}
for n in [8000,110592]:
 for v in ['diagnostic','candidate-diagnostic']:
  roots=db.execute('SELECT start_ns,end_ns FROM nvtx WHERE particles=? AND variant=? AND text=? ORDER BY start_ns',(n,v,'solver-step')).fetchall();assert len(roots)==16;steps=[]
  for a,b in roots:
   rows=db.execute('SELECT name,count(*),sum(end_ns-start_ns) FROM api WHERE particles=? AND variant=? AND start_ns>=? AND end_ns<=? AND name LIKE ? GROUP BY name',(n,v,a,b,'%Ctx%')).fetchall();steps.append({name:dict(count=count,inclusive_us=elapsed/1e3) for name,count,elapsed in rows})
  names=sorted({k for row in steps for k in row});out[f'{n}/{v}']=dict(first_step=steps[0],steady_mean={name:dict(count=sum(row.get(name,{}).get('count',0) for row in steps[1:])/15,inclusive_us=sum(row.get(name,{}).get('inclusive_us',0) for row in steps[1:])/15) for name in names})
values=[json.loads(line) for line in gzip.decompress((w/'all-apis/binding/stdout.gz').read_bytes()).splitlines()];out['unprofiled_binding_probe']=dict(rounds=values,median_ns_per_pair=statistics.median(x['wall_ns_per_pair'] for x in values if not x['warmup']))
(w/'binding-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
