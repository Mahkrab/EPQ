"""Static resources and CPU hardware counters, outside primary solver timing."""
from pathlib import Path
import subprocess,json,time,hashlib,gzip,os
w=Path('/tmp/maelstrom-orchestration-20261028');r=w/'postcheck';r.mkdir();env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'));records=[];refs={}
def run(name,args,limit=240):
 t=time.monotonic();p=subprocess.run(args,cwd=w,env=env,capture_output=True,timeout=limit);dest=r/name;dest.mkdir(parents=True)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(dest/(label+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 rec=dict(command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());(dest/'process.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(dict(name=name,**rec));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0,(name,p.stderr);return p.stdout
for v in ['control','candidate']:
 binary=str(w/('resources-'+v));run(v+'-resources-build',['c++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-DCANDIDATE','-I/usr/local/cuda/include','-I'+str(w/v/'native'),str(w/'resources.cpp'),'-ldl','-o',binary]);run(v+'-resources',[binary,str(w/(v+'.ptx'))])
for name,path,obs in [('8000',w/'control/scenes/falling-block-20.toml',True),('110592',w/'inputs/scenes/capacity-block-48.toml',False)]:
 for v in ['control','candidate']:
  perf=r/f'perf-{name}-{v}.csv';args=[str(w/f'target-{v}/release/maelstrom'),'run',str(path),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure']
  if obs:args+=['--checkpoints','0,1,120,240,480']
  raw=run(f'perf/{name}/{v}',['/usr/lib/linux-tools/6.8.0-147-generic/perf','stat','-x,','-e','task-clock,cycles,instructions,branches,branch-misses,cache-references,cache-misses,context-switches,page-faults','-o',str(perf),'--',*args]);value=json.loads(raw);value.pop('measurements');value['metadata'].pop('build_revision',None);fp=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest();assert refs.get(name,fp)==fp;refs[name]=fp
print('complete',flush=True)
