"""Availability checks only: never alter driver, registry or security configuration."""
from pathlib import Path
import subprocess,json,time,hashlib
w=Path('/tmp/maelstrom-orchestration-20261028');r=w/'tooling';r.mkdir();records=[]
for name,args in [('kernel',['uname','-r']),('nsys',['nsys','--version']),('ncu',['/opt/nvidia/nsight-compute/2026.2.1/ncu','--version']),('sanitizer',['/usr/local/cuda/bin/compute-sanitizer','--version']),('gpu-counters',['nsys','profile','--gpu-metrics-devices=help']),('perf',['/usr/lib/linux-tools/6.8.0-147-generic/perf','--version'])]:
 t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=60)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/f'{name}.{label}').write_bytes(data)
 records.append(dict(name=name,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest(),gpu_counter_permission_denied=b'Insufficient privilege' in p.stdout+p.stderr));assert p.returncode==0,(name,p.stderr)
(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');(r/'environmental-changes.json').write_text(json.dumps(dict(system_wide_driver_settings_modified=False,registry_entries_modified_or_removed=False,security_permissions_modified=False,reboot_or_driver_reset=False,software_installed_or_reconfigured=False,changes=['Task-owned temporary source exports, inputs, release/debug builds, traces and evidence','Per-process CUDA_HOME, architecture, Cargo target and isolated configuration paths','Per-process NVTX/frame-pointer instrumentation and CUDA-context-owned allocations']),indent=2)+'\n')
