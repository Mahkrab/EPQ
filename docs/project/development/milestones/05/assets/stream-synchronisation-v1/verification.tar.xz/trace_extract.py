"""Retain only measured API and device activity, without profiler metadata."""
from pathlib import Path
import sqlite3,json
w=Path('/tmp/maelstrom-sync-20261027');out=w/'measurements/activity.sqlite'
with sqlite3.connect(out) as dest:
 dest.execute('CREATE TABLE api(variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)')
 for name in ['kernel','memcpy','memset']:
  dest.execute(f'CREATE TABLE {name}(variant TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)')
 for variant in ['control','candidate']:
  with sqlite3.connect(w/f'trace-{variant}.sqlite') as src:
   table=json.loads((w/f'measurements/trace-{variant}-counts.json').read_text())['api_table']
   rows=src.execute(f'SELECT s.value,a.start,a.end,a.correlationId FROM {table} a JOIN StringIds s ON s.id=a.nameId').fetchall()
   dest.executemany('INSERT INTO api VALUES (?,?,?,?,?)',[(variant,*row) for row in rows])
   for name in ['kernel','memcpy','memset']:
    rows=src.execute(f'SELECT start,end,correlationId FROM CUPTI_ACTIVITY_KIND_{name.upper()}').fetchall()
    dest.executemany(f'INSERT INTO {name} VALUES (?,?,?,?)',[(variant,*row) for row in rows])
 print(json.dumps({v:{name:dest.execute(f'SELECT count(*) FROM {name} WHERE variant=?',(v,)).fetchone()[0] for name in ['api','kernel','memcpy','memset']} for v in ['control','candidate']},indent=2))
