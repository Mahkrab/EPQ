"""Reconstruct the comparison from retained process outputs and activity rows."""
from pathlib import Path
import gzip,hashlib,json,statistics,sqlite3,sys,math
root=Path(sys.argv[1]);seen={};timings={};runs=0
for process in sorted(root.glob('**/process.json')):
 record=json.loads(process.read_text());out=gzip.decompress(process.with_name('stdout.gz').read_bytes());err=gzip.decompress(process.with_name('stderr.gz').read_bytes())
 assert hashlib.sha256(out).hexdigest()==record['stdout_sha256'],process
 assert hashlib.sha256(err).hexdigest()==record['stderr_sha256'],process
 assert record['exit']==0 and not record['timed_out'],process
 try:result=json.loads(out)
 except (ValueError,UnicodeDecodeError):continue
 if not isinstance(result,dict) or 'final_snapshot' not in result:continue
 if len(process.relative_to(root).parts)!=4:continue # exclude separately profiled requests
 label=process.relative_to(root).parts;variant=label[2];key=label[0]+'/'+label[1] if label[0]=='regression' else label[0]
 assert result['completed_steps']=='480' and not result['failures']
 measurements=result.pop('measurements');result['metadata'].pop('build_revision',None)
 physical=json.dumps(result,sort_keys=True,allow_nan=False)
 assert physical==seen.setdefault(key,physical),(key,variant)
 if label[0]!='regression' and label[1]!='warmup':
  timings.setdefault(key,{})[(label[1],variant)]=math.fsum(s['total_s'] for s in measurements['steps'])
 runs+=1
summary=json.loads((root/'summary.json').read_text());recomputed={}
for name,values in timings.items():
 medians={v:statistics.median(values[(f'sample-{i}',v)] for i in range(1,6)) for v in ['control','candidate']}
 saved=summary[name]
 for v in medians:assert math.isclose(medians[v],saved['median_s'][v],rel_tol=1e-12)
 change=100*(1-medians['candidate']/medians['control']);assert math.isclose(change,saved['median_reduction_percent'],abs_tol=1e-10)
 paired=[100*(1-values[(f'sample-{i}','candidate')]/values[(f'sample-{i}','control')]) for i in range(1,6)]
 assert all(math.isclose(a,b,abs_tol=1e-10) for a,b in zip(paired,saved['paired_reduction_percent']))
 assert sum(x<0 for x in paired)==saved['slower_pairs']
 recomputed[name]=dict(medians_s=medians,reduction_percent=change,paired_reduction_percent=paired)
with sqlite3.connect(root/'activity.sqlite') as db:
 per_step={}
 counts={v:dict(db.execute('SELECT name,count(*) FROM api WHERE variant=? GROUP BY name',(v,))) for v in ['control','candidate']}
 for v in counts:
  launches=[row[0] for row in db.execute('SELECT start_ns FROM api WHERE variant=? AND name="cuLaunchKernel" ORDER BY start_ns',(v,))]
  assert len(launches)==1168
  boundaries=[0]+[launches[i*146] for i in range(1,8)]+[2**63-1]
  per_step[v]=[db.execute('SELECT count(*) FROM api WHERE variant=? AND name="cuStreamSynchronize" AND start_ns>=? AND start_ns<?',(v,lo,hi)).fetchone()[0] for lo,hi in zip(boundaries,boundaries[1:])]
  saved=json.loads((root/f'trace-{v}-counts.json').read_text())
  assert counts[v]=={row[0]:row[1] for row in saved['api']}
  for table in ['kernel','memcpy','memset']:
   assert db.execute(f'SELECT count(*) FROM {table} WHERE variant=?',(v,)).fetchone()[0]==saved['device']['CUPTI_ACTIVITY_KIND_'+table.upper()]
assert counts['control']['cuLaunchKernel']==counts['candidate']['cuLaunchKernel']
assert counts['control']['cuMemcpyDtoH_v2']==counts['candidate']['cuMemcpyDtoH_v2']
assert counts['control']['cuMemcpyHtoD_v2']==counts['candidate']['cuMemcpyHtoD_v2']
print(json.dumps(dict(physical_runs=runs,exact_groups=len(seen),recomputed=recomputed,stream_waits={v:c['cuStreamSynchronize'] for v,c in counts.items()},waits_by_step=per_step),indent=2))
