"""Continue after discovering this Nsight export stores driver calls in RUNTIME."""
import subprocess,pathlib,sqlite3,json,time,gzip,hashlib,os
w=pathlib.Path('/tmp/maelstrom-sync-20261027');root=w/'measurements'
env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'))
def call(label,args):
 t=time.monotonic();p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 dest=root/label;dest.mkdir(parents=True,exist_ok=False)
 for name,data in [('stdout',p.stdout),('stderr',p.stderr)]:(dest/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 (dest/'process.json').write_text(json.dumps(dict(command=args,exit=p.returncode,timed_out=False,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()),indent=2)+'\n');assert p.returncode==0
prefix=w/'trace-candidate'
call('trace/candidate',['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--force-overwrite=false','--output',str(prefix),str(w/'target-candidate/release/maelstrom'),'run',str(w/'control/scenes/falling-block-20.toml'),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','8','--unpaced','--format','json','--quiet','--measure'])
call('trace-export/candidate',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'])
for variant in ['control','candidate']:
 with sqlite3.connect(w/f'trace-{variant}.sqlite') as db:
  tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
  table='CUPTI_ACTIVITY_KIND_DRIVER' if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables else 'CUPTI_ACTIVITY_KIND_RUNTIME'
  apis=db.execute(f'SELECT s.value,count(*),sum(a.end-a.start) FROM {table} a JOIN StringIds s ON s.id=a.nameId GROUP BY a.nameId ORDER BY s.value').fetchall()
  counts={t:db.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET']}
 (root/f'trace-{variant}-counts.json').write_text(json.dumps(dict(api_table=table,api=apis,device=counts),indent=2)+'\n')
 print(variant,apis,counts,flush=True)
