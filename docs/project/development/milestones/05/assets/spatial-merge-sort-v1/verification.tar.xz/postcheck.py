"""Observe loaded kernel resources and attempt a device-memory diagnostic after timing."""
from pathlib import Path
import subprocess,json,time,re,hashlib
w=Path('/tmp/maelstrom-sort-20261027');out=w/'postcheck';out.mkdir(exist_ok=False);records=[]
def run(label,args,timeout=180):
 t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=timeout)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 records.append(dict(label=label,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,flush=True);return p
for v in ['control','candidate']:
 args=['c++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include','-I'+str(w/v/'native'),str(w/'resources.cpp'),'-ldl','-o',str(w/('resources-'+v))]
 if v=='candidate':args+=['-DCANDIDATE']
 assert run(v+'-resources-build',args).returncode==0
 assert run(v+'-resources',[str(w/('resources-'+v)),str(w/(v+'.ptx'))]).returncode==0
text=(w/'verification/candidate-hardware-lib.log').read_text();binary=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',text).group(1)
p=run('device-memcheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','97',binary,'cuda::solver::spatial_sort_tests::hardware_spatial_sort_preserves_full_keys_padding_and_reused_storage','--exact','--ignored','--test-threads=1'])
if p.returncode==0:
 assert b'1 passed' in p.stdout and b'ERROR SUMMARY: 0 errors' in p.stderr+p.stdout
 assert run('device-racecheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','97',binary,'cuda::solver::spatial_sort_tests::hardware_spatial_sort_preserves_full_keys_padding_and_reused_storage','--exact','--ignored','--test-threads=1']).returncode==0
