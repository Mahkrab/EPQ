"""Add sorting-only CUDA event observations to separate benchmark exports."""
from pathlib import Path
import shutil,json,hashlib,difflib
w=Path('/tmp/maelstrom-sort-20261027')
for variant in ['control','candidate']:
 source=w/variant;dest=w/(variant+'-diagnostic');shutil.copytree(source,dest,dirs_exist_ok=True)
 p=dest/'native/bridge.cpp';old=p.read_text();s=old.replace('#include <utility>','#include <utility>\n#include <chrono>\n#include <cstdio>')
 s=s.replace('    X(cuLaunchKernel, "cuLaunchKernel")','''    X(cuLaunchKernel, "cuLaunchKernel") \\
    X(cuEventCreate, "cuEventCreate") X(cuEventRecord, "cuEventRecord") \\
    X(cuEventElapsedTime, "cuEventElapsedTime")''')
 s=s.replace('    CUdeviceptr diagnostic = 0;','''    CUevent sort_begin=nullptr, sort_end=nullptr;
    std::uint64_t sort_submit_ns=0;
    bool sort_measured=false;
    CUdeviceptr diagnostic = 0;''')
 key='    CUcontext previous;\n    code = d.cuCtxPopCurrent_fn(&previous);'
 assert s.count(key)==2
 s=s.replace(key,'''    if (!status.code && (code=d.cuEventCreate_fn(&r.sort_begin,CU_EVENT_DEFAULT))!=CUDA_SUCCESS) status={code,6};
    if (!status.code && (code=d.cuEventCreate_fn(&r.sort_end,CU_EVENT_DEFAULT))!=CUDA_SUCCESS) status={code,6};
'''+key,1)
 # Enclose both sorting implementations identically, with no additional waits.
 key='        // These integer-only passes' if variant=='control' else '        if (settings.padded==1) return {0,0};'
 start=s.index(key)
 end=s.index('        return {0,0};\n    },diagnostic ? records',start)
 body=s[start:end]
 s=s[:start]+'''        const auto sort_start=std::chrono::steady_clock::now();
        auto event_code=r.driver.cuEventRecord_fn(r.sort_begin,r.stream);
        if (event_code!=CUDA_SUCCESS) return {event_code,9};
'''+body+'''        event_code=r.driver.cuEventRecord_fn(r.sort_end,r.stream);
        if (event_code!=CUDA_SUCCESS) return {event_code,9};
        r.sort_submit_ns=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-sort_start).count());
        r.sort_measured=true;
'''+s[end:]
 key='    if (diagnostic && !status.code) {'
 assert s.count(key)==1
 s=s.replace(key,'''    if (diagnostic && !status.code && operation==4 && r.sort_measured) {
        float elapsed_ms=0;
        const auto measurement=solver_call(r,Boundary::HostAccess,[&]() -> Status {
            const auto code=r.driver.cuEventElapsedTime_fn(&elapsed_ms,r.sort_begin,r.sort_end);
            return {code,code==CUDA_SUCCESS ? 0 : 10};
        });
        if (measurement.code) return measurement;
        std::fprintf(stderr,"SORT_STAGE %u %llu %.9g\\n",settings.count,static_cast<unsigned long long>(r.sort_submit_ns),static_cast<double>(elapsed_ms));
        r.sort_measured=false;
    }
'''+key)
 p.write_text(s)
 (w/(variant+'-diagnostic.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/native/bridge.cpp',tofile='b/native/bridge.cpp')))
 manifest={p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.rglob('*')) if p.is_file()}
 (w/(variant+'-diagnostic-source.json')).write_text(json.dumps(manifest,indent=2)+'\n')
