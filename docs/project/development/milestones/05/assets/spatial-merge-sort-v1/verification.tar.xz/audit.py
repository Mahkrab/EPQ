"""Reconstruct physical agreement, both timing boundaries and GPU launch counts."""
from pathlib import Path
import gzip,hashlib,json,statistics,sqlite3,sys,math
root=Path(sys.argv[1]);seen={};ordinary={};stages={};runs=0
for process in sorted(root.glob('**/process.json')):
 rec=json.loads(process.read_text());out=gzip.decompress(process.with_name('stdout.gz').read_bytes());err=gzip.decompress(process.with_name('stderr.gz').read_bytes())
 assert hashlib.sha256(out).hexdigest()==rec['stdout_sha256'],process
 assert hashlib.sha256(err).hexdigest()==rec['stderr_sha256'],process
 assert rec['exit']==0 and not rec['timed_out'],process
 label=process.relative_to(root).parts
 if label[0] not in ['regression','8000','110592','110592-effects','sort-stage']:continue
 result=json.loads(out);assert result['completed_steps']=='480' and not result['failures']
 measured=result.pop('measurements');result['metadata'].pop('build_revision',None)
 if label[0]=='sort-stage':key=label[1];variant=label[3].removesuffix('-diagnostic');sample=label[2]
 else:key='/'.join(label[:2]) if label[0]=='regression' else label[0];variant=label[2];sample=label[1]
 physical=json.dumps(result,sort_keys=True,allow_nan=False);assert physical==seen.setdefault(key,physical),(key,variant)
 total=math.fsum(row['total_s'] for row in measured['steps'])
 if label[0]=='sort-stage':
  values=[line.split() for line in err.decode().splitlines() if line.startswith('SORT_STAGE ')]
  assert len(values)==480 and all(int(row[1])==int(key) for row in values)
  gpu=math.fsum(float(row[3]) for row in values)/1000;submit=sum(int(row[2]) for row in values)/1e9
  if sample!='warmup':stages.setdefault(key,{})[(sample,variant)]=dict(sort_gpu_s=gpu,sort_submit_s=submit,solver_s=total)
 elif label[0]!='regression' and sample!='warmup':ordinary.setdefault(key,{})[(sample,variant)]=total
 runs+=1
summary=json.loads((root/'summary.json').read_text());stage_summary=json.loads((root/'sort-stage-summary.json').read_text());recomputed={};stage_recomputed={}
for name,values in ordinary.items():
 med={v:statistics.median(values[(f'sample-{i}',v)] for i in range(1,6)) for v in ['control','candidate']}
 for v in med:assert math.isclose(med[v],summary[name]['median_s'][v],rel_tol=1e-12)
 reductions=[100*(1-values[(f'sample-{i}','candidate')]/values[(f'sample-{i}','control')]) for i in range(1,6)]
 assert all(math.isclose(a,b,abs_tol=1e-10) for a,b in zip(reductions,summary[name]['paired_reduction_percent']))
 assert sum(x<0 for x in reductions)==summary[name]['slower_pairs']
 recomputed[name]=dict(median_s=med,speedup=med['control']/med['candidate'],paired_reduction_percent=reductions)
for name,values in stages.items():
 stage_recomputed[name]={}
 for field in ['sort_gpu_s','sort_submit_s','solver_s']:
  med={v:statistics.median(values[(f'sample-{i}',v)][field] for i in range(1,6)) for v in ['control','candidate']}
  for v in med:assert math.isclose(med[v],stage_summary[name][field]['median'][v],rel_tol=1e-12)
  assert math.isclose(med['control']/med['candidate'],stage_summary[name][field]['speedup'],rel_tol=1e-12)
  stage_recomputed[name][field]=dict(median_s=med,speedup=med['control']/med['candidate'])
 stage_recomputed[name]['instrumentation_percent']={v:100*(stage_recomputed[name]['solver_s']['median_s'][v]/recomputed[name]['median_s'][v]-1) for v in ['control','candidate']}
traces={}
with sqlite3.connect(root/'activity.sqlite') as db:
 for size,old,old_total,new,new_total in [(8000,91,146,7,62),(110592,153,208,11,66)]:
  traces[size]={}
  for variant,sorts,total in [('control',old,old_total),('candidate',new,new_total)]:
   apis=dict(db.execute('SELECT name,count(*) FROM api WHERE variant=? AND particles=? GROUP BY name',(variant,size)))
   launches=[row[0] for row in db.execute('SELECT correlation FROM api WHERE variant=? AND particles=? AND name="cuLaunchKernel" ORDER BY start_ns',(variant,size))]
   kernels=db.execute('SELECT name,correlation FROM kernel WHERE variant=? AND particles=?',(variant,size)).fetchall();assert len(launches)==len(kernels)==8*total
   kernel_names={corr:name for name,corr in kernels};assert set(kernel_names)==set(launches)
   if variant=='candidate':assert sum(name=='spatial_sort' for name,_ in kernels)==sorts*8
   for step in range(8):
    group=launches[step*total:(step+1)*total];selected=group[3:3+sorts]
    assert len(selected)==sorts
    if variant=='candidate':assert all(kernel_names[corr]=='spatial_sort' for corr in selected)
   assert apis['cuStreamSynchronize']==168
   assert apis['cuMemcpyDtoH_v2']==208 and apis['cuMemcpyHtoD_v2']==11
   saved=json.loads((root/f'trace-{size}-{variant}-counts.json').read_text());assert apis=={row[0]:row[1] for row in saved['api']}
   assert saved['device']['CUPTI_ACTIVITY_KIND_KERNEL']==len(kernels)
   traces[size][variant]=dict(total_launches=len(launches),sort_launches=sorts*8,non_sort_launches=(total-sorts)*8,waits=apis['cuStreamSynchronize'],copies=apis['cuMemcpyDtoH_v2']+apis['cuMemcpyHtoD_v2'])
print(json.dumps(dict(physical_runs=runs,exact_groups=len(seen),ordinary=recomputed,stage=stage_recomputed,traces=traces),indent=2))
