"""Select each intended header explicitly for the retained native test overlay."""
from pathlib import Path
import shutil,subprocess,json,time,hashlib
w=Path('/tmp/maelstrom-correction-20261028');r=w/'reference-power';r.mkdir();records=[]
# A quoted include first searches the including file's directory. Keep this
# overlay outside both source trees so -I selects the intended power.cuh.
test=r/'power_exhaustive.cu';shutil.copyfile(w/'candidate/native/power_exhaustive.cu',test)
for v in ['control','candidate']:
 include=w/v/'native';header=include/'power.cuh'
 args=['/usr/local/cuda/bin/nvcc','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=sm_89','-I'+str(include),str(test),'-o',str(r/(v+'-power-exhaustive'))]
 def run(label,command):
  t=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=600);(r/(label+'.stdout')).write_bytes(p.stdout);(r/(label+'.stderr')).write_bytes(p.stderr);records.append(dict(label=label,command=command,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0;return p
 dependencies=run(v+'-dependencies',[*args[:-2],'-M']).stdout.decode()
 assert str(header) in dependencies
 other=w/('candidate' if v=='control' else 'control')/'native/power.cuh';assert str(other) not in dependencies
 (r/(v+'-identity.json')).write_text(json.dumps(dict(header=str(header),header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),test_sha256=hashlib.sha256(test.read_bytes()).hexdigest(),header_selection_verified=True),indent=2)+'\n')
 run(v+'-build',args)
 for threads in [32,64,128,256]:
  p=run(v+'-'+str(threads),[str(r/(v+'-power-exhaustive')),str(threads)]);result=json.loads(p.stdout);assert result['input_words']==1<<31 and result['mismatches']==result['guard_mismatches']==0 and result['guarded_words']==529216975 and result['raw_quartic_mismatches']==354191
