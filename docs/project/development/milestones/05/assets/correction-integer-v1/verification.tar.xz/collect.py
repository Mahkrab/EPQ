"""Retain bounded observations and source deltas, without native profiler metadata."""
from pathlib import Path
import tarfile,json,hashlib,shutil,subprocess
w=Path('/tmp/maelstrom-correction-20261028');out=w/'retained';out.mkdir();members={}
def pack(name,paths):
 with tarfile.open(out/name,'w:xz') as arc:
  for p in sorted(set(paths)):
   if p.is_file():
    rel=p.relative_to(w).as_posix();members[rel]=hashlib.sha256(p.read_bytes()).hexdigest();arc.add(p,arcname=rel,recursive=False)
# Bind the untouched exploratory executable once more, outside primary timing.
ptx=w/'trial-identity.ptx';command=['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(ptx)];p=subprocess.run(command,cwd=w/'trial-0',capture_output=True,timeout=180);assert p.returncode==0;binary=w/'target-trial-0/release/maelstrom';assert ptx.read_bytes() in binary.read_bytes();assert ptx.read_bytes()==(w/'candidate.ptx').read_bytes()
(w/'trial-final-binding.json').write_text(json.dumps(dict(command=command,exit=0,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),ptx_sha256=hashlib.sha256(ptx.read_bytes()).hexdigest(),ptx_equals_final_candidate=True),indent=2)+'\n')
(w/'trial-power-identity.json').write_text(json.dumps(dict(test_source_sha256=hashlib.sha256((w/'trial-power-exhaustive.cu').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256((w/'trial-power-exhaustive').read_bytes()).hexdigest(),selected_header_sha256=json.loads((w/'trial-0-source.json').read_text())['native/power.cuh'],exit=0,elapsed_s=json.loads((w/'trial-power-result.json').read_text())['elapsed_s'],child_wall_s=None,identity_recorded_after_trial=True),indent=2)+'\n')
pack('observations.tar.xz',list((w/'measurements').rglob('*'))+list((w/'inputs').rglob('*')))
pack('investigation.tar.xz',list((w/'initial').rglob('*'))+list((w/'attribution').rglob('*'))+list((w/'trial-results').rglob('*'))+[w/n for n in ['initial.py','initial-audit.py','profile-probes.py','build-probes.py','probe-builds.json','trial.py','investigation-audit.py','compiler-analysis.json','trial-power-exhaustive.cu','trial-power-result.json','trial-power.stderr','trial-power-build.log','trial-power-identity.json','trial-build.log','trial-final-binding.json','initial-progress.log','control-build.log','attribution-progress.log','trial-progress.log']]+[w/(v+ext) for v in ['probe-0','probe-1','probe-2','trial-0'] for ext in ['-source.json','.patch','-build.stdout','-build.stderr']])
# Only logs/identities from reference-power belong in the archive; no executable/source copy.
reference=[p for p in (w/'reference-power').iterdir() if p.suffix in ['.stdout','.stderr','.json']]
pack('verification.tar.xz',list((w/'verification').rglob('*'))+list((w/'postcheck').rglob('*'))+list((w/'local-verification').rglob('*'))+reference+[w/n for n in ['verify.py','measure.py','audit.py','postcheck.py','resources.cpp','reference-power.py','verification-notes.json','collect.py','verification-progress.log','measurement-progress.log','reference-power-progress.log','postcheck-progress.log']])
(out/'files-sha256.json').write_text(json.dumps(members,indent=2)+'\n')
for n in ['control-source.json','candidate-source.json','control.patch','candidate.patch','protocol.md','independent-audit.json','initial-audit.json','investigation-audit.json']:
 shutil.copyfile(w/n,out/n)
print('members',len(members),flush=True)
