"""Observe resources and device diagnostic availability outside all timing."""
from pathlib import Path
import subprocess,json,time,re,hashlib,os
w=Path('/tmp/maelstrom-correction-20261028');out=w/'postcheck';out.mkdir(exist_ok=False);records=[]
def run(label,args,timeout=180,cwd=None):
 t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=timeout,cwd=cwd)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 records.append(dict(label=label,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,flush=True);return p
for v in ['control','candidate','probe-0','probe-1','probe-2','trial-0']:
 assert run(v+'-resources-build',['c++','-DCANDIDATE','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I/usr/local/cuda/include','-I'+str(w/v/'native'),str(w/'resources.cpp'),'-ldl','-o',str(w/('resources-'+v))]).returncode==0
 assert run(v+'-resources',[str(w/('resources-'+v)),str(w/(v+'.ptx'))]).returncode==0
text=(w/'verification/candidate-hardware-lib.log').read_text();binary=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',text).group(1)
p=run('device-memcheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','97',binary,'cuda::solver::density_tests::','--ignored','--test-threads=1'])
if p.returncode==0:
 assert b'2 passed' in p.stdout and b'ERROR SUMMARY: 0 errors' in p.stderr+p.stdout
 assert run('device-racecheck',['/usr/local/cuda/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','97',binary,'cuda::solver::density_tests::','--ignored','--test-threads=1']).returncode==0
run('platform',['uname','-sr'])
(out/'build-env.json').write_text(json.dumps({k+'_sha256':hashlib.sha256(os.environ.get(k,'').encode()).hexdigest() for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']},indent=2)+'\n')
