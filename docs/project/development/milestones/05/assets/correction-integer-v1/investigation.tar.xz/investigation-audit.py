"""Read correction probes and exploratory samples without collector summaries."""
from pathlib import Path
import sys,json,gzip,hashlib,sqlite3
w=Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest()
def physical(value,n):
 assert value['completed_steps']=='480' and not value['failures'] and len(value['final_snapshot']['particles'])==n and value['metadata']['debug_assertions'] is False
 assert value['execution']=={'mode':'cuda','device':0,'threads':128}
 measurements=value.pop('measurements');assert len(measurements['steps'])==480
 total=sum(step['total_s'] for step in measurements['steps']);value['metadata'].pop('build_revision',None)
 return value,total
for folder in ['attribution','trial-results']:
 for p in (w/folder).glob('**/process.json'):
  d=json.loads(p.read_text());assert d['exit']==0 and not d['timed_out']
  for stream in ['stdout','stderr']:assert sha(gzip.decompress((p.parent/(stream+'.gz')).read_bytes()))==d[stream+'_sha256']
control,_=physical(json.loads(gzip.decompress((w/'initial/110592/warmup/stdout.gz').read_bytes())),110592)
db=sqlite3.connect(w/'attribution/activity.sqlite');probes={}
labels=['acceleration','prediction','cells']+['sort']*11+['count','prefix-block','prefix-total','prefix-carry','fill','row-sort']+['validation-density-lambda','publish','probe','correction','mass','candidate','projection']*8+['velocity'];width=len(labels)
for v in ['probe-0','probe-1','probe-2']:
 for label in ['warmup','profile']:
  raw=gzip.decompress((w/f'attribution/{v}/{label}/stdout.gz').read_bytes()).decode();value,_=json.JSONDecoder().raw_decode(raw);got,_=physical(value,110592);assert got==control
 rows=db.execute('SELECT name,start_ns,end_ns FROM kernel WHERE variant=? ORDER BY start_ns',(v,)).fetchall();assert len(rows)==480*width
 for i,(name,b,e) in enumerate(rows):
  label=labels[i%width];expected='observe_state' if label in ['acceleration','prediction'] else 'spatial_sort' if label=='sort' else 'prefix_counts' if label.startswith('prefix-') else 'solver';assert name==expected and e>=b
 bands={}
 for start,end in [(1,480),(1,120),(241,480)]:
  bands[f'{start}-{end}']={label:sum(e-b for i,(_,b,e) in enumerate(rows) if start<=i//width+1<=end and labels[i%width]==label)/(end-start+1)/1e6 for label in dict.fromkeys(labels)}
 assert bands['1-480']==json.loads((w/'attribution/summary.json').read_text())[v]
 probes[v]=dict(gpu_ms_per_step=bands,kernel_launches=len(rows),extra_launches_per_step=8)
trials={}
for n in [8000,110592]:
 pairs=[];reference=None
 for label in ['warmup','pair-1','pair-2']:
  pair={}
  for v in ['control','trial-0']:
   raw=gzip.decompress((w/f'trial-results/{n}/{label}/{v}/stdout.gz').read_bytes());got,total=physical(json.loads(raw),n)
   if reference is None:reference=got
   else:assert got==reference
   pair[v]=total
  if label!='warmup':pairs.append(pair)
 assert pairs==json.loads((w/'trial-results/summary.json').read_text())[str(n)]
 trials[n]=dict(pairs=pairs,paired_reduction_percent=[100*(1-p['trial-0']/p['control']) for p in pairs])
for folder in ['attribution','trial-results']:
 identities=json.loads((w/folder/'identities.json').read_text())
 for v,d in identities.items():assert d['source']==json.loads((w/(v+'-source.json')).read_text())
print(json.dumps(dict(probe_physical_records=6,trial_physical_records=12,probes=probes,trials=trials),indent=2))
