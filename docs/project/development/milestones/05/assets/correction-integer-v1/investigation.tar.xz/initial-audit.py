"""Reconstruct the pre-change attribution from original control activities."""
from pathlib import Path
import json,gzip,sys,hashlib,sqlite3
w=Path(sys.argv[1]);r=w/'initial';sha=lambda b:hashlib.sha256(b).hexdigest()
for p in r.glob('**/process.json'):
 d=json.loads(p.read_text());assert d['exit']==0 and not d['timed_out']
 for stream in ['stdout','stderr']:assert sha(gzip.decompress((p.parent/(stream+'.gz')).read_bytes()))==d[stream+'_sha256']
source=json.loads((r/'identities.json').read_text());assert source['control']['source']==json.loads((w/'control-source.json').read_text())
db=sqlite3.connect(r/'activity.sqlite');result={}
for n,sorts in [(8000,7),(110592,11)]:
 values=[]
 for label in ['warmup','profile']:
  raw=gzip.decompress((r/f'{n}/{label}/stdout.gz').read_bytes()).decode();v,_=json.JSONDecoder().raw_decode(raw)
  assert v['completed_steps']=='480' and not v['failures'] and len(v['final_snapshot']['particles'])==n and v['metadata']['debug_assertions'] is False
  assert v['execution']['mode']=='cuda' and v['execution']['device']==0 and v['execution']['threads']==128 and v['request']['checkpoints']==[]
  v.pop('measurements');v['metadata'].pop('build_revision',None);values.append(v)
 assert values[0]==values[1]
 labels=['acceleration','prediction','cells']+['sort']*sorts+['count','prefix-block','prefix-total','prefix-carry','fill','row-sort']+['validation-density-lambda','publish','correction','mass','candidate','projection']*8+['velocity'];width=len(labels)
 rows=db.execute('SELECT name,start_ns,end_ns FROM kernel WHERE particles=? ORDER BY start_ns',(n,)).fetchall();assert len(rows)==480*width
 for i,(name,b,e) in enumerate(rows):
  label=labels[i%width];expected='observe_state' if label in ['acceleration','prediction'] else 'spatial_sort' if label=='sort' else 'prefix_counts' if label.startswith('prefix-') else 'solver';assert name==expected and e>=b
 bands={}
 for start,end in [(1,480),(1,120),(241,480)]:
  bands[f'{start}-{end}']={label:sum(e-b for i,(_,b,e) in enumerate(rows) if start<=i//width+1<=end and labels[i%width]==label)/(end-start+1)/1e6 for label in dict.fromkeys(labels)}
 assert bands['1-480']==json.loads((r/'summary.json').read_text())[str(n)]
 result[n]=dict(bands_gpu_ms_per_step=bands,physical_sha256=sha(json.dumps(values[0],sort_keys=True).encode()),profile_and_warmup_match=True,kernel_launches=len(rows))
print(json.dumps(result,indent=2))
