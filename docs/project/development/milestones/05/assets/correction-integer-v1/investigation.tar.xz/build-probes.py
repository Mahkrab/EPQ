from pathlib import Path
import subprocess,os,time,json,tarfile
w=Path('/tmp/maelstrom-correction-20261028');records=[]
for v in ['probe-0','probe-1','probe-2']:
 d=w/v;d.mkdir()
 with tarfile.open(w/(v+'.tar.gz')) as arc:arc.extractall(d,filter='data')
 args=['cargo','build','--release','--features','cuda','--locked','--offline'];env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',CARGO_TARGET_DIR=str(w/('target-'+v)));t=time.monotonic();p=subprocess.run(args,cwd=d,env=env,capture_output=True,timeout=600)
 (w/(v+'-build.stdout')).write_bytes(p.stdout);(w/(v+'-build.stderr')).write_bytes(p.stderr);records.append(dict(variant=v,command=args,exit=p.returncode,wall_s=time.monotonic()-t));(w/'probe-builds.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0
