"""Identify and qualify the delivered source after non-runtime review corrections."""
import hashlib,json,re,subprocess,tarfile,os
from pathlib import Path
r=Path('/tmp/maelstrom-cache-final');source=r/'delivery';manifest=json.loads((r/'delivered-source.json').read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(source/n)==s for n,s in manifest['files'].items())
h=hashlib.sha256()
for n in sorted((n for n in manifest['files'] if n in ['Cargo.toml','Cargo.lock','build.rs'] or n.split('/')[0] in ['src','native','build_support','scenes','config']),key=lambda n:Path(n).parts):
 b=(source/n).read_bytes();h.update(n.encode());h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
binary=r/'delivery-target/release/maelstrom';data=binary.read_bytes();embedded='sha256:'+h.hexdigest();assert embedded.encode() in data
ptx=[p for p in (r/'delivery-target/release/build').glob('maelstrom-*/out/*.ptx') if p.read_bytes() in data]
assert {sha(p) for p in ptx}=={'cf4a83d08b2db15e1576a975759b41844d853b2b52e69235890cc254dce45b8b'}
counts={}
for label,name in [('ordinary','delivery-tests.log'),('optin_library','delivery-optin-library.log'),('optin_integration','delivery-optin-integration.log'),('cache_workflow_repeated_after_import_fix','delivery-cache-workflow.log'),('headless_cli','delivery-headless-cli.log')]:
 v=[tuple(map(int,x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (r/name).read_text())]
 counts[label]={'passed':sum(x[0] for x in v),'failed':sum(x[1] for x in v),'log':name};assert counts[label]['failed']==0
assert [counts[x]['passed'] for x in ['ordinary','optin_library','optin_integration','cache_workflow_repeated_after_import_fix','headless_cli']]==[368,38,21,3,1]
case=r/'runs/large-impact';output=r/'delivery-readback'
subprocess.run([str(binary),'--format','json','render',str(case/'b-1-cache'),'--frame','150','--render-config',str(case/'render.toml'),'-o',str(output)],env=os.environ|{'CUDA_VISIBLE_DEVICES':''},check=True,capture_output=True,timeout=60)
actual=json.loads((output/'manifest.json').read_bytes());expected=json.loads((case/'a-1-images/manifest.json').read_bytes())['frames'][150]
assert actual['timing_seconds']['solver_steps']==0
for key in ['step','png_sha256','rgba_sha256','snapshot_sha256']:
 assert actual['frames'][0][key]==expected[key],key
subprocess.run([str(binary),'runs','validate',str(output)],check=True,capture_output=True,timeout=60)
proof={'source_manifest_sha256':sha(r/'delivered-source.json'),'embedded_source':embedded,'binary_sha256':sha(binary),'ptx_sha256':sha(ptx[0]),'ptx_bytes':ptx[0].stat().st_size,'source_matches_delivery_manifest':True,'counts':counts,'all_features_release_clippy':'delivery-final-clippy.log','headless_release_clippy':'delivery-headless-clippy.log','large_cache_replay_without_fluid_steps':True,'large_single_frame_matches_measured_direct_png_rgba_and_canonical_hash':True,'performance':'No remeasurement: only a leading blank line and a feature-conditional test import differ from timed sources.'}
(r/'delivery-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
archive=r/'retained/delivery-raw.tar.gz';members={}
files=[p for p in r.glob('delivery*.log')]+[r/'delivered-source.json',r/'delivery-cleanup.patch',r/'delivery-verification.json',r/'seal-delivery.py',output/'manifest.json']
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  name=str(p.relative_to(r));members[name]={'sha256':sha(p),'bytes':p.stat().st_size};tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
 for x in tar:assert hashlib.sha256(tar.extractfile(x).read()).hexdigest()==members[x.name]['sha256']
seal={'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,'verified_on_primary':True}
(r/'retained/delivery-raw-manifest.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(proof,indent=2));print('sealed delivery logs',len(members))
