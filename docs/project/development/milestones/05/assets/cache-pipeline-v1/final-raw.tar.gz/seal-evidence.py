"""Seal raw records, retaining full binaries/images/caches separately on the PC."""
import hashlib,json,os,platform,re,subprocess,tarfile
from pathlib import Path
ROOT=Path('/tmp/maelstrom-cache-final')
EARLIER=Path('/tmp/maelstrom-cache-implementation')
out=ROOT/'retained';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def capture(cmd):return subprocess.run(cmd,capture_output=True,text=True,check=False).stdout.strip()
environment={'kernel':platform.release(),'cpu':capture(['lscpu']),'gpu':capture(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader']), 'rustc':capture(['rustc','-Vv']), 'cargo':capture(['cargo','-V']), 'nvcc':capture(['/usr/local/cuda/bin/nvcc','--version']), 'measurement_device':'primary PC via ssh pc','display':json.loads((ROOT/'runs/large-impact/a-1-images/manifest.json').read_bytes())['graphics']}
(ROOT/'environment.json').write_text(json.dumps(environment,indent=2)+'\n')
qualification={}
for label,log in [('ordinary','pc-tests.log'),('optin_library','pc-optin-library.log'),('optin_integration','pc-optin-integration.log')]:
 results=[tuple(map(int,x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (ROOT/log).read_text())]
 qualification[label]={'passed':sum(x[0] for x in results),'failed':sum(x[1] for x in results),'ignored':sum(x[2] for x in results),'log':log}
assert sum(x['passed'] for x in qualification.values())==427
qualification.update({'release_all_features_strict_clippy':True,'additional_specialised_optins_not_run':10,'graphics_optin_adapter':'explicit Mesa lavapipe Vulkan; performance campaign uses hardware OpenGL/D3D12','ordinary_command':'CUDA_HOME=/usr/local/cuda CARGO_TARGET_DIR=ROOT/candidate-target cargo test --release --locked --all-features -- --test-threads=1','optin_library_command':'VK_DRIVER_FILES=/usr/share/vulkan/icd.d/lvp_icd.json cargo test --release --locked --all-features --lib -- --ignored --test-threads=1','optin_integration_tests':['cuda_execution','cuda_boundary','export_device','render_device','cache_workflow','cli_usability','saved_settings_cli'],'clippy_command':'cargo clippy --release --locked --all-features --all-targets -- -D warnings'})
(ROOT/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
for label,source in [('final',ROOT),('earlier',EARLIER)]:
 members=[p for p in source.iterdir() if p.is_file() and p.suffix in ['.json','.log','.py']]
 for scene in (source/'runs').iterdir():
  members += list(scene.glob('*.toml'))
  for part in scene.iterdir():
   if not part.is_dir() or part.name=='library':continue
   for p in part.rglob('*'):
    if p.is_file() and p.suffix in ['.json','.jsonl','.txt','.csv']:members.append(p)
 # Include partial-failure metadata, not binary particle data.
 members += [p for p in (source/'resource-failure').rglob('*') if p.is_file() and p.suffix in ['.json','.jsonl']]
 members=sorted(set(members))
 archive=out/f'{label}-raw.tar.gz';manifest={}
 with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
  for p in members:
   name=str(p.relative_to(source));manifest[name]={'sha256':sha(p),'bytes':p.stat().st_size};tar.add(p,arcname=name,recursive=False)
 with tarfile.open(archive,'r:gz') as tar:
  for entry in tar:
   data=tar.extractfile(entry).read();assert hashlib.sha256(data).hexdigest()==manifest[entry.name]['sha256']
 seal={'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':manifest,'verified_on_primary':True}
 (out/f'{label}-raw-manifest.json').write_text(json.dumps(seal,indent=2)+'\n')
 print(label,len(manifest),archive.stat().st_size,flush=True)
