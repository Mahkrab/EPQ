# Retained setup failures
The first trial-3 generator copied control into trial-3 but referred to trial-2/native/solver.cu when extracting the original correction body. It raised ValueError: substring not found before writing the edited source. The corrected generator uses trial-3 and overwrites only its own private export.

The initial trial-3 target symlink referred to a nonexistent old target. Cargo exited 101: failed to create directory .../target-trial-3; Not a directory (os error 20). The task-owned link was corrected to an existing previous task target. No timing sample was collected from either setup failure.

The first aggregate resource query reached candidate before candidate.ptx existed and exited 2 from the probe's file-open check. resources-progress.log retains the assertion. Production PTX was generated explicitly, and resources-retry-progress.log plus resources.json record the completed query. No measurements ran until this succeeded.

Nsight Compute returned ERR_NVGPUCTRPERM on the fresh one-step attempt. The command, exit 1, raw stdout/stderr hashes and output are in preflight. No privileged settings were changed. This is not a hardware-counter pass.
