//! Completed density checks must justify later reuse without hiding errors in
//! independent correction calls or changing a grouped stage's first diagnostic.

use super::*;

#[test]
#[ignore = "requires an explicitly selected CUDA hardware test run"]
fn completed_geometry_checks_preserve_grouped_and_standalone_results() {
    let config = crate::config::resolve_effective_configuration(None, None, None).unwrap();
    for threads in [32, 64, 128, 256] {
        let mut grouped = CudaSolver::new(0, threads).unwrap();
        let mut separate = CudaSolver::new(0, threads).unwrap();
        for count in [1, 17, 33, 65] {
            for case in 0..12 {
                let particles: Vec<_> = (0..count)
                    .map(|i| Particle {
                        identity: (3 * i + 7) as u64,
                        position_m: Vec3::new((i % 7) as f32 * 0.03, (i / 7) as f32 * 0.01, 0.0),
                        velocity_m_s: Vec3::ZERO,
                    })
                    .collect();
                let mut input: Vec<_> = particles.iter().map(|p| array(p.position_m)).collect();
                let mut s = settings(&config, count, 0).unwrap();
                s.radius = 0.2;
                s.relaxation = 0.01;
                s.strength = 0.1;
                s.reference_weight = crate::kernel::poly6(0.04, 0.2).unwrap();
                match case {
                    0 => {}
                    1 => input.fill([0.0, -0.0, 0.0]),
                    2 => input[count - 1][0] = s.radius,
                    3 => input[count - 1][0] = f32::from_bits(s.radius.to_bits() - 1),
                    4 => input[count - 1][0] = f32::from_bits(s.radius.to_bits() + 1),
                    5 => s.radius = 1.0e-10,
                    6 => s.rest_density = 0.0,
                    7 => s.reference_weight = 0.0,
                    8 => s.strength = f32::MAX,
                    9 => s.mass = f32::MAX,
                    10 => s.radius = f32::MAX,
                    _ => input[count - 1][0] = f32::MAX,
                }
                let mut indices = Vec::new();
                let mut offsets = vec![0_u64];
                // Deliberately retain inactive and coincident members. Both
                // paths must filter the current snapshot, not assume discovery.
                for i in 0..count {
                    indices.extend((0..count).filter(|j| *j != i).map(|j| j as u32));
                    offsets.push(indices.len() as u64);
                }
                s.entries = indices.len() as u64;
                for gpu in [&mut grouped, &mut separate] {
                    gpu.prepare(s, &particles, &[]).unwrap();
                    gpu.context.inner.upload(2, &input).unwrap();
                    gpu.context.inner.reserve(11, indices.len() * 4).unwrap();
                    gpu.context.inner.upload(11, &indices).unwrap();
                    gpu.context.inner.upload(13, &offsets).unwrap();
                    gpu.context.inner.upload(7, &vec![[77.0_f32; 3]; count]).unwrap();
                }
                let actual = grouped.context.inner.checked_group(s, 5, threads).unwrap();
                let mut expected = u64::MAX;
                for operation in 5..=8 {
                    expected = separate.context.inner.checked_launch(s, operation, threads).unwrap();
                    if expected != u64::MAX { break; }
                }
                assert_eq!(actual, expected, "block {threads}, count {count}, case {case}");
                if actual == u64::MAX {
                    for slot in [4, 5, 6] {
                        let bits = |gpu: &mut CudaSolver| gpu.context.inner.download::<f32>(slot, count).unwrap().into_iter().map(f32::to_bits).collect::<Vec<_>>();
                        assert_eq!(bits(&mut grouped), bits(&mut separate));
                    }
                    let bits = |gpu: &mut CudaSolver| gpu.context.inner.download::<[f32; 3]>(7, count).unwrap().into_iter().map(|v| v.map(f32::to_bits)).collect::<Vec<_>>();
                    assert_eq!(bits(&mut grouped), bits(&mut separate));
                }
                assert_eq!(grouped.context.inner.download::<[f32; 3]>(2, count).unwrap(), input);
            }
        }
    }
}
