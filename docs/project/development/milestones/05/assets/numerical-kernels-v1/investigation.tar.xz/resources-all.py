from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/tmp/maelstrom-numerical-20261028');records=[]
for v,ptx in [(v,v) for v in ['control','trial-0','trial-1','trial-2','trial-3','trial-4','candidate']]:
 binary=w/('resource-probe-'+v);args=['c++','-std=c++17','-O2','-DCANDIDATE',*(['-DVALIDATED'] if v in ['trial-4','candidate'] else []),'-I/usr/local/cuda/include','-I'+str(w/v/'native'),str(w/'resources.cpp'),'-ldl','-o',str(binary)];p=subprocess.run(args,capture_output=True);assert p.returncode==0,p.stderr
 p=subprocess.run([str(binary),str(w/(ptx+'.ptx'))],capture_output=True);assert p.returncode==0,p.stderr
 data=json.loads(p.stdout);records.append(dict(variant=v,resources=data,probe_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
(w/'resources.json').write_text(json.dumps(records,indent=2)+'\n')
