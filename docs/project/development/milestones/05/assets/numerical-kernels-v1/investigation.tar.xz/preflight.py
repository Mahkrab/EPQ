from pathlib import Path
import subprocess,json,hashlib,gzip,time
w=Path('/tmp/maelstrom-numerical-20261028');r=w/'preflight';r.mkdir();records=[]
def run(name,args,cwd=w):
 t=time.monotonic();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=120)
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(name+'.'+suffix+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 records.append(dict(name=name,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return p
p=run('candidate-ptx',['/usr/local/cuda/bin/nvcc','--ptx','--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3','--gpu-architecture=compute_89','native/kernels.cu','-o',str(w/'candidate.ptx')],w/'candidate');assert p.returncode==0
args=json.loads(Path('/tmp/maelstrom-reprofile11-20261028/ncu-command.json').read_text())['command'];args=[s.replace('/tmp/maelstrom-reprofile11-20261028','/tmp/maelstrom-numerical-20261028') for s in args];p=run('ncu-counters',args);print('counter attempt',p.returncode,flush=True)
