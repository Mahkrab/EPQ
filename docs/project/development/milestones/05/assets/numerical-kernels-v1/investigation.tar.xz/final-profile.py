"""Matched ordinary CUDA traces and separately labelled diagnostic candidate traces."""
from pathlib import Path
import os,subprocess,time,json,gzip,hashlib,sqlite3
w=Path('/tmp/maelstrom-numerical-20261028');r=w/'final-profiles';r.mkdir(exist_ok=True);env=dict(os.environ,XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'));records=[];physical={}
if (r/'activity.sqlite').exists():
 import shutil
 shutil.copyfile(r/'activity.sqlite',r/'activity-incomplete.sqlite');(r/'activity.sqlite').unlink()
dbout=sqlite3.connect(r/'activity.sqlite')
for sql in ['api(workload TEXT,variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)','kernel(workload TEXT,variant TEXT,name TEXT,start_ns INTEGER,end_ns INTEGER,correlation INTEGER)','memcpy(workload TEXT,variant TEXT,start_ns INTEGER,end_ns INTEGER,bytes INTEGER,copy_kind INTEGER,correlation INTEGER)','memset(workload TEXT,variant TEXT,start_ns INTEGER,end_ns INTEGER,bytes INTEGER,correlation INTEGER)','nvtx(workload TEXT,variant TEXT,text TEXT,start_ns INTEGER,end_ns INTEGER,global_tid INTEGER)']:dbout.execute('CREATE TABLE '+sql)
def call(name,args):
 dest=r/name
 if (dest/'process.json').exists():
  rec=json.loads((dest/'process.json').read_text());assert rec['command']==args and rec['exit']==0
  raw=gzip.decompress((dest/'stdout.gz').read_bytes());err=gzip.decompress((dest/'stderr.gz').read_bytes());assert hashlib.sha256(raw).hexdigest()==rec['stdout_sha256'] and hashlib.sha256(err).hexdigest()==rec['stderr_sha256'];return raw
 t=time.monotonic();p=subprocess.run(args,cwd=w,env=env,capture_output=True,timeout=240);dest=r/name;dest.mkdir(parents=True)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(dest/(label+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 rec=dict(command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());(dest/'process.json').write_text(json.dumps(rec,indent=2)+'\n');assert p.returncode==0,name;return p.stdout
identities={}
for v in ['control','candidate']:
 source=json.loads((w/(v+'-source.json')).read_text())
 for path,h in source.items():assert hashlib.sha256((w/v/path).read_bytes()).hexdigest()==h
 binary=w/f'target-{v}/release/maelstrom';ptx=(w/('control.ptx' if v=='diagnostic' else 'candidate.ptx' if v=='candidate-diagnostic' else v+'.ptx')).read_bytes();assert ptx in binary.read_bytes()
 identities[v]=dict(source=source,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),ptx_sha256=hashlib.sha256(ptx).hexdigest())
(r/'identities.json').write_text(json.dumps(identities,indent=2)+'\n')
for name in ['8000','110592','8000-effects','110592-effects']:
 path=w/'control/scenes/falling-block-20.toml' if name.startswith('8000') else w/'inputs/scenes/capacity-block-48.toml'
 for v in ['control','candidate']:
  command=[str(w/f'target-{v}/release/maelstrom'),'run',str(path),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure','--stage-profile']
  if name.startswith('8000'):command+=['--checkpoints','0,1,120,240,480']
  if name.endswith('effects'):
   for value in ['xsph_viscosity_enabled=true','xsph_viscosity_coefficient=0.01','vorticity_confinement_enabled=true','vorticity_confinement_strength_m_s=0.1']:command+=['--set',value]
  diagnostic=v.endswith('diagnostic');prefix=w/f'final-trace-{name}-{v}';flags=['--trace=cuda,nvtx,osrt','--sample=process-tree','--cpuctxsw=process-tree','--backtrace=fp','--sampling-period=1000000'] if diagnostic else ['--trace=cuda','--sample=none','--cpuctxsw=none']
  if v=='candidate-diagnostic':
   for pair in range(3):
    for side in (['candidate','candidate-diagnostic'] if pair%2==0 else ['candidate-diagnostic','candidate']):
     plain=[str(w/f'target-{side}/release/maelstrom'),*command[1:]];plain.remove('--stage-profile')
     raw=call(f'overhead/{name}/pair-{pair+1}/{side}',plain);value=json.loads(raw);value.pop('measurements');value['metadata'].pop('build_revision',None);fp=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest();assert physical.get(name,fp)==fp;physical[name]=fp
  raw=call(f'trace/{name}/{v}',['nsys','profile',*flags,'--force-overwrite=false','--output',str(prefix),*command]);value,_=json.JSONDecoder().raw_decode(raw.decode());m=value.pop('measurements');value['metadata'].pop('build_revision',None);fp=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest();assert physical.get(name,fp)==fp;physical[name]=fp
  call(f'export/{name}/{v}',['nsys','export','--type','sqlite','--output',str(prefix)+'.sqlite',str(prefix)+'.nsys-rep'])
  with sqlite3.connect(str(prefix)+'.sqlite') as db:
   api_table='CUPTI_ACTIVITY_KIND_DRIVER' if db.execute("SELECT count(*) FROM sqlite_master WHERE name='CUPTI_ACTIVITY_KIND_DRIVER'").fetchone()[0] else 'CUPTI_ACTIVITY_KIND_RUNTIME'
   for table,query in [('api','SELECT s.value,a.start,a.end,a.correlationId FROM CUPTI_ACTIVITY_KIND_DRIVER a JOIN StringIds s ON s.id=a.nameId'),('kernel','SELECT s.value,k.start,k.end,k.correlationId FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName ORDER BY k.start'),('memcpy','SELECT start,end,bytes,copyKind,correlationId FROM CUPTI_ACTIVITY_KIND_MEMCPY'),('memset','SELECT start,end,bytes,correlationId FROM CUPTI_ACTIVITY_KIND_MEMSET')]:
    rows=[(name,v,*row) for row in db.execute(query.replace('CUPTI_ACTIVITY_KIND_DRIVER',api_table))];dbout.executemany('INSERT INTO '+table+' VALUES ('+','.join(['?']*(7 if table=='memcpy' else 6))+')',rows)
   if diagnostic:
    rows=[(name,v,*row) for row in db.execute('SELECT COALESCE(n.text,s.value),n.start,n.end,n.globalTid FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL')];dbout.executemany('INSERT INTO nvtx VALUES (?,?,?,?,?,?)',rows)
  dbout.commit();print(name,v,sum(x['total_s'] for x in m['steps']),flush=True)
(r/'physical.json').write_text(json.dumps(physical,indent=2)+'\n');dbout.close()

for v,d in identities.items():
 for p,h in d['source'].items():assert hashlib.sha256((w/v/p).read_bytes()).hexdigest()==h
print('complete',flush=True)
