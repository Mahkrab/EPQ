from pathlib import Path
import json,hashlib,shutil
w=Path('/tmp/maelstrom-numerical-20261028');shutil.copytree(w/'control',w/'trial-3',dirs_exist_ok=True);p=w/'trial-3/native/solver.cu';s=p.read_text()
# Existing checked stages remain the standalone path and the proof authority.
for name in ['length','separation','poly6','spiky_at_distance','spiky','active']:
 marker='__device__ '+('float ' if name in ['length','separation','poly6'] else 'bool ' if name=='active' else 'Vector ')+name+'('
 start=s.index(marker);stop=s.index('\n}',start)+2;a=s[start:stop].replace('Checked &c','Check &c');s=s[:start]+'template<class Check>\n'+a+s[stop:]
start=s.index('    } else if (operation==7) {');end=s.index('    } else if (operation==8)',start);body=s[start:end];body=body[body.index('        Vector sum'):];body=body.replace('        ','    ')
# Geometry-only checks have already completed on the same immutable snapshot in
# grouped operation 5/6. All correction-specific checked quantities remain.
for old,new in [('active(b,s,i,j,c)','active(b,s,i,j,geometry)'),('separation(b.position[i],b.position[j],c,18)','separation(b.position[i],b.position[j],geometry,18)'),('spiky(displacement,s.radius,c)','spiky(displacement,s.radius,geometry)'),('poly6(distance,s.radius,c)','poly6(distance,s.radius,geometry)')]:body=body.replace(old,new)
helper='''// Grouped density/lambda has checked every displacement, Poly6 value and
// Spiky direction on this unchanged Jacobi snapshot. Repeating those checks in
// correction cannot discover a new failure. Standalone correction still uses
// Checked; pressure, multiplier pairs and correction sums always remain checked.
struct ValidatedGeometry {
    __device__ float scalar(float value, unsigned int) { return value; }
    __device__ Vector vector(Vector value, unsigned int) { return value; }
};
template<class Geometry>
__device__ void calculate_correction(SolverBuffers b, SolverSettings s, unsigned int i,
                                     Checked &c, Geometry &geometry) {
'''+body+'}\n\n'
s=s[:start]+'''    } else if (operation==7) {
        if (b.first_operation==5) {
            ValidatedGeometry geometry;
            calculate_correction(b,s,i,c,geometry);
        } else calculate_correction(b,s,i,c,c);
'''+s[end:]
pos=s.index('// Sorting has its own');s=s[:pos]+helper+s[pos:];p.write_text(s)
p=w/'trial-3/native/solver.cu';s=p.read_text()
start=s.index('        Members squared_row');end=s.index('        float denom=c.scalar(sum+s.relaxation',start)
a=s[start:end]
a=a.replace('        Members squared_row','        ValidatedGeometry geometry;\n        Members squared_row',1).replace('active(b,s,i,j,c)','active(b,s,i,j,geometry)').replace('spiky(sub(b.position[i],b.position[j]),s.radius,c)','spiky(sub(b.position[i],b.position[j]),s.radius,geometry)').replace('Vector dir=c.vector(mul(neg(spiky(sub(b.position[i],b.position[j]),s.radius,geometry)),reciprocal),29);','Vector dir=mul(neg(spiky(sub(b.position[i],b.position[j]),s.radius,geometry)),reciprocal);')
s=s[:start]+a+s[end:];p.write_text(s)
source={n:hashlib.sha256((w/'trial-3'/n).read_bytes()).hexdigest() for n in json.loads((w/'control-source.json').read_text())};(w/'trial-3-source.json').write_text(json.dumps(source,indent=2)+'\n')
