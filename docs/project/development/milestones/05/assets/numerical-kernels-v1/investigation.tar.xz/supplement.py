from pathlib import Path
import shutil,subprocess,os,time,json,hashlib,gzip
w=Path('/tmp/maelstrom-numerical-20261028');r=w/'supplement';r.mkdir();records=[]
def run(name,args,cwd=w,env=None):
 t=time.monotonic();p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=600)
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(name+'.'+suffix+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 records.append(dict(name=name,command=args,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0
shutil.copytree(w/'control',w/'control-validation');p=w/'control-validation/src/cuda/solver.rs';p.write_text(p.read_text()+'\n#[cfg(test)]\n#[path = "reuse_tests.rs"]\nmod reuse_tests;\n');shutil.copyfile(w/'candidate/src/cuda/reuse_tests.rs',w/'control-validation/src/cuda/reuse_tests.rs')
names=list(json.loads((w/'control-source.json').read_text()))+['src/cuda/reuse_tests.rs'];(r/'control-validation-source.json').write_text(json.dumps({n:hashlib.sha256((w/'control-validation'/n).read_bytes()).hexdigest() for n in names},indent=2)+'\n')
env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',CARGO_TARGET_DIR=str(w/'target-trial-0'))
run('control-new-fixture',['cargo','test','--release','--features','cuda','--locked','--offline','--lib','cuda::solver::reuse_tests::','--','--include-ignored','--test-threads=1'],w/'control-validation',env)
binary=w/'target-candidate/release/deps/maelstrom-13d7f2152309ef5d';(r/'candidate-test-binary-sha256.txt').write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+'\n')
for tool in ['racecheck','synccheck','initcheck']:
 run(tool,['/usr/local/cuda/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86',str(binary),'cuda::solver::reuse_tests::','--include-ignored','--test-threads=1'])
