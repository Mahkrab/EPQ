from pathlib import Path
import subprocess,json,hashlib,gzip,time,re,statistics
w=Path('/tmp/maelstrom-numerical-20261028');r=w/'postcheck';r.mkdir();records=[]
args=[str(w/'factors-probe')];t=time.monotonic();p=subprocess.run(args,cwd=w,capture_output=True,timeout=120)
for n,b in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(n+'.gz')).write_bytes(gzip.compress(b,mtime=0))
rec=dict(command=args,exit=p.returncode,wall_s=time.monotonic()-t,binary_sha256=hashlib.sha256((w/'factors-probe').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((w/'factors_probe.cu').read_bytes()).hexdigest(),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());(r/'process.json').write_text(json.dumps(rec,indent=2)+'\n');assert p.returncode==0
value=json.loads(p.stdout);assert value['mismatches']==0 and len(value['event_pairs_ms'])==15
pair=value['event_pairs_ms'];value['reference_median_ms']=statistics.median(x[0] for x in pair);value['candidate_median_ms']=statistics.median(x[1] for x in pair);value['median_reduction_percent']=100*(1-value['candidate_median_ms']/value['reference_median_ms']);value['slower_pairs']=sum(x[1]>x[0] for x in pair);value['initial_result']=json.loads((w/'factors-result.json').read_text());(w/'microbenchmark.json').write_text(json.dumps(value,indent=2)+'\n')
checks={}
for v in ['control','trial-0','trial-1','trial-2','trial-3','trial-4','candidate']:
 manifest=json.loads((w/(v+'-source.json')).read_text());assert all(hashlib.sha256((w/v/n).read_bytes()).hexdigest()==h for n,h in manifest.items()),v;checks[v]=len(manifest)
(w/'post-source-check.json').write_text(json.dumps(checks,indent=2)+'\n')
summary={}
for folder,v in [('trial-results','trial-0'),*[(f'trial{i}-results',f'trial-{i}') for i in [1,2,3,4]]]:
 data=json.loads((w/folder/'summary.json').read_text());summary[v]={}
 for group,pairs in data.items():
  med={x:statistics.median(p[x] for p in pairs) for x in ['control',v]};summary[v][group]=dict(pairs=pairs,medians_s=med,median_reduction_percent=100*(1-med[v]/med['control']))
(w/'exploratory-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
counts={}
for name in ['release-suite','hardware-components','cuda_boundary','cuda_execution']:
 raw=gzip.decompress((w/'verification'/name/'stdout.gz').read_bytes()).decode();matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw);counts[name]=dict(passed=sum(int(a) for a,b,c in matches),failed=sum(int(b) for a,b,c in matches),ignored=sum(int(c) for a,b,c in matches))
(w/'qualification-counts.json').write_text(json.dumps(counts,indent=2)+'\n');a=json.loads((w/'independent-audit.json').read_text());(w/'gpu-stages.json').write_text(json.dumps(a['stage_attribution'],indent=2)+'\n');print(checks,counts,flush=True)
