from pathlib import Path
import json,hashlib
w=Path('/tmp/maelstrom-numerical-20261028');p=w/'trial-0/native/solver.cu';s=p.read_text()
# Reuse the rounded invariant result; keep every checked quantity at its original use.
s=s.replace('__device__ float poly6(float d, float h, Checked &c) {','__device__ float poly6_coefficient(float d, float h, float coefficient, Checked &c) {',1)
s=s.replace('float coeff=c.scalar(__fdiv_rn(315.0f,denom),9);','float coeff=c.scalar(coefficient,9);',1)
a='__device__ Vector spiky_at_distance(Vector displacement, float d, float h, Checked &c) {'
s=s.replace(a,'''__device__ float poly6(float d, float h, Checked &c) {
    float h2=h*h, h4=h2*h2, h8=h4*h4;
    return poly6_coefficient(d,h,__fdiv_rn(315.0f,(64.0f*0x1.921fb6p+1f)*(h*h8)),c);
}
__device__ Vector spiky_coefficient(Vector displacement, float d, float h, float coefficient, Checked &c) {''',1)
s=s.replace('float coeff=c.scalar(__fdiv_rn(-45.0f,denom),14);','float coeff=c.scalar(coefficient,14);',1)
s=s.replace('__device__ Vector spiky(Vector displacement, float h, Checked &c) {','''__device__ Vector spiky_at_distance(Vector displacement, float d, float h, Checked &c) {
    float h2=h*h, h4=h2*h2;
    return spiky_coefficient(displacement,d,h,__fdiv_rn(-45.0f,0x1.921fb6p+1f*(h2*h4)),c);
}
__device__ Vector spiky(Vector displacement, float h, Checked &c) {''',1)
pos=s.index('    if (operation==0) {',s.index('extern "C" __global__ void solver'))
s=s[:pos]+'''    float poly_coefficient=0, gradient_coefficient=0;
    if (operation==5 || operation==6 || operation==7) {
        float h2=s.radius*s.radius, h4=h2*h2, h8=h4*h4;
        poly_coefficient=__fdiv_rn(315.0f,(64.0f*0x1.921fb6p+1f)*(s.radius*h8));
        gradient_coefficient=__fdiv_rn(-45.0f,0x1.921fb6p+1f*(h2*h4));
    }
'''+s[pos:]
start=s.index('    } else if (operation==6 || staged)');end=s.index('    } else if (operation==8)',start)
a=s[start:end].replace('poly6(0,s.radius,c)','poly6_coefficient(0,s.radius,poly_coefficient,c)').replace('poly6(distance,s.radius,c)','poly6_coefficient(distance,s.radius,poly_coefficient,c)').replace('spiky_at_distance(displacement,distance,s.radius,owner_check)','spiky_coefficient(displacement,distance,s.radius,gradient_coefficient,owner_check)').replace('spiky(sub(b.position[i],b.position[j]),s.radius,c)','spiky_coefficient(sub(b.position[i],b.position[j]),separation(b.position[i],b.position[j],c,2),s.radius,gradient_coefficient,c)').replace('spiky(displacement,s.radius,c)','spiky_coefficient(displacement,length(displacement,c),s.radius,gradient_coefficient,c)')
# Suffix original length did not check displacement, keep that exact call.
a=a.replace('separation(b.position[i],b.position[j],c,2)','length(sub(b.position[i],b.position[j]),c)')
s=s[:start]+a+s[end:];p.write_text(s)
source={n:hashlib.sha256((w/'trial-0'/n).read_bytes()).hexdigest() for n in json.loads((w/'control-source.json').read_text())};(w/'trial-0-source.json').write_text(json.dumps(source,indent=2)+'\n')
