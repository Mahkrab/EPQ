"""Independently verify numerical identity, paired timing and CUDA activity accounting."""
from pathlib import Path
import json,gzip,hashlib,statistics,sqlite3,collections,sys
w=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/maelstrom-numerical-20261028');sha=lambda b:hashlib.sha256(b).hexdigest();physical={};solver_records=0;processes=0;failed=[];samples={};regressions={}
for folder in ['trial-results','trial1-results','trial2-results','trial3-results','trial4-results','trial-profiles','measurements','verification','final-profiles']:
 for p in sorted((w/folder).rglob('process.json')):
  rec=json.loads(p.read_text());dest=p.parent;raw=gzip.decompress((dest/'stdout.gz').read_bytes());err=gzip.decompress((dest/'stderr.gz').read_bytes());assert sha(raw)==rec['stdout_sha256'] and sha(err)==rec['stderr_sha256'];processes+=1
  if rec['exit']!=0:failed.append(str(dest.relative_to(w)));continue
  try:value,_=json.JSONDecoder().raw_decode(raw.decode())
  except (ValueError,UnicodeDecodeError):continue
  if not isinstance(value,dict) or 'measurements' not in value or 'final_snapshot' not in value:continue
  m=value.pop('measurements');value['metadata'].pop('build_revision',None);expected_steps=16 if folder=='all-apis' else 480;assert not value['failures'] and value['completed_steps']==str(expected_steps);key=sha(json.dumps({k:value[k] for k in ['input','request','execution']},sort_keys=True).encode());fp=sha(json.dumps(value,sort_keys=True,allow_nan=False).encode());assert physical.get(key,fp)==fp,(dest,'physical mismatch');physical[key]=fp;solver_records+=1
  total=sum(x['total_s'] for x in m['steps']);assert len(m['steps'])==expected_steps
  if folder=='measurements' and (dest/'metrics.json').exists():
   metric=json.loads((dest/'metrics.json').read_text());assert metric['solver_s']==total and metric['physical_sha256']==fp;group,label,v=dest.relative_to(w/folder).parts
   if label.startswith('sample-'):samples.setdefault(group,{}).setdefault(v,[]).append(dict(solver_s=total,construction_s=m['solver_construction_s'],teardown_s=m['solver_teardown_s'],child_wall_s=rec['wall_s']))
  if folder=='verification' and dest.relative_to(w/folder).parts[0]=='regression':
   _,n,v=dest.relative_to(w/folder).parts;regressions.setdefault(n,{})[v]=total
assert not failed,failed;assert solver_records==198,solver_records
summary={}
for group,variants in samples.items():
 a,b=variants['control'],variants['candidate'];assert len(a)==len(b)==5;ca=[x['solver_s'] for x in a];cb=[x['solver_s'] for x in b]
 summary[group]=dict(control_median_s=statistics.median(ca),candidate_median_s=statistics.median(cb),control_range_s=[min(ca),max(ca)],candidate_range_s=[min(cb),max(cb)],median_reduction_percent=100*(1-statistics.median(cb)/statistics.median(ca)),paired_reductions_percent=[100*(1-y/x) for x,y in zip(ca,cb)],slower_pairs=sum(y>x for x,y in zip(ca,cb)),other_medians={v:{k:statistics.median(x[k] for x in rows) for k in ['construction_s','teardown_s','child_wall_s']} for v,rows in variants.items()})
 assert summary[group]['median_reduction_percent']==json.loads((w/'measurements/summary.json').read_text())[group]['median_reduction_percent']
assert len(regressions)==7
stages={};db=sqlite3.connect(w/'final-profiles/activity.sqlite')
for group in ['8000','110592','8000-effects','110592-effects']:
 n=int(group.split('-')[0]);effects=group.endswith('effects');sorts=7 if n==8000 else 11;labels=['acceleration_cfl','prediction_bounds','cells']+['spatial_sort']*sorts+['neighbor_count','prefix_block','prefix_total','prefix_carry','neighbor_fill','row_sort']+['density_lambda_validation','publication','correction','physical_density_check','candidate','projection']*8+['velocity']+(['curl','confinement','velocity_replace','xsph','velocity_replace'] if effects else [])
 for v in ['control','candidate']:
  rows=db.execute('SELECT name,start_ns,end_ns FROM kernel WHERE workload=? AND variant=? ORDER BY start_ns',(group,v)).fetchall();assert len(rows)==480*len(labels);totals=collections.Counter()
  for index,(name,a,b) in enumerate(rows):
   label=labels[index%len(labels)];expected='observe_state' if label in ['acceleration_cfl','prediction_bounds'] else 'spatial_sort' if label=='spatial_sort' else 'prefix_counts' if label.startswith('prefix_') else 'validated_correction' if label=='correction' and v=='candidate' else 'solver';assert name==expected,(label,name);assert b>=a;totals[label]+=b-a
  api=dict(db.execute('SELECT name,count(*) FROM api WHERE workload=? AND variant=? GROUP BY name',(group,v)));copies=db.execute('SELECT copy_kind,count(*),sum(bytes) FROM memcpy WHERE workload=? AND variant=? GROUP BY copy_kind',(group,v)).fetchall();candidate=v.startswith('candidate');download=next(x for x in copies if x[0]==2);ncopies=5;nbytes=24*n+64*((n+127)//128)+24;assert download[1]==480*ncopies and download[2]==480*nbytes,(group,v,download,nbytes)
  uploads=next(x for x in copies if x[0]==1);assert uploads[1]==4,(group,v,uploads)
  sync=sum(count for name,count in api.items() if 'StreamSynchronize' in name);assert sync==480*(26 if effects else 21),(group,v,sync)
  stages[group+'/'+v]=dict(gpu_ms_per_step={k:x/480/1e6 for k,x in totals.items()},launches_per_step=len(labels),stream_waits_per_step=sync//480,downloads_per_step=ncopies,download_bytes_per_step=nbytes,all_copies=copies,api_counts=api)
out=dict(solver_records_exact=solver_records,full_trajectory_records=198,short_all_api_records=0,equivalent_groups=len(physical),process_hashes_verified=processes,failed_solver_processes=failed,primary_measured_pairs=20,timing=summary,regression_single_pairs=regressions,stage_attribution=stages)
(w/'independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(records=solver_records,groups=len(physical),timing=summary),indent=2))
