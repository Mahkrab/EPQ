from pathlib import Path
import subprocess,json
w=Path('/tmp/maelstrom-numerical-20261028');out=w/'assembly';out.mkdir(exist_ok=True)
flags=['--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3']
records=[]
for v in ['control']:
 for name,args in [('ptx',['/usr/local/cuda/bin/nvcc','--ptx',*flags,'--generate-line-info','--gpu-architecture=compute_89','native/kernels.cu','-o',str(out/(v+'.ptx'))]),('cubin',['/usr/local/cuda/bin/nvcc','--cubin',*flags,'--generate-line-info','--gpu-architecture=sm_89','--ptxas-options=-v','native/kernels.cu','-o',str(out/(v+'.cubin'))]),('sass',['/usr/local/cuda/bin/cuobjdump','--dump-sass',str(out/(v+'.cubin'))])]:
  p=subprocess.run(args,cwd=w/v,capture_output=True);(out/(v+'-'+name+'.stdout')).write_bytes(p.stdout);(out/(v+'-'+name+'.stderr')).write_bytes(p.stderr);records.append(dict(variant=v,command=args,exit=p.returncode));assert p.returncode==0
(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
