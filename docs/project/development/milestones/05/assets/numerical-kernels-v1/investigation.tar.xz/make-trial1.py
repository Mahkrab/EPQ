from pathlib import Path
import json,hashlib,shutil
w=Path('/tmp/maelstrom-numerical-20261028');shutil.copytree(w/'control',w/'trial-1');p=w/'trial-1/native/solver.cu';s=p.read_text();start=s.index('__device__ float poly6(');end=s.index('__device__ bool active',start)
helpers='''// Radius-only work is speculative. Its first errors are replayed at the same
// logical use points, after support and distance-dependent checks.
struct KernelFactors {
    float h2, poly, gradient;
    unsigned int poly_error, gradient_error;
    __device__ explicit KernelFactors(float h) {
        h2=h*h;
        float h4=h2*h2, h8=h4*h4;
        Checked p, g;
        float h9=p.scalar(h*h8,7);
        float pd=p.scalar((64.0f*0x1.921fb6p+1f)*h9,8);
        poly=p.scalar(__fdiv_rn(315.0f,pd),9);
        float h6=g.scalar(h2*h4,12);
        float gd=g.scalar(0x1.921fb6p+1f*h6,13);
        gradient=g.scalar(__fdiv_rn(-45.0f,gd),14);
        poly_error=p.error;
        gradient_error=g.error;
    }
    __device__ float weight(float d, float h, Checked &c) const {
        if (d>=h) return 0.0f;
        float hh=c.scalar(h2,4), d2=c.scalar(d*d,5);
        float term=c.scalar(hh-d2,6);
        if (!c.error) c.error=poly_error;
        float cube=c.scalar(term*(term*term),10);
        return c.scalar(poly*cube,11);
    }
    __device__ Vector direction(Vector displacement, float d, float h, Checked &c) const {
        if (d==0.0f || d>=h) return {0,0,0};
        if (!c.error) c.error=gradient_error;
        float remain=c.scalar(h-d,15);
        float scale=c.scalar(__fdiv_rn(gradient*(remain*remain),d),16);
        return c.vector(mul(displacement,scale),17);
    }
};
'''
s=s[:end]+helpers+s[end:]
start=s.index('    } else if (operation==6 || staged)');end=s.index('    } else if (operation==8)',start);a=s[start:end]
a=a.replace('        Checked validation;','        const KernelFactors factors(s.radius);\n        Checked validation;',1).replace('    } else if (operation==7) {','    } else if (operation==7) {\n        const KernelFactors factors(s.radius);')
a=a.replace('poly6(0,s.radius,c)','factors.weight(0,s.radius,c)').replace('poly6(distance,s.radius,c)','factors.weight(distance,s.radius,c)').replace('spiky_at_distance(displacement,distance,s.radius,owner_check)','factors.direction(displacement,distance,s.radius,owner_check)').replace('spiky(sub(b.position[i],b.position[j]),s.radius,c)','factors.direction(sub(b.position[i],b.position[j]),length(sub(b.position[i],b.position[j]),c),s.radius,c)').replace('spiky(displacement,s.radius,c)','factors.direction(displacement,length(displacement,c),s.radius,c)')
s=s[:start]+a+s[end:];p.write_text(s)
source={n:hashlib.sha256((w/'trial-1'/n).read_bytes()).hexdigest() for n in json.loads((w/'control-source.json').read_text())};(w/'trial-1-source.json').write_text(json.dumps(source,indent=2)+'\n')
