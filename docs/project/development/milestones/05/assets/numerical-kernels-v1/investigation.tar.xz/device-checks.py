"""Device diagnostics are correctness evidence, never solver timing samples."""
from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/tmp/maelstrom-numerical-20261028');r=w/'device-checks';r.mkdir();binary=w/'target-candidate/release/deps/maelstrom-13d7f2152309ef5d';assert binary.is_file();records=[]
for tool,selection in [('memcheck','cuda::'),('racecheck','cuda::solver::search_tests::'),('synccheck','cuda::solver::search_tests::'),('initcheck','cuda::solver::search_tests::')]:
 args=['/usr/local/cuda/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86']+[str(binary),selection,'--include-ignored','--test-threads=1'];t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=600)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(r/f'{tool}.{label}').write_bytes(data)
 records.append(dict(tool=tool,command=args,exit=p.returncode,wall_s=time.monotonic()-t,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()));(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(tool,p.returncode,flush=True);assert p.returncode==0,(tool,p.stderr[-1000:])
