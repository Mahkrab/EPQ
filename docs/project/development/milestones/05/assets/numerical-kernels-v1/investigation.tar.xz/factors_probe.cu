// Differential checks exercise deferred radius errors; event timings isolate
// ordered kernel arithmetic, not the complete solver or its memory behaviour.
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <cstring>
#include "solver.cu"

__device__ bool same_float(float a,float b) { return __float_as_uint(a)==__float_as_uint(b); }
__global__ void compare_factors(unsigned long long *mismatches) {
    unsigned int index=blockIdx.x*blockDim.x+threadIdx.x;
    if (index>=(1U<<20)) return;
    // An odd permutation samples both signs, every exponent, and mantissa tails.
    unsigned int bits=index*2654435761U;
    float h=__uint_as_float(bits);
    if (index<512) h=__uint_as_float((index/2)<<23 | (index%2 ? 0x7fffffU : 0U));
    const KernelFactors factors(h);
    float distances[]={0.0f,-0.0f,__uint_as_float(1),h,
        __uint_as_float(__float_as_uint(h)-1),__uint_as_float(__float_as_uint(h)+1),
        h*0.5f,-h,1.0f,__uint_as_float(bits^0x5a5a5a5aU),INFINITY,NAN};
    unsigned long long failures=0;
    for (float d:distances) for (unsigned int which=0;which<2;++which) {
        const unsigned int prior=which ? 18U : 0U;
        Checked a,b;a.error=b.error=prior;
        const float expected=poly6(d,h,a),actual=factors.weight(d,h,b);
        if (!same_float(expected,actual) || a.error!=b.error) ++failures;
        a.error=b.error=prior;
        const Vector displacement{d,-d,0.0f};
        const Vector e=spiky_at_distance(displacement,d,h,a),v=factors.direction(displacement,d,h,b);
        if (!same_float(e.x,v.x) || !same_float(e.y,v.y) || !same_float(e.z,v.z) || a.error!=b.error) ++failures;
    }
    if (failures) atomicAdd(mismatches,failures);
}
template<bool Cached> __global__ void arithmetic(float *out,unsigned int *errors,float radius) {
    unsigned int index=blockIdx.x*blockDim.x+threadIdx.x;
    if (index>=110592) return;
    const KernelFactors factors(radius);Checked c;float sum=0;
    for (unsigned int k=0;k<64;++k) {
        float d=radius*(static_cast<float>((index*17+k*7)%97)*0.01f);
        const Vector delta{d,-d,d};
        float weight=Cached ? factors.weight(d,radius,c) : poly6(d,radius,c);
        Vector direction=Cached ? factors.direction(delta,d,radius,c) : spiky_at_distance(delta,d,radius,c);
        sum=c.scalar(sum+c.scalar(weight+dot(direction,direction),71),72);
    }
    out[index]=sum;errors[index]=c.error;
}
static void check(cudaError_t status) {
    if (status!=cudaSuccess) { std::fprintf(stderr,"%s\n",cudaGetErrorString(status));std::exit(1); }
}
int main() {
    unsigned long long *device,total=0;check(cudaMalloc(&device,sizeof(total)));check(cudaMemset(device,0,sizeof(total)));
    for (unsigned int threads: {32U,64U,128U,256U}) {
        compare_factors<<<((1U<<20)+threads-1)/threads,threads>>>(device);
        check(cudaGetLastError());check(cudaDeviceSynchronize());
    }
    check(cudaMemcpy(&total,device,sizeof(total),cudaMemcpyDeviceToHost));check(cudaFree(device));
    std::printf("{\"radius_samples_per_block\":1048576,\"distance_cases\":12,\"prior_errors\":2,\"block_sizes\":[32,64,128,256],\"mismatches\":%llu,\"event_pairs_ms\":[",total);
    if (total) return 2;
    float *out;unsigned int *errors;check(cudaMalloc(&out,110592*sizeof(float)));check(cudaMalloc(&errors,110592*sizeof(unsigned int)));
    std::vector<float> ref(110592),actual(110592);std::vector<unsigned int> er(110592);
    cudaEvent_t begin,end;check(cudaEventCreate(&begin));check(cudaEventCreate(&end));
    for (int pair=0;pair<16;++pair) {
        float ms[2];
        for (int j=0;j<2;++j) {
            const int v=(pair+j)%2;check(cudaEventRecord(begin));
            if (v) arithmetic<true><<<864,128>>>(out,errors,0.2f);
            else arithmetic<false><<<864,128>>>(out,errors,0.2f);
            check(cudaGetLastError());check(cudaEventRecord(end));check(cudaEventSynchronize(end));check(cudaEventElapsedTime(ms+v,begin,end));
            check(cudaMemcpy(actual.data(),out,actual.size()*sizeof(float),cudaMemcpyDeviceToHost));
            check(cudaMemcpy(er.data(),errors,er.size()*sizeof(unsigned int),cudaMemcpyDeviceToHost));
            if (std::any_of(er.begin(),er.end(),[](unsigned int x){return x!=0;})) return 3;
            if (pair==0 && j==0) ref=actual;
            if (std::memcmp(ref.data(),actual.data(),ref.size()*sizeof(float))!=0) return 4;
        }
        if (pair) std::printf("%s[%.9f,%.9f]",pair==1 ? "" : ",",ms[0],ms[1]);
    }
    std::printf("]}\n");check(cudaEventDestroy(begin));check(cudaEventDestroy(end));check(cudaFree(out));check(cudaFree(errors));
}
