from pathlib import Path
import shutil,json,hashlib
w=Path('/tmp/maelstrom-numerical-20261028');shutil.copytree(w/'trial-4',w/'candidate');p=w/'candidate/native/solver.cu';s=p.read_text();s=s.replace('''        if (b.first_operation==5) {
            ValidatedGeometry geometry;
            calculate_correction(b,s,i,c,geometry);
        } else calculate_correction(b,s,i,c,c);''','''        calculate_correction(b,s,i,c,c);''',1);s=s.replace('''        ValidatedGeometry geometry;
        Members squared_row''','''        // The first traversal checked these same directions, including their
        // reciprocal scaling. Any earlier error is fixed; only the ordered
        // dot products and additions can discover another failure here.
        ValidatedGeometry geometry;
        Members squared_row''',1);p.write_text(s)
p=w/'candidate/native/tests.cpp';s=p.read_text();s=s.replace('    struct Launch { unsigned int operation, stride, span, grid, block; };','    struct Launch { unsigned int operation, stride, span, grid, block; CUfunction function; };');s=s.replace('std::strcmp(name,"solver")==0 ? 2 :','std::strcmp(name,"validated_correction")==0 ? 6 : std::strcmp(name,"solver")==0 ? 2 :',1).replace('if (function==reinterpret_cast<CUfunction>(2)) {','if (function==reinterpret_cast<CUfunction>(2) || function==reinterpret_cast<CUfunction>(6)) {',1).replace('settings.stride,settings.span,grid,block});','settings.stride,settings.span,grid,block,function});',1)
# Check dispatch in every recorded launch, including mocked failures.
s=s.replace('''            auto operation=*static_cast<unsigned int *>(args[2]);
            if (buffers.diagnostic''','''            auto operation=*static_cast<unsigned int *>(args[2]);
            assert((function==reinterpret_cast<CUfunction>(6)) ==
                (buffers.first_operation==5 && operation==7));
            if (buffers.diagnostic''',1);p.write_text(s)
p=w/'candidate/src/cuda/solver.rs';p.write_text(p.read_text()+'\n#[cfg(test)]\n#[path = "reuse_tests.rs"]\nmod reuse_tests;\n');shutil.copyfile(w/'reuse_tests.rs',w/'candidate/src/cuda/reuse_tests.rs')
p=w/'candidate/docs/cuda.md';s=p.read_text();needle='The first attempt uploads accepted state and static planes';pos=s.index(needle);s=s[:pos]+'''Within density/lambda, the squared-gradient suffix reuses the completed first
traversal's validation of pair geometry and reciprocal-scaled directions. Its dot
products and ordered additions remain checked. Grouped position correction uses
a dedicated entry after the global density/lambda completion and publication
barriers. The same snapshot and settings have already passed all displacement,
Poly6 and Spiky checks; correction still checks pressure, multiplier pairs,
contributions, ordered sums and scaling. Independent correction calls retain all
geometry checks. No cached geometry, allocation, changed summation or extra launch
is required. Earlier diagnostic slots still suppress dependent writes.

'''+s[pos:];p.write_text(s)
