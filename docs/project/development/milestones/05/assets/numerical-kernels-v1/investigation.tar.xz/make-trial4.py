from pathlib import Path
import shutil,json,hashlib
w=Path('/tmp/maelstrom-numerical-20261028');shutil.copytree(w/'trial-3',w/'trial-4');p=w/'trial-4/native/solver.cu';s=p.read_text();s+='''
// This entry uses the same stream-wide proof as grouped correction. Its private
// resource requirement is independent of discovery and density/lambda code.
extern "C" __global__ void validated_correction(SolverBuffers b, SolverSettings s, unsigned int) {
    const auto lane=static_cast<std::uint64_t>(blockIdx.x)*blockDim.x+threadIdx.x;
    if (lane>=s.count) return;
    for (unsigned int previous=0;previous<2;++previous)
        if (b.diagnostic[previous]!=ULLONG_MAX) return;
    const auto i=static_cast<unsigned int>(lane);
    Checked c;
    ValidatedGeometry geometry;
    calculate_correction(b,s,i,c,geometry);
    b.errors[i]=c.error;
    if (c.error && b.diagnostic) record_diagnostic(b,2,(static_cast<unsigned long long>(i)<<32)|c.error);
}
''';p.write_text(s)
p=w/'trial-4/native/bridge.cpp';s=p.read_text().replace('    CUfunction solver = nullptr;','    CUfunction solver = nullptr;\n    CUfunction validated_correction = nullptr;',1)
needle='    if (!status.code && (code = d.cuModuleGetFunction_fn(&r.solver, r.module, "solver")) != CUDA_SUCCESS) status = {code, 5};'
s=s.replace(needle,needle+'\n    if (!status.code && (code = d.cuModuleGetFunction_fn(&r.validated_correction, r.module, "validated_correction")) != CUDA_SUCCESS) status = {code, 5};',1)
s=s.replace('auto code=r.driver.cuLaunchKernel_fn(function,','auto selected=buffers.first_operation==5 && kernel_operation==7 ? r.validated_correction : function;\n            auto code=r.driver.cuLaunchKernel_fn(selected,',1);p.write_text(s)
source={n:hashlib.sha256((w/'trial-4'/n).read_bytes()).hexdigest() for n in json.loads((w/'control-source.json').read_text())};(w/'trial-4-source.json').write_text(json.dumps(source,indent=2)+'\n')
