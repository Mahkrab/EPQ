"""Qualify final source, including exact small-scene regressions before timing."""
from pathlib import Path
import subprocess,json,time,hashlib,os,gzip
w=Path('/tmp/maelstrom-numerical-20261028/validation-only');r=w/'verification';r.mkdir();env=dict(os.environ,CUDA_HOME='/usr/local/cuda',MAELSTROM_CUDA_ARCH='89',XDG_CONFIG_HOME=str(w/'isolated-config'),MAELSTROM_SCENES_DIR=str(w/'isolated-scenes'),MAELSTROM_RUNS_DIR=str(w/'isolated-runs'));records=[]
def run(name,args,v='candidate',limit=600):
 source=json.loads((w/(v+'-source.json')).read_text());assert all(hashlib.sha256((w/v/p).read_bytes()).hexdigest()==h for p,h in source.items());t=time.monotonic();p=subprocess.run(args,cwd=w/v,env=dict(env,CARGO_TARGET_DIR=str(w/f'target-{v}')),capture_output=True,timeout=limit);dest=r/name;dest.mkdir(parents=True)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:(dest/(label+'.gz')).write_bytes(gzip.compress(data,mtime=0))
 rec=dict(name=name,command=args,variant=v,exit=p.returncode,wall_s=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());(dest/'process.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(rec);(r/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0,(name,p.stderr[-2000:]);return p.stdout
cargo=['cargo','test','--release','--features','cuda','--locked','--offline']
run('release-suite',cargo+['--no-fail-fast'])
run('hardware-components',cargo+['--lib','cuda::','--','--include-ignored','--test-threads=1'])
for target in ['cuda_boundary','cuda_execution']:run(target,cargo+['--test',target,'--','--include-ignored','--test-threads=1'])
run('clippy',['cargo','clippy','--release','--features','cuda','--locked','--offline','--all-targets','--','-D','warnings']);run('format',['cargo','fmt','--check'])
for v in ['control','candidate']:
 binary=str(w/('native-tests-'+v));run(v+'-native-build',['c++','-std=c++17','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I/usr/local/cuda/include','native/tests.cpp','-ldl','-o',binary],v);run(v+'-native',[binary],v);run(v+'-binary',['cargo','build','--release','--features','cuda','--locked','--offline'],v)
checks={}
for side in [4,6,8,10,12,16,20]:
 for v in ['control','candidate']:
  args=[str(w/f'target-{v}/release/maelstrom'),'run',str(w/f'control/scenes/falling-block-{side:02}.toml'),'--backend','cuda','--device','0','--block-size','128','--refine-timestep','4','--steps','480','--unpaced','--format','json','--quiet','--measure','--checkpoints','0,1,120,240,480'];raw=run(f'regression/{side**3}/{v}',args,v,120);value=json.loads(raw);m=value.pop('measurements');value['metadata'].pop('build_revision',None);assert value['completed_steps']=='480' and not value['failures'];fp=hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest();assert checks.get(side,fp)==fp;checks[side]=fp
(r/'regressions.json').write_text(json.dumps(checks,indent=2)+'\n');print('complete',flush=True)
