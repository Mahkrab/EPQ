from pathlib import Path
import subprocess,json,hashlib,collections
w=Path('/tmp/maelstrom-numerical-20261028/validation-only');out=w/'assembly';out.mkdir(exist_ok=True);flags=['--std=c++17','--fmad=false','--ftz=false','--prec-div=true','--prec-sqrt=true','-O3'];records=[];summaries={}
for v in ['control','candidate']:
 for name,args in [('ptx',['/usr/local/cuda/bin/nvcc','--ptx',*flags,'--generate-line-info','--gpu-architecture=compute_89','native/kernels.cu','-o',str(out/(v+'.ptx'))]),('cubin',['/usr/local/cuda/bin/nvcc','--cubin',*flags,'--generate-line-info','--gpu-architecture=sm_89','--ptxas-options=-v','native/kernels.cu','-o',str(out/(v+'.cubin'))]),('sass',['/usr/local/cuda/bin/nvdisasm','-g',str(out/(v+'.cubin'))])]:
  p=subprocess.run(args,cwd=w/v,capture_output=True);(out/(v+'-'+name+'.stdout')).write_bytes(p.stdout);(out/(v+'-'+name+'.stderr')).write_bytes(p.stderr);records.append(dict(variant=v,command=args,exit=p.returncode));assert p.returncode==0
 s=(out/(v+'-sass.stdout')).read_text();functions={};name=None;location=None
 for line in s.splitlines():
  if line.startswith('//--------------------- .text.'):
   name=line.split('.text.')[1].split()[0];functions[name]=collections.Counter()
  if name and '//## File' in line:location=line.strip()
  if name and '*/' in line and '/*' in line:
   instruction=line.split('*/',1)[1].strip()
   if instruction.startswith('@'):instruction=instruction.split(None,1)[1]
   if instruction: functions[name][instruction.split()[0]]+=1
 ptx=(out/(v+'.ptx')).read_text();summaries[v]=dict(ptx_div_rn_f32=ptx.count('div.rn.f32'),ptx_sqrt_rn_f32=ptx.count('sqrt.rn.f32'),sass_static_opcodes=functions,files={str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/(v+'.ptx'),out/(v+'.cubin'),out/(v+'-sass.stdout')]})
(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
