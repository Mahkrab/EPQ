from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil,re
w=Path('/tmp/maelstrom-numerical-20261028');f=w/'validation-only';out=w/'retained';sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(json.loads((f/'device-checks/commands.json').read_text()))==4
assert all(x['exit']==0 for x in json.loads((f/'device-checks/commands.json').read_text()))
args=[str(w/'resource-probe-trial-3'),str(f/'candidate.ptx')];p=subprocess.run(args,capture_output=True);assert p.returncode==0,p.stderr
resource=dict(command=args,exit=p.returncode,resources=json.loads(p.stdout),ptx_matches_exploratory_trial_3=(f/'candidate.ptx').read_bytes()==(w/'trial-3.ptx').read_bytes(),stdout_sha256=sha(p.stdout),probe_sha256=sha((w/'resource-probe-trial-3').read_bytes()));(f/'resources.json').write_text(json.dumps(resource,indent=2)+'\n')
counts={}
for name in ['release-suite','hardware-components','cuda_boundary','cuda_execution']:
 raw=__import__('gzip').decompress((f/'verification'/name/'stdout.gz').read_bytes()).decode();m=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw);counts[name]=dict(passed=sum(int(a) for a,b,c in m),failed=sum(int(b) for a,b,c in m),ignored=sum(int(c) for a,b,c in m))
(f/'qualification-counts.json').write_text(json.dumps(counts,indent=2)+'\n')
checks={}
for v in ['control','candidate']:
 s=json.loads((f/(v+'-source.json')).read_text());assert all(sha((f/v/n).read_bytes())==h for n,h in s.items());checks[v]=len(s);assert (f/(v+'.ptx')).read_bytes() in (f/f'target-{v}/release/maelstrom').read_bytes()
(f/'post-source-check.json').write_text(json.dumps(checks,indent=2)+'\n')
for origin,dest in [('candidate-source.json','validation-only-source.json'),('protocol.md','validation-only-protocol.md'),('independent-audit.json','validation-only-audit.json'),('resources.json','validation-only-resources.json'),('qualification-counts.json','validation-only-qualification-counts.json')]:shutil.copyfile(f/origin,out/dest)
shutil.copyfile(w/'followup-audit.py',out/'followup-audit.py')
a=json.loads((w/'control-source.json').read_text());b=json.loads((f/'candidate-source.json').read_text());parts=[]
for n in sorted(a.keys()|b.keys()):
 if a.get(n)==b.get(n):continue
 left=w/'control'/n;right=f/'candidate'/n;p=subprocess.run(['diff','-u','--label','a/'+n if left.exists() else '/dev/null','--label','b/'+n,str(left) if left.exists() else '/dev/null',str(right)],capture_output=True);assert p.returncode==1;parts.append(p.stdout)
(out/'validation-only.patch').write_bytes(b''.join(parts))
members=json.loads((out/'files-sha256.json').read_text());counts_archive=json.loads((out/'archive-members.json').read_text());paths=[]
for folder in ['verification','measurements','final-profiles','device-checks','assembly','inputs']:
 paths.extend((p,p.relative_to(w).as_posix()) for p in (f/folder).rglob('*') if p.is_file())
paths.extend((p,p.relative_to(w).as_posix()) for p in f.iterdir() if p.is_file() and p.suffix in ['.py','.json','.md','.log','.ptx','.stdout','.stderr'])
paths.extend((p,'validation-only/task-readers/'+p.name) for p in w.glob('followup-*.py'))
name='validation-only.tar.xz'
def scrub(info):info.uid=info.gid=0;info.uname=info.gname='';return info
with tarfile.open(out/name,'w:xz',preset=6) as archive:
 for p,n in sorted(paths,key=lambda pair:pair[1]):
  assert n not in members,n;members[n]=sha(p.read_bytes());archive.add(p,arcname=n,recursive=False,filter=scrub)
counts_archive[name]=len(paths);(out/'files-sha256.json').write_text(json.dumps(members,indent=2)+'\n');(out/'archive-members.json').write_text(json.dumps(counts_archive,indent=2)+'\n');print('complete',len(paths),'followup members;',len(members),'total',flush=True)
