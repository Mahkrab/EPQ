from pathlib import Path
import shutil,json,hashlib
w=Path('/tmp/maelstrom-numerical-20261028');f=w/'validation-only';f.mkdir();(f/'protocol.md').write_text('''# Prospective bounded validation-only follow-up
The combined dedicated-entry candidate is rejected after primary results: large no-effects median +2.535% slower despite three other improved medians. Preserve that campaign intact. The preceding validation-only trial-3 improved all four two-pair exploratory medians; it avoids an extra entry and module lookup. This is a separate final experiment, not replacement samples. Test only trial-3 validation reuse, with its standalone checked path, original dispatch, all ten retained optimisations, and the new exact fixture. No coefficient-hoisting candidate is combined.

Same PC, scenes, precise flags, device0, block128, refine4, eight iterations,480 unpaced steps, four workloads and observation policy. Qualify full release/CUDA/boundary/execution/native/Clippy/fmt and seven exact regressions before independent one warmup+five alternating pairs per workload (first measured candidate/control). Fresh PTX/binary/input identities and post-source checks. Eight matched full-trajectory GPU captures separate. No concurrent task builds/tests during timing, no source/setting/driver/registry/security changes. Retain only consistent useful whole-solver benefit at acceptable complexity; otherwise reject all numerical prototypes. Preserve every failure/slow sample. All original198 records remain separate.
''')
shutil.copytree(w/'control',f/'control');shutil.copyfile(w/'control-source.json',f/'control-source.json');shutil.copytree(w/'trial-3',f/'candidate');shutil.copytree(w/'inputs',f/'inputs');(f/'target-control').symlink_to(w/'target-control');(f/'target-candidate').symlink_to(w/'target-trial-3')
p=f/'candidate/src/cuda/solver.rs';p.write_text(p.read_text()+'\n#[cfg(test)]\n#[path = "reuse_tests.rs"]\nmod reuse_tests;\n');shutil.copyfile(w/'candidate/src/cuda/reuse_tests.rs',f/'candidate/src/cuda/reuse_tests.rs')
p=f/'candidate/native/solver.cu';s=p.read_text().replace('''        float ratio=c.scalar(__fdiv_rn(weight,s.reference_weight),34);
        float shaped=c.scalar(ordered_power(ratio,s.exponent),35);
        pressure=c.scalar(-s.strength*shaped,36);''','''            float ratio=c.scalar(__fdiv_rn(weight,s.reference_weight),34);
            float shaped=c.scalar(ordered_power(ratio,s.exponent),35);
            pressure=c.scalar(-s.strength*shaped,36);''',1)
s=s.replace('''        ValidatedGeometry geometry;
        Members squared_row''','''        // The first traversal checked these same directions and their
        // reciprocal scaling. Only the ordered dot products and additions can
        // discover another failure after the preceding first-error selection.
        ValidatedGeometry geometry;
        Members squared_row''',1);p.write_text(s)
p=f/'candidate/docs/cuda.md';s=p.read_text();pos=s.index('The first attempt uploads accepted state and static planes');s=s[:pos]+'''The squared-gradient suffix reuses validation completed in the first traversal;
its dot products and ordered additions remain checked. Grouped correction likewise
reuses the preceding globally completed density/lambda checks of displacement,
Poly6 and Spiky on the identical position snapshot. Pressure, multiplier pairs,
contributions, ordered sums and correction scaling retain their checks. Standalone
correction keeps full geometry checks. Earlier diagnostic slots still suppress
dependent writes. This requires no geometry cache, new allocation, kernel entry,
launch, transfer or cancellation boundary.

'''+s[pos:];p.write_text(s)
names=list(json.loads((w/'control-source.json').read_text()))+['src/cuda/reuse_tests.rs'];(f/'candidate-source.json').write_text(json.dumps({n:hashlib.sha256((f/'candidate'/n).read_bytes()).hexdigest() for n in names},indent=2)+'\n')
for name in ['verify.py','measure.py','final-profile.py','static-analysis.py']:
 s=(w/name).read_text().replace("Path('/tmp/maelstrom-numerical-20261028')","Path('/tmp/maelstrom-numerical-20261028/validation-only')")
 if name=='static-analysis.py':s=s.replace("['control','trial-0','trial-1','trial-2','trial-3','trial-4','candidate']","['control','candidate']")
 (f/name).write_text(s)
